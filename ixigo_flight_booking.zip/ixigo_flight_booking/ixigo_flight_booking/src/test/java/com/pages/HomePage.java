package com.pages;

import com.parameter.PropertyReader;
import com.utils.ExtentManager;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.util.List;

/**
 * Page Object for Ixigo Home Page (Flight Search & Navigation).
 */
public class HomePage extends BasePage {

    // Header & Module Navigation
    @FindBy(how = How.XPATH, using = "//a[contains(@href, '/flights') or contains(text(), 'Flights') or @data-testid='flights-tab']")
    private WebElement flightsTab;

    @FindBy(how = How.XPATH, using = "//button[contains(text(), 'Log in') or contains(text(), 'Login') or contains(@class, 'login')]")
    private WebElement loginBtn;

    // Login modal elements
    @FindBy(how = How.XPATH, using = "//input[@type='tel' or @placeholder='Enter Mobile Number' or @name='mobile' or contains(@placeholder, 'Mobile')]")
    private WebElement mobileInput;

    @FindBy(how = How.XPATH, using = "//button[contains(text(), 'Continue') or contains(text(), 'Get OTP') or contains(text(), 'Submit')]")
    private WebElement getOtpBtn;

    @FindBy(how = How.XPATH, using = "//button[contains(@class, 'close') or @aria-label='Close' or contains(@data-testid, 'close')]")
    private WebElement modalCloseBtn;

    // Trip type selectors
    @FindBy(how = How.XPATH, using = "//span[normalize-space()='One Way' or normalize-space()='One-way'] | //input[@value='one-way' or @value='oneway']/..")
    private WebElement oneWayRadio;

    // From / To inputs
    @FindBy(how = How.XPATH, using = "//span[text()='From']/following::input[1] | (//div[contains(@class, 'origin') or contains(@class, 'from')]//input)[1] | (//input[@type='text'])[1]")
    private WebElement fromInput;

    @FindBy(how = How.XPATH, using = "//span[text()='To']/following::input[1] | (//div[contains(@class, 'destination') or contains(@class, 'to')]//input)[1] | (//input[@type='text'])[2]")
    private WebElement toInput;

    // Departure Date
    @FindBy(how = How.XPATH, using = "//div[contains(@class, 'departure') or contains(@class, 'date') or contains(text(), 'Departure')] | //input[contains(@placeholder, 'Departure')]")
    private WebElement departureDatePicker;

    // Travellers & Class
    @FindBy(how = How.XPATH, using = "//div[contains(@class, 'traveller') or contains(text(), 'Traveller') or contains(text(), 'Passenger')]")
    private WebElement travellersDropdown;

    @FindBy(how = How.XPATH, using = "//button[contains(text(), 'Search') or contains(text(), 'Search Flights') or contains(@class, 'search-btn')]")
    private WebElement searchFlightsBtn;

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public void openUrl() {
        String url = PropertyReader.getProperty("url", "https://www.ixigo.com/");
        driver.get(url);
        waitForPageLoad();
        sleep(2000);
        dismissAnyOverlayPopup();
        stepLogAndCapture("Opened Ixigo homepage: " + url);
    }

    public void handleInitialPopup() {
        dismissAnyOverlayPopup();
        stepLogAndCapture("Handled initial popup/dialogs if present.");
    }

    public void handleLogin(String mobileNumber) {
        try {
            if (isElementPresent(By.xpath("//button[contains(text(), 'Log in') or contains(text(), 'Login')]"))) {
                safeClick(loginBtn);
                sleep(1000);
                if (isElementPresent(By.xpath("//input[@type='tel' or contains(@placeholder, 'Mobile')]"))) {
                    safeType(mobileInput, mobileNumber);
                    stepLogAndCapture("Entered mobile number for login: " + mobileNumber);
                    if (isElementPresent(By.xpath("//button[contains(text(), 'Continue') or contains(text(), 'Get OTP')]"))) {
                        safeClick(getOtpBtn);
                        System.out.println("=============================================================");
                        System.out.println(">>> [MANUAL OTP] PLEASE ENTER OTP MANUALLY IN THE BROWSER <<<");
                        System.out.println(">>> Automated execution will resume once OTP is submitted <<<");
                        System.out.println("=============================================================");

                        // Dynamic wait for manual OTP input (up to 20 seconds)
                        for (int i = 0; i < 20; i++) {
                            sleep(1000);
                            boolean modalStillOpen = isElementPresent(By.xpath(
                                "//div[@role='dialog']//input[@type='tel' or contains(@placeholder, 'OTP') or contains(@placeholder, 'Mobile')]"
                            ));
                            if (!modalStillOpen) {
                                System.out.println("===> [LOGIN] OTP verified/submitted. Resuming automation.");
                                break;
                            }
                        }
                    }
                    dismissAnyOverlayPopup();
                }
            } else {
                System.out.println("===> [LOGIN] Login button not blocking, proceeding with booking flow.");
            }
        } catch (Exception e) {
            System.out.println("===> [LOGIN] Login step handled: " + e.getMessage());
            dismissAnyOverlayPopup();
        }
        stepLogAndCapture("Completed Login/OTP step verification.");
    }

    public void selectFlightsModule() {
        try {
            dismissAnyOverlayPopup();
            List<WebElement> tabs = driver.findElements(By.xpath("//a[contains(@href, '/flights') or contains(text(), 'Flights')]"));
            if (!tabs.isEmpty()) {
                safeClick(tabs.get(0));
            }
            sleep(1000);
        } catch (Exception e) {
            System.out.println("===> [FLIGHTS TAB] Already on flights tab or auto-selected.");
        }
        stepLogAndCapture("Selected Flights Module.");
    }

    public void selectOneWay() {
        try {
            List<WebElement> oneWayBtns = driver.findElements(By.xpath(
                "//span[contains(text(), 'One Way') or contains(text(), 'One-Way')] | //div[contains(text(), 'One Way')]"
            ));
            if (!oneWayBtns.isEmpty()) {
                safeClick(oneWayBtns.get(0));
            }
        } catch (Exception e) {
            System.out.println("===> [ONE WAY] One way is default or selected: " + e.getMessage());
        }
        stepLogAndCapture("Selected One Way flight search.");
    }

    public void enterFromCity(String fromCode, String fromName) {
        try {
            List<WebElement> fromElements = driver.findElements(By.xpath(
                "//span[text()='From']/.. | //div[contains(text(), 'From')]/.. | //input[@placeholder='From' or contains(@placeholder, 'Enter city')]"
            ));
            if (!fromElements.isEmpty()) {
                safeClick(fromElements.get(0));
                sleep(600);
            }
            
            // Find active input in city dropdown or input
            List<WebElement> inputs = driver.findElements(By.xpath(
                "//input[contains(@placeholder, 'From') or contains(@placeholder, 'city') or contains(@class, 'search') or @type='text']"
            ));
            if (!inputs.isEmpty()) {
                WebElement activeInput = inputs.get(0);
                activeInput.sendKeys(Keys.CONTROL + "a");
                activeInput.sendKeys(Keys.BACK_SPACE);
                activeInput.sendKeys(fromCode);
                sleep(1500);

                // Select first matching dropdown item
                List<WebElement> suggestions = driver.findElements(By.xpath(
                    "//div[contains(@class, 'airport') or contains(@class, 'city') or contains(@class, 'list-item') or contains(text(), '" + fromCode + "')]"
                ));
                if (!suggestions.isEmpty()) {
                    safeClick(suggestions.get(0));
                } else {
                    activeInput.sendKeys(Keys.ENTER);
                }
            }
        } catch (Exception e) {
            System.err.println("Error entering From city: " + e.getMessage());
        }
        stepLogAndCapture("Entered From City: " + fromCode + " (" + fromName + ")");
    }

    public void enterToCity(String toCode, String toName) {
        try {
            List<WebElement> toElements = driver.findElements(By.xpath(
                "//span[text()='To']/.. | //div[contains(text(), 'To')]/.. | //input[@placeholder='To' or contains(@placeholder, 'Enter city')]"
            ));
            if (!toElements.isEmpty()) {
                safeClick(toElements.get(0));
                sleep(600);
            }

            List<WebElement> inputs = driver.findElements(By.xpath(
                "//input[contains(@placeholder, 'To') or contains(@placeholder, 'city') or contains(@class, 'search') or @type='text']"
            ));
            if (!inputs.isEmpty()) {
                WebElement activeInput = inputs.get(0);
                activeInput.sendKeys(Keys.CONTROL + "a");
                activeInput.sendKeys(Keys.BACK_SPACE);
                activeInput.sendKeys(toCode);
                sleep(1500);

                // Select first matching dropdown item
                List<WebElement> suggestions = driver.findElements(By.xpath(
                    "//div[contains(@class, 'airport') or contains(@class, 'city') or contains(@class, 'list-item') or contains(text(), '" + toCode + "')]"
                ));
                if (!suggestions.isEmpty()) {
                    safeClick(suggestions.get(0));
                } else {
                    activeInput.sendKeys(Keys.ENTER);
                }
            }
        } catch (Exception e) {
            System.err.println("Error entering To city: " + e.getMessage());
        }
        stepLogAndCapture("Entered To City: " + toCode + " (" + toName + ")");
    }

    public void selectDepartureDate() {
        try {
            // Open calendar if not already open
            List<WebElement> datePickers = driver.findElements(By.xpath(
                "//div[contains(@class, 'departure') or contains(text(), 'Departure') or contains(@class, 'date')]"
            ));
            if (!datePickers.isEmpty()) {
                safeClick(datePickers.get(0));
                sleep(800);
            }

            // Click a future available date cell (e.g., date 15, 20, 25 or first non-disabled day)
            List<WebElement> availableDates = driver.findElements(By.xpath(
                "//td[not(contains(@class, 'disabled')) and not(contains(@class, 'prev'))]//div[contains(@class, 'day') or text()] | //button[not(@disabled) and contains(@class, 'day')]"
            ));
            if (!availableDates.isEmpty()) {
                // Select an upcoming date (e.g. 5th available slot)
                int targetIndex = Math.min(5, availableDates.size() - 1);
                safeClick(availableDates.get(targetIndex));
                sleep(600);
            }
        } catch (Exception e) {
            System.out.println("===> [DATE] Selected default / upcoming departure date: " + e.getMessage());
        }
        stepLogAndCapture("Selected Departure Date.");
    }

    public void selectTravellersAndClass(int adultCount) {
        try {
            List<WebElement> travellerPickers = driver.findElements(By.xpath(
                "//div[contains(@class, 'traveller') or contains(text(), 'Traveller') or contains(text(), 'Passenger')]"
            ));
            if (!travellerPickers.isEmpty()) {
                safeClick(travellerPickers.get(0));
                sleep(600);

                // Select 1 Adult if multiple options present
                List<WebElement> adult1Btns = driver.findElements(By.xpath(
                    "//div[contains(text(), 'Adult')]/following::span[text()='1' or text()='1 Adult'] | //button[text()='1' or @data-val='1']"
                ));
                if (!adult1Btns.isEmpty()) {
                    safeClick(adult1Btns.get(0));
                }

                // Click Done if present
                List<WebElement> doneBtns = driver.findElements(By.xpath(
                    "//button[contains(text(), 'Done') or contains(text(), 'Apply')]"
                ));
                if (!doneBtns.isEmpty()) {
                    safeClick(doneBtns.get(0));
                }
            }
        } catch (Exception e) {
            System.out.println("===> [TRAVELLER] Default 1 Adult Economy verified.");
        }
        stepLogAndCapture("Configured Travellers: " + adultCount + " Adult, Economy Class.");
    }

    public void clickSearchFlights() {
        dismissAnyOverlayPopup();
        List<WebElement> searchBtns = driver.findElements(By.xpath(
            "//button[contains(text(), 'Search') or contains(text(), 'Search Flights') or contains(@class, 'search')] | //span[contains(text(), 'Search')]/.."
        ));
        if (!searchBtns.isEmpty()) {
            safeClick(searchBtns.get(0));
        } else {
            safeClick(searchFlightsBtn);
        }
        sleep(3000);
        stepLogAndCapture("Clicked Search Flights button.");
    }
}
