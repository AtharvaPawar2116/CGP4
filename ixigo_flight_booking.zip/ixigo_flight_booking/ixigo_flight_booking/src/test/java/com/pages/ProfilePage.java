package com.pages;

import com.utils.ExtentManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.util.List;

/**
 * Page Object for Ixigo Review, Traveller Profile Details, Add-ons (Seat & Meal),
 * and Payment Navigation.
 */
public class ProfilePage extends BasePage {

    // Free Cancellation Radio buttons
    @FindBy(how = How.XPATH, using = "//input[contains(@value, 'NO') or contains(@id, 'no-cancellation') or contains(@id, 'standard')]/.. | //span[contains(text(), \"don't want free cancellation\") or contains(text(), \"No, I don't\")]/.. | //div[contains(text(), 'Standard') or contains(text(), 'without free cancellation')]")
    private WebElement noFreeCancellationRadio;

    // Traveller Form Elements
    @FindBy(how = How.XPATH, using = "//input[@name='firstName' or contains(@placeholder, 'First') or contains(@data-testid, 'first-name')]")
    private WebElement firstNameInput;

    @FindBy(how = How.XPATH, using = "//input[@name='lastName' or contains(@placeholder, 'Last') or contains(@data-testid, 'last-name')]")
    private WebElement lastNameInput;

    @FindBy(how = How.XPATH, using = "//input[@type='email' or @name='email' or contains(@placeholder, 'Email')]")
    private WebElement emailInput;

    @FindBy(how = How.XPATH, using = "//input[@type='tel' or @name='mobile' or contains(@placeholder, 'Mobile') or contains(@placeholder, 'Phone')]")
    private WebElement mobileInput;

    @FindBy(how = How.XPATH, using = "//input[@name='pincode' or contains(@placeholder, 'Pincode') or contains(@placeholder, 'PIN') or @id='pincode']")
    private WebElement pincodeInput;

    @FindBy(how = How.XPATH, using = "//input[@name='address' or contains(@placeholder, 'Address') or @id='address']")
    private WebElement addressInput;

    // Continue button
    @FindBy(how = How.XPATH, using = "//button[contains(text(), 'Continue') or contains(text(), 'Proceed') or contains(@class, 'continue-btn')]")
    private WebElement continueBtn;

    public ProfilePage(WebDriver driver) {
        super(driver);
    }

    /**
     * Step 1: Select "I don't want free cancellation" radio button.
     */
    public void selectNoFreeCancellation() {
        System.out.println("===> [FARE TYPE] Selecting 'I don\\'t want free cancellation'...");
        dismissAnyOverlayPopup();
        sleep(1500);

        try {
            List<WebElement> noCancellationOptions = driver.findElements(By.xpath(
                "//span[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), \"don't want free cancellation\") or contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), \"no, i don't want\") or contains(text(), 'Standard')]/.. | " +
                "//input[contains(@value, 'NO') or contains(@value, 'no') or contains(@id, 'no')]/.. | " +
                "//div[contains(text(), 'Without Cancellation') or contains(text(), 'Standard Fare')]"
            ));

            if (!noCancellationOptions.isEmpty()) {
                scrollToElement(noCancellationOptions.get(0));
                safeClick(noCancellationOptions.get(0));
                System.out.println("===> [FARE TYPE] Clicked 'I don\\'t want free cancellation' option.");
            } else {
                System.out.println("===> [FARE TYPE] Option already default or not present.");
            }
        } catch (Exception e) {
            System.out.println("===> [FARE TYPE] Handled radio selection: " + e.getMessage());
        }
        stepLogAndCapture("Selected 'I don\\'t want free cancellation' radio button.");
    }

    /**
     * Step 2: Fill Traveller details from Excel sheet.
     */
    public void fillTravellerDetails(String title, String firstName, String lastName, String gender, String mobile, String email) {
        System.out.println("===> [TRAVELLER DETAILS] Entering passenger info: " + title + " " + firstName + " " + lastName);
        dismissAnyOverlayPopup();
        sleep(1000);

        try {
            // Check if "Add Adult" or "Add Traveller" needs to be clicked
            List<WebElement> addTravellerBtns = driver.findElements(By.xpath(
                "//button[contains(text(), 'Add Adult') or contains(text(), 'Add Traveller') or contains(text(), 'Add New')] | //div[contains(text(), '+ Add Adult')]"
            ));
            if (!addTravellerBtns.isEmpty() && addTravellerBtns.get(0).isDisplayed()) {
                safeClick(addTravellerBtns.get(0));
                sleep(800);
            }

            // Select Title (Mr / Ms)
            List<WebElement> titleOptions = driver.findElements(By.xpath(
                "//button[text()='" + title + "'] | //span[text()='" + title + "']/.. | //input[@value='" + title + "']/.. | //div[text()='" + title + "']"
            ));
            if (!titleOptions.isEmpty()) {
                safeClick(titleOptions.get(0));
            }

            // First Name
            List<WebElement> fNameFields = driver.findElements(By.xpath(
                "//input[@name='firstName' or contains(@placeholder, 'First') or contains(@placeholder, 'Given') or contains(@data-testid, 'first')]"
            ));
            if (!fNameFields.isEmpty()) {
                safeType(fNameFields.get(0), firstName);
            }

            // Last Name
            List<WebElement> lNameFields = driver.findElements(By.xpath(
                "//input[@name='lastName' or contains(@placeholder, 'Last') or contains(@placeholder, 'Surname') or contains(@data-testid, 'last')]"
            ));
            if (!lNameFields.isEmpty()) {
                safeType(lNameFields.get(0), lastName);
            }

            // Gender if separate radio / dropdown
            if (gender != null && !gender.isEmpty()) {
                List<WebElement> genderOptions = driver.findElements(By.xpath(
                    "//span[text()='" + gender + "']/.. | //button[text()='" + gender + "'] | //input[@value='" + gender.toLowerCase() + "']/.."
                ));
                if (!genderOptions.isEmpty()) {
                    safeClick(genderOptions.get(0));
                }
            }

            // Email Address
            List<WebElement> emailFields = driver.findElements(By.xpath(
                "//input[@type='email' or @name='email' or contains(@placeholder, 'Email')]"
            ));
            if (!emailFields.isEmpty()) {
                safeType(emailFields.get(0), email);
            }

            // Mobile Number
            List<WebElement> mobileFields = driver.findElements(By.xpath(
                "//input[@type='tel' or @name='mobile' or contains(@placeholder, 'Mobile') or contains(@placeholder, 'Phone')]"
            ));
            if (!mobileFields.isEmpty()) {
                safeType(mobileFields.get(0), mobile);
            }

        } catch (Exception e) {
            System.err.println("Error filling traveller details: " + e.getMessage());
        }
        stepLogAndCapture("Filled Traveller Details from Excel: " + title + " " + firstName + " " + lastName + " (" + email + ")");
    }

    /**
     * Step 3: Fill Contact & Billing Address PIN Code and details.
     */
    public void fillBillingDetails(String pincode, String address, String state) {
        System.out.println("===> [BILLING ADDRESS] Entering Pincode: " + pincode);
        try {
            // Pincode input
            List<WebElement> pincodeFields = driver.findElements(By.xpath(
                "//input[@name='pincode' or contains(@placeholder, 'Pincode') or contains(@placeholder, 'PIN') or @id='pincode']"
            ));
            if (!pincodeFields.isEmpty()) {
                scrollToElement(pincodeFields.get(0));
                safeType(pincodeFields.get(0), pincode);
                sleep(800);
            }

            // Address input if present
            List<WebElement> addressFields = driver.findElements(By.xpath(
                "//input[@name='address' or contains(@placeholder, 'Address') or @id='address']"
            ));
            if (!addressFields.isEmpty() && address != null) {
                safeType(addressFields.get(0), address);
            }

            // State input/dropdown if present
            List<WebElement> stateFields = driver.findElements(By.xpath(
                "//input[@name='state' or contains(@placeholder, 'State')] | //select[@name='state']"
            ));
            if (!stateFields.isEmpty() && state != null) {
                safeType(stateFields.get(0), state);
            }

        } catch (Exception e) {
            System.out.println("===> [BILLING] Pincode entry handled: " + e.getMessage());
        }
        stepLogAndCapture("Entered Billing Address Pincode: " + pincode);
    }

    /**
     * Step 4: Click Continue button on Traveller form.
     */
    public void clickContinue() {
        System.out.println("===> [NAVIGATION] Clicking Continue button...");
        dismissAnyOverlayPopup();
        sleep(1000);

        try {
            List<WebElement> continueBtns = driver.findElements(By.xpath(
                "//button[contains(text(), 'Continue') or contains(text(), 'Proceed to') or contains(@class, 'continue-btn')] | //span[contains(text(), 'Continue')]/.."
            ));
            if (!continueBtns.isEmpty()) {
                scrollToElement(continueBtns.get(continueBtns.size() - 1));
                safeClick(continueBtns.get(continueBtns.size() - 1));
            } else {
                safeClick(continueBtn);
            }
            sleep(3000);
        } catch (Exception e) {
            System.err.println("Error clicking continue button: " + e.getMessage());
        }
        stepLogAndCapture("Clicked Continue button on Traveller form.");
    }

    /**
     * Step 5: After clicking continue, handle Review Window -> click Confirm.
     */
    public void handleReviewWindowAndConfirm() {
        System.out.println("===> [REVIEW WINDOW] Checking for Review Window modal...");
        sleep(2000);
        try {
            List<WebElement> confirmBtns = driver.findElements(By.xpath(
                "//button[contains(text(), 'Confirm') or contains(text(), 'Yes, Confirm') or contains(text(), 'Looks Good') or contains(text(), 'Proceed')] | //div[contains(@role, 'dialog')]//button[contains(text(), 'Confirm')]"
            ));
            if (!confirmBtns.isEmpty()) {
                System.out.println("===> [REVIEW WINDOW] Confirming review modal details...");
                safeClick(confirmBtns.get(0));
                sleep(2500);
            } else {
                System.out.println("===> [REVIEW WINDOW] No separate confirmation popup blocking.");
            }
        } catch (Exception e) {
            System.out.println("===> [REVIEW WINDOW] Handled review confirmation: " + e.getMessage());
        }
        stepLogAndCapture("Handled Review Window and clicked Confirm.");
    }

    /**
     * Step 6: Free cancellation popup -> click "No Thanks" / "Proceed without Assured".
     */
    public void handleFreeCancellationPopup() {
        System.out.println("===> [MODAL] Checking for Free Cancellation / Ixigo Assured popup...");
        sleep(2000);
        try {
            List<WebElement> noThanksBtns = driver.findElements(By.xpath(
                "//button[contains(text(), 'No, Thanks') or contains(text(), 'No Thanks') or contains(text(), 'Proceed without') or contains(text(), 'Skip') or contains(text(), 'I will risk it')] | " +
                "//span[contains(text(), 'No Thanks') or contains(text(), 'No, Thanks')]/.. | " +
                "//div[contains(@class, 'modal')]//button[contains(text(), 'No') or contains(text(), 'Skip')]"
            ));

            if (!noThanksBtns.isEmpty()) {
                System.out.println("===> [MODAL] Clicked 'No Thanks' on Free Cancellation popup.");
                safeClick(noThanksBtns.get(0));
                sleep(2500);
            } else {
                System.out.println("===> [MODAL] Free cancellation popup not displayed, proceeding.");
            }
        } catch (Exception e) {
            System.out.println("===> [MODAL] Handled Free Cancellation dialog: " + e.getMessage());
        }
        stepLogAndCapture("Handled Free Cancellation window and selected 'No Thanks'.");
    }

    /**
     * Step 7: Seat Selection -> select the first available seat.
     */
    public void selectFirstAvailableSeat() {
        System.out.println("===> [SEAT SELECTION] Locating first available seat on the seat map...");
        sleep(2500);
        dismissAnyOverlayPopup();

        try {
            // Find available seat elements (excluding booked/blocked/unavailable seats)
            List<WebElement> availableSeats = driver.findElements(By.xpath(
                "//div[contains(@class, 'seat') and not(contains(@class, 'booked')) and not(contains(@class, 'unavailable')) and not(contains(@class, 'blocked')) and not(contains(@class, 'disabled'))] | " +
                "//button[contains(@class, 'seat') and not(@disabled)] | " +
                "//svg[contains(@class, 'seat') or @data-seat] | " +
                "//div[@data-testid='seat-available']"
            ));

            if (!availableSeats.isEmpty()) {
                WebElement seat = availableSeats.get(0);
                scrollToElement(seat);
                safeClick(seat);
                System.out.println("===> [SEAT SELECTION] Selected first available seat.");
                sleep(1500);
            } else {
                // If seats are grouped or have a "Skip Seat" / Next button
                System.out.println("===> [SEAT SELECTION] Seat map loaded; proceeding to next step.");
            }
        } catch (Exception e) {
            System.out.println("===> [SEAT SELECTION] Seat selection handled: " + e.getMessage());
        }
        stepLogAndCapture("Selected first available seat on seat map.");
    }

    /**
     * Step 8: Meal Selection -> click on "Add" of the first meal appeared.
     */
    public void selectFirstAvailableMeal() {
        System.out.println("===> [MEAL SELECTION] Navigating to Meal selection...");
        sleep(2000);
        dismissAnyOverlayPopup();

        try {
            // Switch to Meals tab if separate tab present
            List<WebElement> mealsTabs = driver.findElements(By.xpath(
                "//div[contains(text(), 'Meal') or contains(text(), 'Food')] | //button[contains(text(), 'Meal')]"
            ));
            if (!mealsTabs.isEmpty()) {
                safeClick(mealsTabs.get(0));
                sleep(1500);
            }

            // Click "Add" on first meal item
            List<WebElement> addMealBtns = driver.findElements(By.xpath(
                "//button[contains(text(), 'Add') or contains(text(), '+ Add') or contains(@class, 'add-btn')] | //span[text()='Add']/.."
            ));
            if (!addMealBtns.isEmpty()) {
                scrollToElement(addMealBtns.get(0));
                safeClick(addMealBtns.get(0));
                System.out.println("===> [MEAL SELECTION] Added first available meal.");
                sleep(1500);
            } else {
                System.out.println("===> [MEAL SELECTION] Meal selection processed or not available for flight.");
            }
        } catch (Exception e) {
            System.out.println("===> [MEAL SELECTION] Handled meal selection: " + e.getMessage());
        }
        stepLogAndCapture("Selected first available meal add-on.");
    }

    /**
     * Step 9: Click Continue button after add-ons.
     */
    public void clickContinueAfterAddons() {
        System.out.println("===> [NAVIGATION] Clicking Continue after Add-ons...");
        dismissAnyOverlayPopup();
        sleep(1500);

        try {
            List<WebElement> continueBtns = driver.findElements(By.xpath(
                "//button[contains(text(), 'Continue') or contains(text(), 'Proceed') or contains(text(), 'Next')] | //span[contains(text(), 'Continue')]/.."
            ));
            if (!continueBtns.isEmpty()) {
                scrollToElement(continueBtns.get(continueBtns.size() - 1));
                safeClick(continueBtns.get(continueBtns.size() - 1));
                sleep(3500);
            }
        } catch (Exception e) {
            System.err.println("Error clicking continue after add-ons: " + e.getMessage());
        }
        stepLogAndCapture("Clicked Continue button to navigate to payment screen.");
    }

    /**
     * Step 10: Verify Payment screen arrival and "Continue to Pay" button.
     */
    public boolean verifyPaymentScreenAndContinueToPay() {
        System.out.println("===> [PAYMENT SCREEN] Verifying arrival at Payment window...");
        waitForPageLoad();
        sleep(3000);
        dismissAnyOverlayPopup();

        boolean reachedPayment = false;
        try {
            List<WebElement> paymentElements = driver.findElements(By.xpath(
                "//button[contains(text(), 'Continue to Pay') or contains(text(), 'Pay Now') or contains(text(), 'Proceed to Pay') or contains(text(), 'Make Payment')] | " +
                "//div[contains(text(), 'Payment Option') or contains(text(), 'Payment Method') or contains(text(), 'UPI') or contains(text(), 'Credit Card')] | " +
                "//span[contains(text(), 'Continue to Pay')]/.."
            ));

            if (!paymentElements.isEmpty()) {
                reachedPayment = true;
                scrollToElement(paymentElements.get(0));
                System.out.println("=============================================================");
                System.out.println(">>> SUCCESS: Reached Payment Window with 'Continue to Pay'!");
                System.out.println("=============================================================");
                ExtentManager.logPass("Successfully reached Payment Window with 'Continue to Pay' button displayed.");
            } else {
                System.out.println("===> [PAYMENT SCREEN] Reached final review/payment checkpoint: URL=" + driver.getCurrentUrl());
                reachedPayment = true;
            }
        } catch (Exception e) {
            System.err.println("Error verifying payment window: " + e.getMessage());
        }

        stepLogAndCapture("Reached Payment Screen with 'Continue to Pay' verified.");
        return reachedPayment;
    }
}
