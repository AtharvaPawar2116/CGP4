package com.pages;

import com.parameter.PropertyReader;
import com.utils.ExtentManager;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * Base Page containing shared WebDriver actions, explicit waits,
 * JavaScript executors, and popup handling.
 */
public class BasePage {

    protected WebDriver driver;
    protected WebDriverWait wait;
    protected JavascriptExecutor js;
    protected Actions actions;
    protected int timeoutSeconds;

    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.timeoutSeconds = PropertyReader.getIntProperty("explicitWait", 25);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        this.js = (JavascriptExecutor) driver;
        this.actions = new Actions(driver);
        PageFactory.initElements(driver, this);
    }

    public void waitForPageLoad() {
        try {
            wait.until(webDriver -> js.executeScript("return document.readyState").equals("complete"));
        } catch (Exception ignored) {
        }
    }

    public WebElement waitForVisible(WebElement element) {
        return wait.until(ExpectedConditions.visibilityOf(element));
    }

    public WebElement waitForClickable(WebElement element) {
        return wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public WebElement waitForPresence(By locator) {
        return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
    }

    public void safeClick(WebElement element) {
        try {
            waitForClickable(element);
            element.click();
        } catch (Exception e) {
            try {
                scrollToElement(element);
                element.click();
            } catch (Exception ex) {
                jsClick(element);
            }
        }
    }

    public void safeClick(By locator) {
        try {
            WebElement el = wait.until(ExpectedConditions.elementToBeClickable(locator));
            el.click();
        } catch (Exception e) {
            try {
                WebElement el = driver.findElement(locator);
                jsClick(el);
            } catch (Exception ex) {
                System.err.println("Failed safeClick on locator: " + locator + " - " + ex.getMessage());
            }
        }
    }

    public void jsClick(WebElement element) {
        try {
            js.executeScript("arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});", element);
            js.executeScript("arguments[0].click();", element);
        } catch (Exception e) {
            element.click();
        }
    }

    public void safeType(WebElement element, String text) {
        try {
            waitForVisible(element);
            element.clear();
            element.sendKeys(text);
        } catch (Exception e) {
            try {
                js.executeScript("arguments[0].value = '';", element);
                element.sendKeys(text);
            } catch (Exception ex) {
                js.executeScript("arguments[0].value = arguments[1];", element, text);
            }
        }
    }

    public void scrollToElement(WebElement element) {
        try {
            js.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", element);
            sleep(400);
        } catch (Exception ignored) {
        }
    }

    public boolean isElementDisplayed(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isElementPresent(By locator) {
        try {
            return !driver.findElements(locator).isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    public void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Dismisses common overlay popups, ads, or notification dialogs if present.
     */
    public void dismissAnyOverlayPopup() {
        String[] popupCloseLocators = {
            "//button[contains(@class, 'close') or @aria-label='Close' or @data-testid='modal-close']",
            "//div[contains(@class, 'modal')]//span[contains(text(), '×') or contains(text(), '✕')]",
            "//span[contains(@class, 'close') or contains(@class, 'cross')]",
            "//button[contains(text(), 'Later') or contains(text(), 'Remind Me Later') or contains(text(), 'No Thanks') or contains(text(), 'Skip')]",
            "//div[contains(@class, 'overlay')]//button",
            "//div[@role='dialog']//button"
        };

        for (String xpath : popupCloseLocators) {
            try {
                List<WebElement> closeBtns = driver.findElements(By.xpath(xpath));
                for (WebElement btn : closeBtns) {
                    if (btn.isDisplayed()) {
                        System.out.println("===> [POPUP] Dismissing overlay popup via: " + xpath);
                        jsClick(btn);
                        sleep(500);
                        break;
                    }
                }
            } catch (Exception ignored) {
            }
        }
    }

    public void stepLogAndCapture(String stepMessage) {
        ExtentManager.logStep(stepMessage);
        ExtentManager.attachScreenshot(driver, stepMessage);
    }
}
