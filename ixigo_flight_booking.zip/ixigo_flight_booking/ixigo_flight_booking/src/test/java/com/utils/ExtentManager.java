package com.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.openqa.selenium.WebDriver;

import java.io.File;

/**
 * Manages ExtentReports lifecycle and ThreadLocal ExtentTest logging.
 */
public class ExtentManager {

    private static ExtentReports extent;
    private static final ThreadLocal<ExtentTest> testThread = new ThreadLocal<>();
    private static final String REPORT_DIR = "target/Extent Report/Report";
    private static final String REPORT_PATH = REPORT_DIR + "/index.html";

    public static synchronized ExtentReports getExtentReports() {
        if (extent == null) {
            File dir = new File(REPORT_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            ExtentSparkReporter sparkReporter = new ExtentSparkReporter(REPORT_PATH);
            sparkReporter.config().setReportName("Ixigo Flight Booking Automation Report");
            sparkReporter.config().setDocumentTitle("Ixigo Flight Booking - Test Execution Report");
            sparkReporter.config().setTheme(Theme.STANDARD);
            sparkReporter.config().setEncoding("UTF-8");
            sparkReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");

            extent = new ExtentReports();
            extent.attachReporter(sparkReporter);
            extent.setSystemInfo("Application", "Ixigo Flight Booking");
            extent.setSystemInfo("Environment", "QA / Production");
            extent.setSystemInfo("Author", "QA Automation Engineer");
            extent.setSystemInfo("OS", System.getProperty("os.name"));
            extent.setSystemInfo("Java Version", System.getProperty("java.version"));
        }
        return extent;
    }

    public static ExtentTest createTest(String testName, String description) {
        ExtentTest test = getExtentReports().createTest(testName, description);
        testThread.set(test);
        return test;
    }

    public static ExtentTest getTest() {
        return testThread.get();
    }

    public static void log(Status status, String message) {
        ExtentTest test = getTest();
        if (test != null) {
            test.log(status, message);
        }
    }

    public static void logStep(String stepDescription) {
        System.out.println("===> [STEP] " + stepDescription);
        ExtentTest test = getTest();
        if (test != null) {
            test.log(Status.INFO, "<b>[STEP]</b> " + stepDescription);
        }
    }

    public static void logPass(String message) {
        System.out.println("===> [PASS] " + message);
        ExtentTest test = getTest();
        if (test != null) {
            test.log(Status.PASS, message);
        }
    }

    public static void logFail(String message) {
        System.err.println("===> [FAIL] " + message);
        ExtentTest test = getTest();
        if (test != null) {
            test.log(Status.FAIL, message);
        }
    }

    public static void attachScreenshot(WebDriver driver, String title) {
        ExtentTest test = getTest();
        if (test != null && driver != null) {
            String base64 = Screenshots.captureBase64(driver);
            if (base64 != null && !base64.isEmpty()) {
                test.info(title, MediaEntityBuilder.createScreenCaptureFromBase64String(base64).build());
            }
        }
    }

    public static synchronized void flush() {
        if (extent != null) {
            extent.flush();
        }
    }
}
