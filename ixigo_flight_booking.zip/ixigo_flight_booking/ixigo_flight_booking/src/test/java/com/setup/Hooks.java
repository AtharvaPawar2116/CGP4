package com.setup;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.utils.ExtentManager;
import com.utils.Screenshots;
import org.openqa.selenium.WebDriver;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

/**
 * TestNG Listeners / Hooks for ExtentReports, Logging, and Screenshot capture.
 */
public class Hooks implements ITestListener, ISuiteListener {

    @Override
    public void onStart(ISuite suite) {
        System.out.println("=============================================================");
        System.out.println(">>> Starting Test Suite: " + suite.getName());
        System.out.println("=============================================================");
        ExtentManager.getExtentReports();
    }

    @Override
    public void onFinish(ISuite suite) {
        System.out.println("=============================================================");
        System.out.println(">>> Finished Test Suite: " + suite.getName());
        System.out.println(">>> Flushing Extent Reports to target/Extent Report/Report/index.html");
        System.out.println("=============================================================");
        ExtentManager.flush();
    }

    @Override
    public void onTestStart(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        String description = result.getMethod().getDescription();
        if (description == null || description.isEmpty()) {
            description = "Execution of test method " + testName;
        }
        System.out.println("\n-------------------------------------------------------------");
        System.out.println(">>> [START] Executing Test: " + testName + " | " + description);
        System.out.println("-------------------------------------------------------------");
        ExtentManager.createTest(testName, description);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        System.out.println(">>> [TEST COMPLETED - PASS] " + testName);
        ExtentTest test = ExtentManager.getTest();
        if (test != null) {
            test.log(Status.PASS, "Test passed successfully: " + testName);
            WebDriver driver = SetupDriver.getDriver();
            if (driver != null) {
                ExtentManager.attachScreenshot(driver, "Final State - Pass");
                Screenshots.captureScreenshot(driver, testName + "_PASS");
            }
        }
    }

    @Override
    public void onTestFailure(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        System.err.println(">>> [TEST COMPLETED - FAIL] " + testName + " - " + result.getThrowable().getMessage());
        ExtentTest test = ExtentManager.getTest();
        if (test != null) {
            test.log(Status.FAIL, "Test Failed: " + result.getThrowable().getMessage());
            test.log(Status.FAIL, result.getThrowable());
            WebDriver driver = SetupDriver.getDriver();
            if (driver != null) {
                ExtentManager.attachScreenshot(driver, "Failure State");
                Screenshots.captureScreenshot(driver, testName + "_FAIL");
            }
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        System.out.println(">>> [TEST SKIPPED] " + testName);
        ExtentTest test = ExtentManager.getTest();
        if (test != null) {
            test.log(Status.SKIP, "Test Skipped: " + result.getThrowable());
        }
    }

    @Override
    public void onStart(ITestContext context) {
    }

    @Override
    public void onFinish(ITestContext context) {
    }
}
