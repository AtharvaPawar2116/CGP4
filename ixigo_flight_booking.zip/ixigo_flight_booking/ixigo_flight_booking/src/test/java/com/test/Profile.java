package com.test;

import com.pages.HomePage;
import com.pages.ProfilePage;
import com.pages.SearchPage;
import com.parameter.ExcelReader;
import com.parameter.PropertyReader;
import com.setup.SetupDriver;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.List;
import java.util.Map;

/**
 * End-to-End Flight Booking Test Suite divided into 8 sequential Test Cases
 * as required for Exam / Project Evaluation.
 * 
 * Flow:
 * TC_01: Open Website & Handle Popups
 * TC_02: Enter Mobile for Login & Handle Manual OTP
 * TC_03: Select Flights Module & Search Parameters (1 Adult, DEL -> BOM)
 * TC_04: Search Flights & Filter Air India
 * TC_05: Book First Visible Flight & Choose Standard Fare (No Free Cancellation)
 * TC_06: Fill Traveller Details & Billing Pincode from Excel Sheet
 * TC_07: Confirm Review Window & Handle Free Cancellation Dialog
 * TC_08: Select Seat, Add Meal & Reach Payment Screen ("Continue to Pay")
 */
public class Profile {

    private WebDriver driver;
    private HomePage homePage;
    private SearchPage searchPage;
    private ProfilePage profilePage;

    // Test Data from Excel (Data.xlsx)
    private String title;
    private String firstName;
    private String lastName;
    private String gender;
    private String mobile;
    private String email;
    private String pincode;
    private String address;
    private String state;
    private String city;
    private String fromCity;
    private String toCity;
    private String airline;

    @BeforeClass
    @Parameters({"browser"})
    public void setupSuite(@Optional("") String browser) {
        if (browser == null || browser.trim().isEmpty()) {
            browser = PropertyReader.getProperty("browser", "chrome");
        }
        System.out.println("=============================================================");
        System.out.println(">>> [SETUP] Initializing Browser for Ixigo Suite: " + browser);
        System.out.println("=============================================================");
        driver = SetupDriver.initDriver(browser);
        homePage = new HomePage(driver);
        searchPage = new SearchPage(driver);
        profilePage = new ProfilePage(driver);

        // Load Test Data from Excel Sheet
        ExcelReader excelReader = new ExcelReader("src/test/resources/Exceldata/Data.xlsx");
        List<Map<String, String>> dataList = excelReader.getSheetDataAsMap("TravellerData");
        if (!dataList.isEmpty()) {
            Map<String, String> row = dataList.get(0);
            title = row.getOrDefault("Title", "Mr");
            firstName = row.getOrDefault("FirstName", "Rahul");
            lastName = row.getOrDefault("LastName", "Sharma");
            gender = row.getOrDefault("Gender", "Male");
            mobile = row.getOrDefault("Mobile", "9876543210");
            email = row.getOrDefault("Email", "rahul.sharma@example.com");
            pincode = row.getOrDefault("Pincode", "110001");
            address = row.getOrDefault("Address", "Flat 402, Barakhamba Road");
            state = row.getOrDefault("State", "Delhi");
            city = row.getOrDefault("City", "New Delhi");
            fromCity = row.getOrDefault("FromCity", "DEL");
            toCity = row.getOrDefault("ToCity", "BOM");
            airline = row.getOrDefault("Airline", "Air India");
        } else {
            // Fallback values
            title = "Mr";
            firstName = "Rahul";
            lastName = "Sharma";
            gender = "Male";
            mobile = "9876543210";
            email = "rahul.sharma@example.com";
            pincode = "110001";
            address = "Flat 402, Barakhamba Road";
            state = "Delhi";
            city = "New Delhi";
            fromCity = "DEL";
            toCity = "BOM";
            airline = "Air India";
        }
        System.out.println(">>> [EXCEL DATA LOADED] Traveller: " + title + " " + firstName + " " + lastName + " | Route: " + fromCity + " -> " + toCity);
    }

    @Test(priority = 1, description = "TC_01: Verify Ixigo Homepage loads and handle initial popups")
    public void TC_01_VerifyHomePageAndDismissPopups() {
        System.out.println("\n-------------------------------------------------------------");
        System.out.println(">>> EXECUTING TEST CASE 1: Verify Homepage & Dismiss Popups");
        System.out.println("-------------------------------------------------------------");
        homePage.openUrl();
        String title = driver.getTitle();
        System.out.println("Console Output -> TC_01: Homepage loaded successfully with title: " + title);
        Assert.assertTrue(title != null && !title.isEmpty(), "Homepage title should not be empty.");
        homePage.handleInitialPopup();
        System.out.println("Console Output -> TC_01: Initial promotional popup checked and handled.");
    }

    @Test(priority = 2, dependsOnMethods = {"TC_01_VerifyHomePageAndDismissPopups"}, description = "TC_02: Enter mobile for login and handle manual OTP entry")
    public void TC_02_HandleLoginAndManualOTP() {
        System.out.println("\n-------------------------------------------------------------");
        System.out.println(">>> EXECUTING TEST CASE 2: Login Mobile & Manual OTP Entry");
        System.out.println("-------------------------------------------------------------");
        homePage.handleLogin(mobile);
        System.out.println("Console Output -> TC_02: Mobile number " + mobile + " submitted and manual OTP window completed.");
    }

    @Test(priority = 3, dependsOnMethods = {"TC_02_HandleLoginAndManualOTP"}, description = "TC_03: Select Flights module, One-way, From, To, Date and 1 Adult")
    public void TC_03_SelectFlightModuleAndSearchParameters() {
        System.out.println("\n-------------------------------------------------------------");
        System.out.println(">>> EXECUTING TEST CASE 3: Flight Module & Search Parameters");
        System.out.println("-------------------------------------------------------------");
        homePage.selectFlightsModule();
        System.out.println("Console Output -> TC_03: Selected Flights module.");
        homePage.selectOneWay();
        homePage.enterFromCity(fromCity, "Delhi");
        homePage.enterToCity(toCity, "Mumbai");
        homePage.selectDepartureDate();
        homePage.selectTravellersAndClass(1);
        System.out.println("Console Output -> TC_03: Configured search: One-Way, Origin: " + fromCity + ", Destination: " + toCity + ", Travellers: 1 Adult.");
    }

    @Test(priority = 4, dependsOnMethods = {"TC_03_SelectFlightModuleAndSearchParameters"}, description = "TC_04: Click Search Flights and filter results by Air India")
    public void TC_04_SearchFlightsAndFilterAirIndia() {
        System.out.println("\n-------------------------------------------------------------");
        System.out.println(">>> EXECUTING TEST CASE 4: Search Flights & Filter Air India");
        System.out.println("-------------------------------------------------------------");
        homePage.clickSearchFlights();
        searchPage.waitForFlightResults();
        System.out.println("Console Output -> TC_04: Flight search results loaded.");
        searchPage.filterByAirline(airline);
        System.out.println("Console Output -> TC_04: Applied airline filter: " + airline);
    }

    @Test(priority = 5, dependsOnMethods = {"TC_04_SearchFlightsAndFilterAirIndia"}, description = "TC_05: Book first visible flight and select No Free Cancellation fare")
    public void TC_05_SelectFlightAndBookWithStandardFare() {
        System.out.println("\n-------------------------------------------------------------");
        System.out.println(">>> EXECUTING TEST CASE 5: Book First Visible Flight & Standard Fare");
        System.out.println("-------------------------------------------------------------");
        searchPage.selectFirstVisibleFlightAndBook();
        System.out.println("Console Output -> TC_05: First visible Air India flight selected and booking initiated.");
        profilePage.selectNoFreeCancellation();
        System.out.println("Console Output -> TC_05: Selected 'I don\\'t want free cancellation' radio button.");
    }

    @Test(priority = 6, dependsOnMethods = {"TC_05_SelectFlightAndBookWithStandardFare"}, description = "TC_06: Enter traveller details and billing PIN code from Excel")
    public void TC_06_EnterTravellerAndBillingDetailsFromExcel() {
        System.out.println("\n-------------------------------------------------------------");
        System.out.println(">>> EXECUTING TEST CASE 6: Traveller & Billing Details from Excel");
        System.out.println("-------------------------------------------------------------");
        profilePage.fillTravellerDetails(title, firstName, lastName, gender, mobile, email);
        System.out.println("Console Output -> TC_06: Filled traveller details: " + title + " " + firstName + " " + lastName + " (" + email + ")");
        profilePage.fillBillingDetails(pincode, address, state);
        System.out.println("Console Output -> TC_06: Entered billing address PIN code: " + pincode);
    }

    @Test(priority = 7, dependsOnMethods = {"TC_06_EnterTravellerAndBillingDetailsFromExcel"}, description = "TC_07: Confirm Review Window and handle Free Cancellation popup")
    public void TC_07_ConfirmReviewAndHandleModals() {
        System.out.println("\n-------------------------------------------------------------");
        System.out.println(">>> EXECUTING TEST CASE 7: Review Confirmation & Modals");
        System.out.println("-------------------------------------------------------------");
        profilePage.clickContinue();
        System.out.println("Console Output -> TC_07: Clicked Continue on traveller details form.");
        profilePage.handleReviewWindowAndConfirm();
        System.out.println("Console Output -> TC_07: Handled Review Window confirmation.");
        profilePage.handleFreeCancellationPopup();
        System.out.println("Console Output -> TC_07: Handled Free Cancellation popup with 'No Thanks'.");
    }

    @Test(priority = 8, dependsOnMethods = {"TC_07_ConfirmReviewAndHandleModals"}, description = "TC_08: Select seat, add meal and reach payment window with Continue to Pay")
    public void TC_08_SelectSeatMealAndVerifyPaymentScreen() {
        System.out.println("\n-------------------------------------------------------------");
        System.out.println(">>> EXECUTING TEST CASE 8: Seat, Meal Add-on & Payment Screen Verification");
        System.out.println("-------------------------------------------------------------");
        profilePage.selectFirstAvailableSeat();
        System.out.println("Console Output -> TC_08: Selected first available seat on the seat map.");
        profilePage.selectFirstAvailableMeal();
        System.out.println("Console Output -> TC_08: Selected first available meal add-on.");
        profilePage.clickContinueAfterAddons();
        System.out.println("Console Output -> TC_08: Clicked Continue after add-on selections.");
        boolean reachedPayment = profilePage.verifyPaymentScreenAndContinueToPay();
        System.out.println("Console Output -> TC_08: Verified arrival at Payment Screen with 'Continue to Pay'. FLOW COMPLETE.");
        Assert.assertTrue(reachedPayment, "Should successfully reach payment window with 'Continue to Pay'");
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        System.out.println("=============================================================");
        System.out.println(">>> [CLEANUP] Closing WebDriver session.");
        System.out.println("=============================================================");
        SetupDriver.quitDriver();
    }
}
