package com.parameter.DataProvider;

import com.parameter.ExcelReader;
import org.testng.annotations.DataProvider;

public class FlightDataProvider {

    @DataProvider(name = "travellerExcelData")
    public static Object[][] getTravellerData() {
        ExcelReader excelReader = new ExcelReader("src/test/resources/Exceldata/Data.xlsx");
        return excelReader.getSheetData("TravellerData");
    }

    @DataProvider(name = "singleTravellerData")
    public static Object[][] getSingleTravellerData() {
        ExcelReader excelReader = new ExcelReader("src/test/resources/Exceldata/Data.xlsx");
        Object[][] all = excelReader.getSheetData("TravellerData");
        if (all.length > 0) {
            return new Object[][] { all[0] };
        }
        return new Object[][] {
            {"Mr", "Rahul", "Sharma", "Male", "9876543210", "rahul.sharma@example.com", "110001", "Flat 402, Barakhamba Road", "Delhi", "New Delhi", "DEL", "BOM", "Air India"}
        };
    }
}
