package com.parameter;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Utility class to read Excel (.xlsx) files using Apache POI.
 */
public class ExcelReader {

    private String filePath;

    public ExcelReader(String filePath) {
        this.filePath = filePath;
    }

    public ExcelReader() {
        this.filePath = "src/test/resources/Exceldata/Data.xlsx";
    }

    /**
     * Reads all rows from specified sheet into a 2D Object array (for TestNG @DataProvider).
     */
    public Object[][] getSheetData(String sheetName) {
        Object[][] data = null;
        File file = new File(filePath);
        if (!file.exists()) {
            System.err.println("Excel file not found at: " + filePath);
            return new Object[0][0];
        }

        try (FileInputStream fis = new FileInputStream(file);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                System.err.println("Sheet '" + sheetName + "' not found in Excel file: " + filePath);
                return new Object[0][0];
            }

            int rowCount = sheet.getLastRowNum(); // 0-based, last row index
            if (rowCount < 1) {
                return new Object[0][0];
            }

            Row headerRow = sheet.getRow(0);
            int colCount = headerRow.getLastCellNum();

            data = new Object[rowCount][colCount];
            DataFormatter formatter = new DataFormatter();

            for (int i = 1; i <= rowCount; i++) {
                Row row = sheet.getRow(i);
                for (int j = 0; j < colCount; j++) {
                    if (row == null) {
                        data[i - 1][j] = "";
                    } else {
                        Cell cell = row.getCell(j);
                        data[i - 1][j] = (cell == null) ? "" : formatter.formatCellValue(cell).trim();
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading Excel data: " + e.getMessage());
        }
        return data;
    }

    /**
     * Reads sheet data as a List of Maps (Column Header -> Cell Value).
     */
    public List<Map<String, String>> getSheetDataAsMap(String sheetName) {
        List<Map<String, String>> list = new ArrayList<>();
        File file = new File(filePath);
        if (!file.exists()) {
            return list;
        }

        try (FileInputStream fis = new FileInputStream(file);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                return list;
            }

            Row headerRow = sheet.getRow(0);
            if (headerRow == null) {
                return list;
            }

            int colCount = headerRow.getLastCellNum();
            List<String> headers = new ArrayList<>();
            DataFormatter formatter = new DataFormatter();

            for (int c = 0; c < colCount; c++) {
                Cell cell = headerRow.getCell(c);
                headers.add(cell == null ? "COL_" + c : formatter.formatCellValue(cell).trim());
            }

            int rowCount = sheet.getLastRowNum();
            for (int r = 1; r <= rowCount; r++) {
                Row row = sheet.getRow(r);
                if (row == null) continue;
                Map<String, String> rowMap = new HashMap<>();
                for (int c = 0; c < colCount; c++) {
                    Cell cell = row.getCell(c);
                    String val = (cell == null) ? "" : formatter.formatCellValue(cell).trim();
                    rowMap.put(headers.get(c), val);
                }
                list.add(rowMap);
            }
        } catch (IOException e) {
            System.err.println("Error reading Excel map data: " + e.getMessage());
        }
        return list;
    }

    /**
     * Get specific cell value by row and column index.
     */
    public String getCellData(String sheetName, int rowNum, int colNum) {
        try (FileInputStream fis = new FileInputStream(new File(filePath));
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) return "";
            Row row = sheet.getRow(rowNum);
            if (row == null) return "";
            Cell cell = row.getCell(colNum);
            DataFormatter formatter = new DataFormatter();
            return (cell == null) ? "" : formatter.formatCellValue(cell).trim();
        } catch (Exception e) {
            return "";
        }
    }
}
