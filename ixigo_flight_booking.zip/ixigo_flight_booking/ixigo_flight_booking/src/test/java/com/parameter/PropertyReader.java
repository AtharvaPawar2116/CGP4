package com.parameter;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Utility class to read properties from ProfileData.properties.
 */
public class PropertyReader {

    private static Properties properties;
    private static final String DEFAULT_PROPERTIES_PATH = "src/test/resources/PropertyData/ProfileData.properties";

    static {
        loadProperties(DEFAULT_PROPERTIES_PATH);
    }

    public static void loadProperties(String filePath) {
        properties = new Properties();
        try (InputStream is = new FileInputStream(filePath)) {
            properties.load(is);
        } catch (IOException e) {
            System.err.println("Failed to load property file at: " + filePath + " - " + e.getMessage());
        }
    }

    public static String getProperty(String key) {
        if (properties == null) {
            loadProperties(DEFAULT_PROPERTIES_PATH);
        }
        return properties.getProperty(key);
    }

    public static String getProperty(String key, String defaultValue) {
        if (properties == null) {
            loadProperties(DEFAULT_PROPERTIES_PATH);
        }
        return properties.getProperty(key, defaultValue);
    }

    public static int getIntProperty(String key, int defaultValue) {
        String val = getProperty(key);
        if (val == null || val.trim().isEmpty()) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(val.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    public static boolean getBooleanProperty(String key, boolean defaultValue) {
        String val = getProperty(key);
        if (val == null || val.trim().isEmpty()) {
            return defaultValue;
        }
        return Boolean.parseBoolean(val.trim());
    }
}
