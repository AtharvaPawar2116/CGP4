package com.setup;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import com.parameter.PropertyReader;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SetupDriver {

    private static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();
    public static WebDriver driver;

    public static WebDriver getDriver() {
        return tlDriver.get() != null ? tlDriver.get() : driver;
    }

    public void launchBrowser(String browser) {

        WebDriver localDriver;

        if (browser.equalsIgnoreCase("chrome")) {

            WebDriverManager.chromedriver().setup();
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--remote-allow-origins=*");
            options.addArguments("--disable-notifications");
            options.addArguments("--start-maximized");
            options.addArguments("--disable-blink-features=AutomationControlled");
            localDriver = new ChromeDriver(options);

        } else if (browser.equalsIgnoreCase("edge")) {

            WebDriverManager.edgedriver().setup();
            EdgeOptions options = new EdgeOptions();
            options.addArguments("--remote-allow-origins=*");
            options.addArguments("--disable-notifications");
            options.addArguments("--start-maximized");
            localDriver = new EdgeDriver(options);

        } else if (browser.equalsIgnoreCase("firefox")) {

            WebDriverManager.firefoxdriver().setup();
            FirefoxOptions options = new FirefoxOptions();
            options.addArguments("--start-maximized");
            localDriver = new FirefoxDriver(options);

        } else {

            throw new IllegalArgumentException("Invalid Browser: " + browser);

        }

        tlDriver.set(localDriver);
        driver = localDriver;

        localDriver.manage().window().maximize();
        localDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
        localDriver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));

        String url = PropertyReader.getProperty("url");
        if (url == null || url.trim().isEmpty()) {
            url = "https://www.ixigo.com/flights";
        }
        localDriver.get(url);
    }

    public void closeBrowser() {

        WebDriver currentDriver = getDriver();
        if (currentDriver != null) {
            try {
                currentDriver.quit();
            } catch (Exception ignored) {
            }
        }
        tlDriver.remove();
        driver = null;

    }

}