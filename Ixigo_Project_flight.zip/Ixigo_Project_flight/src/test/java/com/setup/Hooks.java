package com.setup;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

public class Hooks extends SetupDriver {

    @Parameters("browser")
    @BeforeClass
    public void setUp(String browser) {

        launchBrowser(browser);

    }

    @AfterClass
    public void tearDown() {

        closeBrowser();

    }

}