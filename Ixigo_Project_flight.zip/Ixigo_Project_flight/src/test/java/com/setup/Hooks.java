package com.setup;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

public class Hooks extends SetupDriver {

    @Parameters("browser")
    @BeforeClass
    public void setUp(@Optional("chrome") String browser) {

        launchBrowser(browser);

    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {

        closeBrowser();

    }

}