package com.test;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pages.FlightListPage;
import com.pages.FlightPassengerPage;
import com.pages.FlightSearchPage;
import com.pages.HomePage;
import com.pages.LoginPage;
import com.parameter.DataProviderClass;
import com.setup.Hooks;

@Listeners(com.utils.ExtentListener.class)
public class FlightBookingTest extends Hooks {

    HomePage home;
    LoginPage login;
    FlightSearchPage search;
    FlightListPage flight;
    FlightPassengerPage passenger;

    String mobile;
    String from;
    String to;
    String name;
    String age;

    @BeforeClass
    public void initializePages() {

        home = new HomePage(driver);
        login = new LoginPage(driver);
        search = new FlightSearchPage(driver);
        flight = new FlightListPage(driver);
        passenger = new FlightPassengerPage(driver);
    }

    @Test(priority = 1, dataProvider = "FlightData", dataProviderClass = DataProviderClass.class)
    public void getTestData(String mobile, String from,
                            String to, String name, String age) {

        this.mobile = mobile;
        this.from = from;
        this.to = to;
        this.name = name;
        this.age = age;
    }

    @Test(priority = 2, description = "TC_1: Search one way flight with valid details and verify results")
    public void TC_1_searchOneWayFlightValidDetails() {
    	//Close popup if present - handles iframe
    	home.closeCleverTapPopupIfPresent();

        Assert.assertTrue(home.isHomePageDisplayed(), "Home page is not displayed");

        home.clickFlights();

        search.selectOneWay();

        search.enterLeavingFrom(from);

        search.enterGoingTo(to);

        search.selectDepartureDate();

        Assert.assertTrue(search.isSearchButtonDisplayed(), "Search button is not displayed");

        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Search results are not displayed for valid one-way flight");

        System.out.println("TC_1 Passed: One way flight search verified successfully.");
    }

    @Test(priority = 3, description = "TC_2: Search round trip flight with valid details and verify results")
    public void TC_2_searchRoundTripFlightValidDetails() {

        driver.get("https://www.ixigo.com");
        home.closeCleverTapPopupIfPresent();

        home.clickFlights();

        search.selectRoundTrip();

        search.enterLeavingFrom(from);

        search.enterGoingTo(to);

        search.selectDepartureDate();

        search.selectReturnDate();

        Assert.assertTrue(search.isSearchButtonDisplayed(), "Search button is not displayed");

        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Search results are not displayed for valid round-trip flight");

        System.out.println("TC_2 Passed: Round trip flight search verified successfully.");
    }

    @Test(priority = 4, description = "TC_3: Verify error message when source city is not entered")
    public void TC_3_verifyErrorMissingSourceCity() {

        driver.get("https://www.ixigo.com");
        home.closeCleverTapPopupIfPresent();

        home.clickFlights();

        search.clearLeavingFrom();

        search.enterGoingTo(to);

        search.clickSearch();

        Assert.assertTrue(search.isErrorMessageDisplayed(), "Error message was not displayed when source city was omitted");

        System.out.println("TC_3 Passed: Error message verified when source city is missing. Message: " + search.getErrorMessage());
    }

    @Test(priority = 5, description = "TC_4: Verify error message when source and destination are the same")
    public void TC_4_verifyErrorSameSourceAndDestination() {

        driver.get("https://www.ixigo.com");
        home.closeCleverTapPopupIfPresent();

        home.clickFlights();

        search.enterLeavingFrom(from);

        search.enterGoingTo(from);

        search.clickSearch();

        Assert.assertTrue(search.isErrorMessageDisplayed(), "Error message was not displayed for identical source & destination");

        System.out.println("TC_4 Passed: Error message verified when source and destination are the same.");
    }

    @Test(priority = 6, description = "TC_5: Verify past date selection is restricted")
    public void TC_5_verifyPastDateRestricted() {

        driver.get("https://www.ixigo.com");
        home.closeCleverTapPopupIfPresent();

        home.clickFlights();

        boolean isPastRestricted = search.isPastDateDisabled();

        Assert.assertTrue(isPastRestricted, "Past dates are not restricted in the departure calendar");

        System.out.println("TC_5 Passed: Past date selection is restricted successfully.");
    }

    @Test(priority = 7, description = "TC_6: Verify sorting by lowest price updates search results")
    public void TC_6_verifySortingByLowestPrice() {

        driver.get("https://www.ixigo.com");
        home.closeCleverTapPopupIfPresent();

        home.clickFlights();

        search.selectOneWay();

        search.enterLeavingFrom(from);

        search.enterGoingTo(to);

        search.selectDepartureDate();

        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Search results not displayed");

        flight.sortByPrice();

        Assert.assertTrue(flight.isSortedByPrice(), "Flight search results are not sorted by lowest price");

        System.out.println("TC_6 Passed: Sorting by lowest price verified successfully.");
    }

    @Test(priority = 8, description = "TC_7: Sort fastest flight to appear first in the sort by")
    public void TC_7_verifySortingByFastestFlight() {

        driver.get("https://www.ixigo.com");
        home.closeCleverTapPopupIfPresent();

        home.clickFlights();

        search.selectOneWay();

        search.enterLeavingFrom(from);

        search.enterGoingTo(to);

        search.selectDepartureDate();

        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Search results not displayed");

        flight.sortByFastest();

        Assert.assertTrue(flight.isSortedByFastest(), "Flight search results are not sorted by fastest flight duration");

        System.out.println("TC_7 Passed: Sort by fastest flight verified successfully.");
    }

    @Test(priority = 9, description = "TC_8: Sort flight search results by earliest departure")
    public void TC_8_verifySortingByEarliestDeparture() {

        driver.get("https://www.ixigo.com");
        home.closeCleverTapPopupIfPresent();

        home.clickFlights();

        search.selectOneWay();

        search.enterLeavingFrom(from);

        search.enterGoingTo(to);

        search.selectDepartureDate();

        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Search results not displayed");

        flight.sortByEarliestDeparture();

        Assert.assertTrue(flight.isSortedByEarliestDeparture(), "Flight search results are not sorted by earliest departure time");

        System.out.println("TC_8 Passed: Sort by earliest departure verified successfully.");
    }

}
