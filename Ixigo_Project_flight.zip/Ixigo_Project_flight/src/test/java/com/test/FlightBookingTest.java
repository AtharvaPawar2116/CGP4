package com.test;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pages.FlightListPage;
import com.pages.FlightPassengerPage;
import com.pages.FlightSearchPage;
import com.pages.HomePage;
import com.pages.LoginPage;
import com.parameter.DataProviderClass;
import com.setup.Hooks;

@Listeners(com.utils.ExtentListener.class)
public class FlightBookingTest extends Hooks {

    private HomePage home;
    private LoginPage login;
    private FlightSearchPage search;
    private FlightListPage flight;
    private FlightPassengerPage passenger;

    private String mobile = "7816013123";
    private String from = "DEL";
    private String to = "BOM";
    private String name = "Sairam";
    private String age = "22";

    @BeforeClass
    public void initializePages() {
        home = new HomePage(getDriver());
        login = new LoginPage(getDriver());
        search = new FlightSearchPage(getDriver());
        flight = new FlightListPage(getDriver());
        passenger = new FlightPassengerPage(getDriver());
    }

    @BeforeMethod
    public void ensureFlightPageLoaded() {
        if (getDriver() != null) {
            home = new HomePage(getDriver());
            login = new LoginPage(getDriver());
            search = new FlightSearchPage(getDriver());
            flight = new FlightListPage(getDriver());
            passenger = new FlightPassengerPage(getDriver());
        }
    }

    @Test(priority = 1, dataProvider = "FlightData", dataProviderClass = DataProviderClass.class, description = "Load test data from Excel")
    public void getTestData(String mobile, String from,
                            String to, String name, String age) {

        if (mobile != null && !mobile.trim().isEmpty()) this.mobile = mobile.trim();
        if (from != null && !from.trim().isEmpty()) this.from = from.trim();
        if (to != null && !to.trim().isEmpty()) this.to = to.trim();
        if (name != null && !name.trim().isEmpty()) this.name = name.trim();
        if (age != null && !age.trim().isEmpty()) this.age = age.trim();

        System.out.println("LOG: Test Data successfully loaded -> Mobile: " + this.mobile + ", From: " + this.from + ", To: " + this.to + ", Name: " + this.name + ", Age: " + this.age);
    }

    @Test(priority = 2, description = "TC_1: Verify login modal and user mobile entry")
    public void TC_1_verifyLoginFlow() {
        System.out.println("\n--- Starting TC_1: Login Flow & User Verification ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        System.out.println("LOG: Opening Login Modal");
        login.openLoginModal();

        System.out.println("LOG: Entering User Mobile Number: " + mobile);
        login.enterMobileNumber(mobile);

        System.out.println("LOG: Submitting Login / Continue");
        login.clickContinue();

        login.switchToDefaultContent();
        Assert.assertTrue(login.isLoginSuccessful(), "Login flow failed or page corrupted");
        System.out.println("LOG: TC_1 Passed - Login flow initiated and verified successfully.");
    }

    @Test(priority = 3, description = "TC_2: Search one way flight with valid details and verify results")
    public void TC_2_searchOneWayFlightValidDetails() {
        System.out.println("\n--- Starting TC_2: One Way Flight Search ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        Assert.assertTrue(home.isHomePageDisplayed(), "Home page is not displayed");

        System.out.println("LOG: Selecting One Way Tab");
        search.selectOneWay();

        System.out.println("LOG: Entering Origin: " + from);
        search.enterLeavingFrom(from);

        System.out.println("LOG: Entering Destination: " + to);
        search.enterGoingTo(to);

        System.out.println("LOG: Selecting Departure Date");
        search.selectDepartureDate();

        Assert.assertTrue(search.isSearchButtonDisplayed(), "Search button is not displayed");

        System.out.println("LOG: Clicking Search Button");
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Search results are not displayed for valid one-way flight");

        System.out.println("LOG: TC_2 Passed - One way flight search verified successfully.");
    }

    @Test(priority = 4, description = "TC_3: Search round trip flight with valid details and verify results")
    public void TC_3_searchRoundTripFlightValidDetails() {
        System.out.println("\n--- Starting TC_3: Round Trip Flight Search ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        System.out.println("LOG: Selecting Round Trip Tab");
        search.selectRoundTrip();

        System.out.println("LOG: Entering Origin: " + from);
        search.enterLeavingFrom(from);

        System.out.println("LOG: Entering Destination: " + to);
        search.enterGoingTo(to);

        System.out.println("LOG: Selecting Departure Date");
        search.selectDepartureDate();

        System.out.println("LOG: Selecting Return Date");
        search.selectReturnDate();

        Assert.assertTrue(search.isSearchButtonDisplayed(), "Search button is not displayed");

        System.out.println("LOG: Clicking Search Button");
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Search results are not displayed for valid round-trip flight");

        System.out.println("LOG: TC_3 Passed - Round trip flight search verified successfully.");
    }

    @Test(priority = 5, description = "TC_4: Full end-to-end flight booking and passenger details entry")
    public void TC_4_flightBookingAndPassengerDetailsEntry() {
        System.out.println("\n--- Starting TC_4: Flight Selection and Passenger Details Entry ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        System.out.println("LOG: Searching flight for booking: " + from + " -> " + to);
        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Flight results not displayed");

        System.out.println("LOG: Selecting first available flight");
        flight.selectFlight(0);

        System.out.println("LOG: Entering Passenger Details -> Name: " + name + ", Age: " + age + ", Gender: Male");
        passenger.enterPassengerName(name);
        passenger.enterPassengerAge(age);
        passenger.selectGender();

        System.out.println("LOG: Handling Insurance / Travel Add-ons");
        passenger.selectInsurance();

        Assert.assertTrue(passenger.isPassengerPageDisplayed(), "Passenger details entry verified");
        System.out.println("LOG: TC_4 Passed - Flight selected and passenger details entered successfully.");
    }

    @Test(priority = 6, description = "TC_5: Verify error message when source city is not entered")
    public void TC_5_verifyErrorMissingSourceCity() {
        System.out.println("\n--- Starting TC_5: Verify Missing Source City Error ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        System.out.println("LOG: Clearing Source City and entering destination");
        search.clearLeavingFrom();
        search.enterGoingTo(to);
        search.clickSearch();

        Assert.assertTrue(search.isErrorMessageDisplayed(), "Error message was not displayed when source city was omitted");

        System.out.println("LOG: TC_5 Passed - Error message verified when source city is missing. Message: " + search.getErrorMessage());
    }

    @Test(priority = 7, description = "TC_6: Verify error message when source and destination are the same")
    public void TC_6_verifyErrorSameSourceAndDestination() {
        System.out.println("\n--- Starting TC_6: Verify Same Source & Destination Error ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        System.out.println("LOG: Entering identical source & destination: " + from);
        search.enterLeavingFrom(from);
        search.enterGoingTo(from);
        search.clickSearch();

        Assert.assertTrue(search.isErrorMessageDisplayed(), "Error message was not displayed for identical source & destination");

        System.out.println("LOG: TC_6 Passed - Error message verified when source and destination are the same.");
    }

    @Test(priority = 8, description = "TC_7: Verify past date selection is restricted")
    public void TC_7_verifyPastDateRestricted() {
        System.out.println("\n--- Starting TC_7: Verify Past Date Restriction ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        boolean isPastRestricted = search.isPastDateDisabled();

        Assert.assertTrue(isPastRestricted, "Past dates are not restricted in the departure calendar");

        System.out.println("LOG: TC_7 Passed - Past date selection is restricted successfully.");
    }

    @Test(priority = 9, description = "TC_8: Verify sorting by lowest price updates search results")
    public void TC_8_verifySortingByLowestPrice() {
        System.out.println("\n--- Starting TC_8: Sorting by Lowest Price ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Search results not displayed");

        System.out.println("LOG: Clicking Sort by Lowest Price / Cheapest");
        flight.sortByPrice();

        Assert.assertTrue(flight.isSortedByPrice(), "Flight search results are not sorted by lowest price");

        System.out.println("LOG: TC_8 Passed - Sorting by lowest price verified successfully.");
    }

    @Test(priority = 10, description = "TC_9: Sort fastest flight to appear first in the sort by")
    public void TC_9_verifySortingByFastestFlight() {
        System.out.println("\n--- Starting TC_9: Sorting by Fastest Duration ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Search results not displayed");

        System.out.println("LOG: Clicking Sort by Fastest Flight");
        flight.sortByFastest();

        Assert.assertTrue(flight.isSortedByFastest(), "Flight search results are not sorted by fastest flight duration");

        System.out.println("LOG: TC_9 Passed - Sort by fastest flight verified successfully.");
    }

    @Test(priority = 11, description = "TC_10: Sort flight search results by earliest departure")
    public void TC_10_verifySortingByEarliestDeparture() {
        System.out.println("\n--- Starting TC_10: Sorting by Earliest Departure ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Search results not displayed");

        System.out.println("LOG: Clicking Sort by Earliest Departure");
        flight.sortByEarliestDeparture();

        Assert.assertTrue(flight.isSortedByEarliestDeparture(), "Flight search results are not sorted by earliest departure time");

        System.out.println("LOG: TC_10 Passed - Sort by earliest departure verified successfully.");
    }

}
