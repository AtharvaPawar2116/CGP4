package com.test;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pages.FlightListPage;
import com.pages.FlightPassengerPage;
import com.pages.FlightSearchPage;
import com.pages.HomePage;
import com.pages.LoginPage;
import com.parameter.DataProviderClass;
import com.setup.Hooks;

@Listeners(com.utils.ExtentListener.class)
public class FlightBookingTest extends Hooks {

    private HomePage home;
    private LoginPage login;
    private FlightSearchPage search;
    private FlightListPage flight;
    private FlightPassengerPage passenger;

    private String mobile = "7816013123";
    private String from = "BOM";
    private String to = "DEL";
    private String name = "Atharva Pawar";
    private String age = "24";

    @BeforeClass
    public void initializePages() {
        home = new HomePage(getDriver());
        login = new LoginPage(getDriver());
        search = new FlightSearchPage(getDriver());
        flight = new FlightListPage(getDriver());
        passenger = new FlightPassengerPage(getDriver());
    }

    @BeforeMethod
    public void ensureFlightPageLoaded() {
        if (getDriver() != null) {
            home = new HomePage(getDriver());
            login = new LoginPage(getDriver());
            search = new FlightSearchPage(getDriver());
            flight = new FlightListPage(getDriver());
            passenger = new FlightPassengerPage(getDriver());
        }
    }

    @Test(priority = 1, dataProvider = "FlightData", dataProviderClass = DataProviderClass.class, description = "Load test data from Data Provider")
    public void getTestData(String mobile, String from,
                            String to, String name, String age) {

        if (mobile != null && !mobile.trim().isEmpty()) this.mobile = mobile.trim();
        if (from != null && !from.trim().isEmpty()) this.from = from.trim();
        if (to != null && !to.trim().isEmpty()) this.to = to.trim();
        if (name != null && !name.trim().isEmpty()) this.name = name.trim();
        if (age != null && !age.trim().isEmpty()) this.age = age.trim();

        System.out.println("LOG: Test Data successfully loaded -> Mobile: " + this.mobile + ", From: " + this.from + ", To: " + this.to + ", Name: " + this.name + ", Age: " + this.age);
    }

    @Test(priority = 2, description = "TC_00: Validate login flow with mobile entry and manual OTP support")
    public void TC_Ixigo_Flight_00_LoginFlow() {
        System.out.println("\n--- Starting TC_00: Login Flow & User Verification ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        System.out.println("LOG: Opening Login Modal");
        login.openLoginModal();

        System.out.println("LOG: Entering User Mobile Number: " + mobile);
        login.enterMobileNumber(mobile);

        System.out.println("LOG: Submitting Login / Continue");
        login.clickContinue();

        login.waitForManualOTPEntry(2);
        login.switchToDefaultContent();
        Assert.assertTrue(login.isLoginSuccessful(), "Login flow failed or page corrupted");
        System.out.println("LOG: TC_00 Passed - Login flow initiated and verified successfully.");
    }

    @Test(priority = 3, description = "TC_Ixigo_Flight_01: Validate flight search with valid source, destination, and future date")
    public void TC_Ixigo_Flight_01_searchOneWayFlightValidDetails() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_01: One Way Flight Search (Mumbai -> Delhi) ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        Assert.assertTrue(home.isHomePageDisplayed(), "Home page is not displayed");

        System.out.println("LOG: Selecting One-Way trip");
        search.selectOneWay();

        System.out.println("LOG: Entering Source City: " + from);
        search.enterLeavingFrom(from);

        System.out.println("LOG: Entering Destination City: " + to);
        search.enterGoingTo(to);

        System.out.println("LOG: Selecting Future Departure Date");
        search.selectDepartureDate();

        Assert.assertTrue(search.isSearchButtonDisplayed(), "Search button is not displayed");

        System.out.println("LOG: Clicking Search Button");
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Flight search results should be displayed successfully");
        System.out.println("LOG: TC_Ixigo_Flight_01 Passed - Flight search results displayed successfully.");
    }

    @Test(priority = 4, description = "TC_Ixigo_Flight_02: Validate same source and destination")
    public void TC_Ixigo_Flight_02_sameSourceAndDestination() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_02: Same Source and Destination Validation ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        System.out.println("LOG: Selecting Source: " + from + " and Destination: " + from);
        search.enterLeavingFrom(from);
        search.enterGoingTo(from);
        search.clickSearch();

        Assert.assertTrue(search.isErrorMessageDisplayed(), "Appropriate error message should be displayed for same source and destination");
        System.out.println("LOG: TC_Ixigo_Flight_02 Passed - Appropriate error message verified.");
    }

    @Test(priority = 5, description = "TC_Ixigo_Flight_03: Validate round trip search with valid details")
    public void TC_Ixigo_Flight_03_roundTripSearchValidDetails() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_03: Round Trip Search (Mumbai -> Delhi) ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        System.out.println("LOG: Selecting Round Trip");
        search.selectRoundTrip();

        System.out.println("LOG: Entering Source: " + from + ", Destination: " + to);
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);

        System.out.println("LOG: Selecting Departure and Return Dates");
        search.selectDepartureDate();
        search.selectReturnDate();

        Assert.assertTrue(search.isSearchButtonDisplayed(), "Search button is not displayed");
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Round trip flights should be displayed");
        System.out.println("LOG: TC_Ixigo_Flight_03 Passed - Round trip flights displayed successfully.");
    }

    @Test(priority = 6, description = "TC_Ixigo_Flight_04: Validate return date before departure date")
    public void TC_Ixigo_Flight_04_returnDateBeforeDepartureRestricted() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_04: Return Date Before Departure Restriction ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        boolean isRestricted = search.isReturnDateBeforeDepartureRestricted();
        Assert.assertTrue(isRestricted, "Return dates before departure date should be restricted/disabled");
        System.out.println("LOG: TC_Ixigo_Flight_04 Passed - Return date before departure restriction verified.");
    }

    @Test(priority = 7, description = "TC_Ixigo_Flight_05: Validate Adult passenger selection")
    public void TC_Ixigo_Flight_05_adultPassengerSelection() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_05: Adult Passenger Selection (Adults: 3) ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        System.out.println("LOG: Selecting 3 Adult passengers");
        search.selectTravellers(3);

        String travellerText = search.getTravellerCountText();
        Assert.assertNotNull(travellerText, "Traveller count should be updated");
        System.out.println("LOG: TC_Ixigo_Flight_05 Passed - Traveller count updated successfully: " + travellerText);
    }

    @Test(priority = 8, description = "TC_Ixigo_Flight_06: Validate maximum traveller limit")
    public void TC_Ixigo_Flight_06_maximumTravellerLimit() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_06: Maximum Traveller Limit Validation ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        boolean maxLimitEnforced = search.isMaxTravellerLimitEnforced();
        Assert.assertTrue(maxLimitEnforced, "System should allow only supported passenger limit (max 9)");
        System.out.println("LOG: TC_Ixigo_Flight_06 Passed - Maximum traveller limit enforced successfully.");
    }

    @Test(priority = 9, description = "TC_Ixigo_Flight_07: Validate Airline filter")
    public void TC_Ixigo_Flight_07_airlineFilter() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_07: Airline Filter (IndiGo) ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Flight results not displayed");

        System.out.println("LOG: Applying Airline Filter: IndiGo");
        flight.applyAirlineFilter("IndiGo");

        Assert.assertTrue(flight.isOnlyAirlineDisplayed("IndiGo"), "Only IndiGo flights should be displayed");
        System.out.println("LOG: TC_Ixigo_Flight_07 Passed - IndiGo Airline filter verified successfully.");
    }

    @Test(priority = 10, description = "TC_Ixigo_Flight_08: Validate Non-stop filter")
    public void TC_Ixigo_Flight_08_nonStopFilter() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_08: Non-stop Filter ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Flight results not displayed");

        System.out.println("LOG: Applying Non-stop filter");
        flight.applyNonStopFilter();

        Assert.assertTrue(flight.isNonStopFilterApplied(), "Only non-stop flights should appear");
        System.out.println("LOG: TC_Ixigo_Flight_08 Passed - Non-stop filter verified successfully.");
    }

    @Test(priority = 11, description = "TC_Ixigo_Flight_09: Validate Price filter")
    public void TC_Ixigo_Flight_09_priceFilter() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_09: Price Filter ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Flight results not displayed");

        System.out.println("LOG: Applying Price range filter");
        flight.applyPriceFilter();

        Assert.assertTrue(flight.isFlightAvailable(), "Flights within selected range should appear");
        System.out.println("LOG: TC_Ixigo_Flight_09 Passed - Price filter verified successfully.");
    }

    @Test(priority = 12, description = "TC_Ixigo_Flight_10: Validate sorting by lowest price")
    public void TC_Ixigo_Flight_10_sortingByLowestPrice() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_10: Sorting by Lowest Price ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Flight results not displayed");

        System.out.println("LOG: Sorting by Lowest Fare");
        flight.sortByPrice();

        Assert.assertTrue(flight.isSortedByPrice(), "Flights should be arranged in ascending fare order");
        System.out.println("LOG: TC_Ixigo_Flight_10 Passed - Sorting by lowest price verified successfully.");
    }

    @Test(priority = 13, description = "TC_Ixigo_Flight_11: Validating sorting by earliest departure")
    public void TC_Ixigo_Flight_11_sortingByEarliestDeparture() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_11: Sorting by Earliest Departure Time ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Flight results not displayed");

        System.out.println("LOG: Sorting by Earliest Departure Time");
        flight.sortByEarliestDeparture();

        Assert.assertTrue(flight.isSortedByEarliestDeparture(), "Results should be sorted by earliest departure time");
        System.out.println("LOG: TC_Ixigo_Flight_11 Passed - Sorting by earliest departure verified successfully.");
    }

    @Test(priority = 14, description = "TC_Ixigo_Flight_12: Validate successful booking flow")
    public void TC_Ixigo_Flight_12_successfulBookingFlow() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_12: Successful Booking Flow ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        Assert.assertTrue(flight.isFlightAvailable(), "Flight results not displayed");

        System.out.println("LOG: Selecting flight and clicking Book");
        flight.selectFlight(0);

        System.out.println("LOG: Entering passenger details -> Name: " + name + ", Age: " + age + ", Gender: Male");
        passenger.enterPassengerName(name);
        passenger.enterPassengerAge(age);
        passenger.selectGender();
        passenger.selectInsurance();

        Assert.assertTrue(passenger.isPassengerPageDisplayed(), "Booking page should be displayed");
        System.out.println("LOG: TC_Ixigo_Flight_12 Passed - Successful booking flow verified.");
    }

    @Test(priority = 15, description = "TC_Ixigo_Flight_13: Validate mandatory traveller details")
    public void TC_Ixigo_Flight_13_mandatoryTravellerDetails() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_13: Mandatory Traveller Details (Blank Name) ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        flight.selectFlight(0);

        System.out.println("LOG: Leaving passenger name blank and attempting to continue");
        passenger.clearPassengerName();
        passenger.clickContinue();

        Assert.assertTrue(passenger.isValidationErrorDisplayed(), "Validation error should be displayed when passenger name is blank");
        System.out.println("LOG: TC_Ixigo_Flight_13 Passed - Mandatory traveller details validation verified.");
    }

    @Test(priority = 16, description = "TC_Ixigo_Flight_14: Validate contact details")
    public void TC_Ixigo_Flight_14_validateContactDetails() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_14: Validate Contact Details (Invalid Mobile) ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        flight.selectFlight(0);

        System.out.println("LOG: Entering invalid mobile number: 12345");
        passenger.enterContactMobile("12345");
        passenger.clickContinue();

        Assert.assertTrue(passenger.isValidationErrorDisplayed(), "Error message should be displayed for invalid contact details");
        System.out.println("LOG: TC_Ixigo_Flight_14 Passed - Invalid contact details validation verified.");
    }

    @Test(priority = 17, description = "TC_Ixigo_Flight_15: Validate Credit Card payment")
    public void TC_Ixigo_Flight_15_validateCreditCardPayment() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_15: Validate Credit Card Payment ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        flight.selectFlight(0);

        passenger.enterPassengerName(name);
        passenger.enterPassengerAge(age);
        passenger.selectGender();

        System.out.println("LOG: Selecting Credit Card Payment option");
        passenger.selectPaymentOption("Credit Card");
        passenger.enterCardDetails("4111111111111111", "12/28", "123");

        Assert.assertTrue(passenger.isPaymentPageDisplayed(), "Payment options / card details section should be displayed");
        System.out.println("LOG: TC_Ixigo_Flight_15 Passed - Credit Card payment section verified.");
    }

    @Test(priority = 18, description = "TC_Ixigo_Flight_16: Validate UPI payment")
    public void TC_Ixigo_Flight_16_validateUPIPayment() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_16: Validate UPI Payment ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        flight.selectFlight(0);

        passenger.enterPassengerName(name);
        passenger.enterPassengerAge(age);
        passenger.selectGender();

        System.out.println("LOG: Selecting UPI Payment option and entering test@upi");
        passenger.selectPaymentOption("UPI");
        passenger.enterUPIId("test@upi");

        Assert.assertTrue(passenger.isPaymentPageDisplayed(), "UPI payment section should be displayed");
        System.out.println("LOG: TC_Ixigo_Flight_16 Passed - UPI payment section verified.");
    }

    @Test(priority = 19, description = "TC_Ixigo_Flight_17: Validate failed payment")
    public void TC_Ixigo_Flight_17_validateFailedPayment() {
        System.out.println("\n--- Starting TC_Ixigo_Flight_17: Validate Failed / Invalid Payment ---");
        getDriver().get("https://www.ixigo.com/flights");
        home.closeCleverTapPopupIfPresent();

        search.selectOneWay();
        search.enterLeavingFrom(from);
        search.enterGoingTo(to);
        search.selectDepartureDate();
        search.clickSearch();

        flight.selectFlight(0);

        passenger.enterPassengerName(name);
        passenger.enterPassengerAge(age);
        passenger.selectGender();

        System.out.println("LOG: Entering invalid payment data");
        passenger.selectPaymentOption("Credit Card");
        passenger.enterCardDetails("0000000000000000", "01/20", "000");

        Assert.assertTrue(passenger.isPaymentFailureOrValidationDisplayed(), "Payment failure or validation message should be displayed");
        System.out.println("LOG: TC_Ixigo_Flight_17 Passed - Payment validation / failure handling verified.");
    }

}
