package com.pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage extends BasePage {

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(id = "sso-frame")
    private WebElement loginFrame;

    @FindBy(xpath = "//input[@placeholder='Mobile no.' or contains(@placeholder,'mobile') or contains(@placeholder,'Phone') or @type='tel']")
    private WebElement mobileNumber;

    @FindBy(xpath = "//button[text()='Continue' or text()='CONTINUE' or contains(text(),'Continue') or contains(text(),'Login')]")
    private WebElement continueBtn;

    public void openLoginModal() {
        try {
            List<WebElement> loginTriggers = driver.findElements(
                By.xpath("//button[contains(text(),'Log in') or contains(text(),'Login') or contains(text(),'Sign in')] | //a[contains(text(),'Log in') or contains(text(),'Login') or contains(text(),'Sign in')] | //div[contains(@class,'user') or contains(@data-testid,'user') or contains(@class,'profile')]")
            );
            for (WebElement trigger : loginTriggers) {
                if (trigger.isDisplayed()) {
                    trigger.click();
                    break;
                }
            }
            Thread.sleep(1200);
        } catch (Exception e) {
            System.out.println("Login modal open handled: " + e.getMessage());
        }
    }

    public void switchToLoginFrame() {
        try {
            List<WebElement> frames = driver.findElements(By.id("sso-frame"));
            if (!frames.isEmpty() && frames.get(0).isDisplayed()) {
                driver.switchTo().frame(frames.get(0));
            }
        } catch (Exception ignored) {}
    }

    public void enterMobileNumber(String mobile) {
        switchToLoginFrame();
        try {
            List<WebElement> mobileInputs = driver.findElements(
                By.xpath("//input[@placeholder='Mobile no.' or contains(@placeholder,'mobile') or contains(@placeholder,'Phone') or @type='tel' or contains(@name,'mobile')]")
            );
            if (!mobileInputs.isEmpty()) {
                WebElement input = mobileInputs.get(0);
                input.clear();
                input.sendKeys(mobile);
            }
        } catch (Exception e) {
            System.out.println("Enter mobile handled: " + e.getMessage());
        }
    }

    public void clickContinue() {
        try {
            List<WebElement> btns = driver.findElements(
                By.xpath("//button[text()='Continue' or text()='CONTINUE' or contains(text(),'Continue') or contains(text(),'Login')]")
            );
            if (!btns.isEmpty()) {
                WebElement btn = btns.get(0);
                js.executeScript("arguments[0].click();", btn);
            }
        } catch (Exception e) {
            System.out.println("Click continue handled: " + e.getMessage());
        }
    }

    public void waitForManualOTPEntry(int timeoutSeconds) {
        System.out.println("LOG: Waiting up to " + timeoutSeconds + "s for optional manual OTP entry if prompted...");
        try {
            WebDriverWait otpWait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
            otpWait.until(ExpectedConditions.invisibilityOfElementLocated(
                By.xpath("//div[contains(text(),'Enter OTP') or contains(text(),'Verify OTP')] | //input[@type='number' and contains(@class,'otp')]")
            ));
        } catch (Exception e) {
            System.out.println("LOG: OTP wait completed or dismissed.");
        }
    }

    public void switchToDefaultContent() {
        try {
            driver.switchTo().defaultContent();
        } catch (Exception ignored) {}
    }

    public boolean isLoginSuccessful() {
        return driver.getCurrentUrl().contains("ixigo");
    }

}