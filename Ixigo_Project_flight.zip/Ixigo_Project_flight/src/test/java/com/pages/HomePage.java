package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HomePage extends BasePage {
	
    public HomePage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//a[contains(@href,'flights') or contains(text(),'Flights')]")
    WebElement flightsLink;

    public void clickFlights() {

        try {
            wait.until(ExpectedConditions.elementToBeClickable(flightsLink));
            flightsLink.click();
        } catch (Exception e) {
            System.out.println("Flights page active by default or clicked: " + e.getMessage());
        }

    }

    public boolean isHomePageDisplayed() {

        return driver.getTitle().toLowerCase().contains("ixigo") || driver.getCurrentUrl().contains("ixigo");

    }

}