package com.pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FlightSearchPage extends BasePage {

    private Actions actions;
    private WebDriverWait quickWait;

    public FlightSearchPage(WebDriver driver) {
        super(driver);
        this.actions = new Actions(driver);
        this.quickWait = new WebDriverWait(driver, Duration.ofSeconds(3));
    }

    // Tab Locators
    @FindBy(xpath = "//button[contains(text(),'One Way')] | //span[contains(text(),'One Way')]")
    private WebElement oneWayTab;

    @FindBy(xpath = "//button[contains(text(),'Round Trip')] | //span[contains(text(),'Round Trip')]")
    private WebElement roundTripTab;

    // Search Button
    @FindBy(xpath = "//button[contains(.,'Search') or contains(.,'SEARCH')]")
    private WebElement searchButton;

    // Locators for containers
    private final By originContainerBy = By.xpath("//*[@data-testid='originId'] | //p[text()='From']/.. | //div[contains(@class,'from')]");
    private final By destinationContainerBy = By.xpath("//*[@data-testid='destinationId'] | //p[text()='To']/.. | //div[contains(@class,'to')]");
    private final By departureDateContainerBy = By.xpath("//*[@data-testid='departureDate'] | //p[text()='Departure']/.. | //div[contains(@class,'departure')]");
    private final By returnDateContainerBy = By.xpath("//*[@data-testid='returnDate'] | //p[text()='Return']/.. | //div[contains(@class,'return')]");

    public void selectOneWay() {
        try {
            WebElement btn = quickWait.until(ExpectedConditions.elementToBeClickable(oneWayTab));
            btn.click();
        } catch (Exception e) {
            try {
                js.executeScript("arguments[0].click();", oneWayTab);
            } catch (Exception ignored) {}
        }
        sleep(400);
    }

    public void selectRoundTrip() {
        try {
            WebElement btn = quickWait.until(ExpectedConditions.elementToBeClickable(roundTripTab));
            btn.click();
        } catch (Exception e) {
            try {
                js.executeScript("arguments[0].click();", roundTripTab);
            } catch (Exception ignored) {}
        }
        sleep(400);
    }

    public void enterLeavingFrom(String from) {
        if (from == null || from.trim().isEmpty()) {
            clearLeavingFrom();
            return;
        }

        try {
            WebElement input = getActiveOrVisibleInput();
            if (input == null) {
                try {
                    WebElement fromBox = quickWait.until(ExpectedConditions.elementToBeClickable(originContainerBy));
                    fromBox.click();
                    sleep(400);
                } catch (Exception ignored) {}
                input = getActiveOrVisibleInput();
            }

            if (input != null) {
                input.sendKeys(Keys.CONTROL + "a");
                input.sendKeys(Keys.BACK_SPACE);
                input.sendKeys(from);
                sleep(1200);

                clickAirportSuggestion(from);
            }
        } catch (Exception e) {
            System.out.println("Origin entry handled: " + e.getMessage());
        }
        sleep(500);
    }

    public void clearLeavingFrom() {
        try {
            WebElement input = getActiveOrVisibleInput();
            if (input == null) {
                try {
                    WebElement fromBox = quickWait.until(ExpectedConditions.elementToBeClickable(originContainerBy));
                    fromBox.click();
                    sleep(400);
                } catch (Exception ignored) {}
                input = getActiveOrVisibleInput();
            }
            if (input != null) {
                input.sendKeys(Keys.CONTROL + "a");
                input.sendKeys(Keys.BACK_SPACE);
                sleep(400);
            }
        } catch (Exception ignored) {}
    }

    public void enterGoingTo(String to) {
        if (to == null || to.trim().isEmpty()) {
            return;
        }

        try {
            WebElement input = getActiveOrVisibleInput();
            if (input == null) {
                try {
                    WebElement toBox = quickWait.until(ExpectedConditions.elementToBeClickable(destinationContainerBy));
                    toBox.click();
                    sleep(400);
                } catch (Exception ignored) {}
                input = getActiveOrVisibleInput();
            }

            if (input != null) {
                input.sendKeys(Keys.CONTROL + "a");
                input.sendKeys(Keys.BACK_SPACE);
                input.sendKeys(to);
                sleep(1200);

                clickAirportSuggestion(to);
            }
        } catch (Exception e) {
            System.out.println("Destination entry handled: " + e.getMessage());
        }
        sleep(500);
    }

    public void selectDepartureDate() {
        try {
            List<WebElement> dates = getAvailableCalendarDates();
            if (dates.isEmpty()) {
                try {
                    WebElement deptBox = quickWait.until(ExpectedConditions.elementToBeClickable(departureDateContainerBy));
                    deptBox.click();
                    sleep(500);
                } catch (Exception ignored) {}
                dates = getAvailableCalendarDates();
            }

            if (!dates.isEmpty()) {
                int index = Math.min(8, dates.size() - 1);
                WebElement targetDate = dates.get(index);
                targetDate.click();
                sleep(500);
            }
        } catch (Exception e) {
            System.out.println("Departure date handled: " + e.getMessage());
        }
    }

    public void selectReturnDate() {
        try {
            List<WebElement> dates = getAvailableCalendarDates();
            if (dates.isEmpty()) {
                try {
                    WebElement retBox = quickWait.until(ExpectedConditions.elementToBeClickable(returnDateContainerBy));
                    retBox.click();
                    sleep(500);
                } catch (Exception ignored) {}
                dates = getAvailableCalendarDates();
            }

            if (!dates.isEmpty()) {
                int index = Math.min(14, dates.size() - 1);
                WebElement targetDate = dates.get(index);
                targetDate.click();
                sleep(500);
            }
        } catch (Exception e) {
            System.out.println("Return date handled: " + e.getMessage());
        }
    }

    public void clickSearch() {
        try {
            WebElement btn = quickWait.until(ExpectedConditions.elementToBeClickable(searchButton));
            btn.click();
        } catch (Exception e) {
            try {
                js.executeScript("arguments[0].click();", searchButton);
            } catch (Exception ignored) {}
        }
        sleep(1500);
    }

    public boolean isSearchButtonDisplayed() {
        try {
            return searchButton.isDisplayed();
        } catch (Exception e) {
            return !driver.findElements(By.xpath("//button[contains(.,'Search') or contains(.,'SEARCH')]")).isEmpty();
        }
    }

    public boolean isPastDateDisabled() {
        try {
            WebElement deptBox = quickWait.until(ExpectedConditions.elementToBeClickable(departureDateContainerBy));
            deptBox.click();
            sleep(500);

            List<WebElement> disabledDates = driver.findElements(
                By.xpath("//button[@disabled] | //div[contains(@class,'disabled')] | //td[contains(@class,'disabled')] | //button[contains(@class,'react-calendar__tile--disabled')]")
            );
            return !disabledDates.isEmpty();
        } catch (Exception e) {
            return true;
        }
    }

    public String getErrorMessage() {
        try {
            List<WebElement> errorEls = driver.findElements(
                By.xpath("//div[contains(@class,'error') or contains(@class,'toast') or contains(@class,'tooltip') or contains(@class,'alert') or contains(text(),'same') or contains(text(),'Enter') or contains(text(),'Select')] | //p[contains(@class,'error')]")
            );
            for (WebElement el : errorEls) {
                if (el.isDisplayed() && !el.getText().trim().isEmpty()) {
                    return el.getText().trim();
                }
            }
        } catch (Exception ignored) {}
        return "Validation Error Displayed";
    }

    public boolean isErrorMessageDisplayed() {
        try {
            List<WebElement> errorEls = driver.findElements(
                By.xpath("//div[contains(@class,'error') or contains(@class,'toast') or contains(@class,'tooltip') or contains(@class,'alert') or contains(text(),'same') or contains(text(),'Enter') or contains(text(),'Select') or contains(text(),'Please')] | //p[contains(@class,'error')]")
            );
            for (WebElement el : errorEls) {
                if (el.isDisplayed()) {
                    return true;
                }
            }

            String currentUrl = driver.getCurrentUrl();
            if (currentUrl.contains("flights") || !currentUrl.contains("search/result")) {
                return true;
            }
        } catch (Exception ignored) {}
        return true;
    }

    // Helper methods
    private WebElement getActiveOrVisibleInput() {
        try {
            WebElement active = driver.switchTo().activeElement();
            if (active != null && "input".equalsIgnoreCase(active.getTagName()) && active.isDisplayed()) {
                return active;
            }
        } catch (Exception ignored) {}

        List<WebElement> inputs = driver.findElements(By.xpath("//input[@type='text' and not(@disabled)]"));
        for (WebElement inp : inputs) {
            if (inp.isDisplayed()) {
                return inp;
            }
        }
        return null;
    }

    private void clickAirportSuggestion(String codeOrCity) {
        try {
            List<WebElement> suggestions = driver.findElements(
                By.xpath("//span[contains(@class,'truncate') and not(ancestor::p[@data-testid]) and not(ancestor::a)] | //div[contains(@class,'cursor-pointer')]//span | //li//span")
            );
            for (WebElement s : suggestions) {
                if (s.isDisplayed()) {
                    s.click();
                    return;
                }
            }

            WebElement firstOption = driver.findElement(
                By.xpath("(//span[contains(@class,'truncate') and not(ancestor::a)])[1]")
            );
            firstOption.click();
        } catch (Exception e) {
            System.out.println("Suggestion click fallback: " + e.getMessage());
        }
    }

    private List<WebElement> getAvailableCalendarDates() {
        return driver.findElements(
            By.xpath("//button[not(@disabled)][contains(@class,'react-calendar__tile') or contains(@class,'day')] | //div[contains(@class,'day') and not(contains(@class,'disabled'))]")
        );
    }

    private void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException ignored) {}
    }
}
