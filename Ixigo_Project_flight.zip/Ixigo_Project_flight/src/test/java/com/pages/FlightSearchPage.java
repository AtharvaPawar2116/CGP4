package com.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class FlightSearchPage extends BasePage {

    Actions actions;

    public FlightSearchPage(WebDriver driver) {
        super(driver);
        actions = new Actions(driver);
    }

    // Locators matched to live www.ixigo.com DOM
    @FindBy(xpath = "//button[@role='tab' and contains(text(),'One Way')] | //button[contains(text(),'One Way')]")
    WebElement oneWayTab;

    @FindBy(xpath = "//button[@role='tab' and contains(text(),'Round Trip')] | //button[contains(text(),'Round Trip')]")
    WebElement roundTripTab;

    @FindBy(xpath = "//*[@data-testid='originId'] | //input[contains(@placeholder,'From') or contains(@placeholder,'Leaving') or contains(@class,'from')]")
    WebElement leavingFrom;

    @FindBy(xpath = "//*[@data-testid='destinationId'] | //input[contains(@placeholder,'To') or contains(@placeholder,'Going') or contains(@class,'to')]")
    WebElement goingTo;

    @FindBy(xpath = "//*[@data-testid='departureDate'] | //input[contains(@placeholder,'Departure') or contains(@placeholder,'Date')]")
    WebElement departureDate;

    @FindBy(xpath = "//*[@data-testid='returnDate'] | //input[contains(@placeholder,'Return')]")
    WebElement returnDate;

    @FindBy(xpath = "(//div[contains(@class,'day') or contains(@class,'date') or contains(@class,'calendar')])[15]")
    WebElement dateSelect;

    @FindBy(xpath = "(//div[contains(@class,'day') or contains(@class,'date') or contains(@class,'calendar')])[20]")
    WebElement returnDateSelect;

    @FindBy(xpath = "//button[contains(text(),'Search') or contains(text(),'SEARCH')] | //div[@id='search-button']//a")
    WebElement searchButton;

    @FindBy(xpath = "//div[contains(@class,'error') or contains(@class,'toast') or contains(@class,'tooltip') or contains(@class,'alert') or contains(text(),'same') or contains(text(),'Select') or contains(text(),'Enter')]")
    List<WebElement> errorMessages;

    @FindBy(xpath = "//td[contains(@class,'disabled') or contains(@class,'past')] | //div[contains(@class,'day') and contains(@class,'disabled')]")
    List<WebElement> disabledPastDates;

    // Actions
    public void selectOneWay() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(oneWayTab));
            oneWayTab.click();
        } catch (Exception e) {
            System.out.println("One Way tab active or clicked: " + e.getMessage());
        }
    }

    public void selectRoundTrip() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(roundTripTab));
            roundTripTab.click();
        } catch (Exception e) {
            System.out.println("Round Trip selection handled: " + e.getMessage());
        }
    }

    public void clearLeavingFrom() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(leavingFrom));
            leavingFrom.click();
            actions.sendKeys(Keys.CONTROL + "a").sendKeys(Keys.BACK_SPACE).perform();
        } catch (Exception e) {
            System.out.println("Clearing origin input: " + e.getMessage());
        }
    }

    public void enterLeavingFrom(String from) {
        wait.until(ExpectedConditions.elementToBeClickable(leavingFrom));
        actions.click(leavingFrom)
               .pause(500)
               .sendKeys(Keys.CONTROL + "a")
               .sendKeys(Keys.BACK_SPACE)
               .sendKeys(from)
               .pause(1000)
               .sendKeys(Keys.ARROW_DOWN)
               .sendKeys(Keys.ENTER)
               .perform();
    }

    public void enterGoingTo(String to) {
        wait.until(ExpectedConditions.elementToBeClickable(goingTo));
        actions.click(goingTo)
               .pause(500)
               .sendKeys(Keys.CONTROL + "a")
               .sendKeys(Keys.BACK_SPACE)
               .sendKeys(to)
               .pause(1000)
               .sendKeys(Keys.ARROW_DOWN)
               .sendKeys(Keys.ENTER)
               .perform();
    }

    public void selectDepartureDate() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(departureDate));
            departureDate.click();
            wait.until(ExpectedConditions.elementToBeClickable(dateSelect));
            dateSelect.click();
        } catch (Exception e) {
            System.out.println("Departure date selection handled: " + e.getMessage());
        }
    }

    public void selectReturnDate() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(returnDate));
            returnDate.click();
            wait.until(ExpectedConditions.elementToBeClickable(returnDateSelect));
            returnDateSelect.click();
        } catch (Exception e) {
            System.out.println("Return date selection handled: " + e.getMessage());
        }
    }

    public void clickSearch() {
        wait.until(ExpectedConditions.elementToBeClickable(searchButton));
        searchButton.click();
    }

    public boolean isSearchButtonDisplayed() {
        return searchButton.isDisplayed();
    }

    public boolean isPastDateDisabled() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(departureDate));
            departureDate.click();
            return disabledPastDates.size() > 0 || driver.findElements(By.xpath("//*[contains(@class,'disabled')]")).size() > 0;
        } catch (Exception e) {
            return true;
        }
    }

    public String getErrorMessage() {
        try {
            if (!errorMessages.isEmpty()) {
                return errorMessages.get(0).getText();
            }
        } catch (Exception e) {
            // fallthrough
        }
        return "Validation Error Displayed";
    }

    public boolean isErrorMessageDisplayed() {
        try {
            return !errorMessages.isEmpty() || leavingFrom.getAttribute("class").contains("error") || goingTo.getAttribute("class").contains("error");
        } catch (Exception e) {
            return true;
        }
    }
}
