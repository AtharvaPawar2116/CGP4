package com.pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {

    protected WebDriver driver;
    protected WebDriverWait wait;
    protected JavascriptExecutor js;

    public BasePage(WebDriver driver) {

        this.driver = driver;
        PageFactory.initElements(driver, this);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        this.js = (JavascriptExecutor) driver;

    }

    /**
     * Closes CleverTap or overlay popup if present without blocking
     */
    public void closeCleverTapPopupIfPresent() {

        try {
            WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(1));
            List<WebElement> iframes = driver.findElements(By.id("wiz-iframe-intent"));
            if (!iframes.isEmpty() && iframes.get(0).isDisplayed()) {
                driver.switchTo().frame(iframes.get(0));
                WebElement closeBtn = shortWait.until(
                    ExpectedConditions.elementToBeClickable(By.id("closeButton"))
                );
                closeBtn.click();
                driver.switchTo().defaultContent();
                System.out.println("Popup Closed Successfully");
            }
        } catch (Exception e) {
            try {
                driver.switchTo().defaultContent();
            } catch (Exception ignored) {}
        }

        // Also close any generic notification/overlay dialog if present
        try {
            List<WebElement> closeBtns = driver.findElements(
                By.xpath("//div[contains(@class,'modal') or contains(@class,'dialog') or contains(@class,'popup')]//button[contains(@class,'close') or text()='✕' or text()='×' or @aria-label='Close']")
            );
            if (!closeBtns.isEmpty() && closeBtns.get(0).isDisplayed()) {
                closeBtns.get(0).click();
            }
        } catch (Exception ignored) {}
    }

}