package com.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {

    protected WebDriver driver;
    protected WebDriverWait wait;

    public BasePage(WebDriver driver) {

        this.driver = driver;

        PageFactory.initElements(driver, this);

        wait = new WebDriverWait(driver, Duration.ofSeconds(30));

    }

    /**
     * Closes CleverTap popup iframe if present
     * This method handles the iframe switching required to close the popup
     */
    public void closeCleverTapPopupIfPresent() {

        try {
            // Wait for and switch to the iframe containing the popup
            WebElement iframeElement = wait.until(
                ExpectedConditions.presenceOfElementLocated(
                    By.id("wiz-iframe-intent")
                )
            );
            
            driver.switchTo().frame(iframeElement);
            
            // Now find and click the close button inside the iframe
            WebElement closeBtn = wait.until(
                ExpectedConditions.elementToBeClickable(
                    By.id("closeButton")
                )
            );

            closeBtn.click();
            
            // Switch back to main content
            driver.switchTo().defaultContent();

            System.out.println("Popup Closed Successfully");

        } catch (Exception e) {

            System.out.println("Popup Not Present: " + e.getMessage());
            // Ensure we switch back to main content if error occurs
            try {
                driver.switchTo().defaultContent();
            } catch (Exception ignored) {}

        }
    }

}