package com.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class SearchPage extends BasePage {

    Actions actions;

    public SearchPage(WebDriver driver) {
        super(driver);
        actions = new Actions(driver);
    }

    @FindBy(xpath = "//input[@placeholder='Leaving From']")
    WebElement leavingFrom;

    @FindBy(xpath = "//input[@placeholder='Going To']")
    WebElement goingTo;

    @FindBy(xpath = "//input[@placeholder='Onward Journey Date']")
    WebElement journeyDate;

    @FindBy(xpath = "//*[@id='jaurney-date']/div/div[2]/div[2]/a[30]")
    WebElement date30;

    @FindBy(xpath = "//div[@id='search-button']//a")
    WebElement searchButton;

    public void enterLeavingFrom(String from) {

        wait.until(ExpectedConditions.elementToBeClickable(leavingFrom));

        actions.click(leavingFrom)
               .sendKeys(from)
               .sendKeys(Keys.ARROW_DOWN)
               .sendKeys(Keys.ENTER)
               .perform();
    }

    public void enterGoingTo(String to) {

        wait.until(ExpectedConditions.elementToBeClickable(goingTo));

        actions.click(goingTo)
               .sendKeys(to)
               .sendKeys(Keys.ARROW_DOWN)
               .sendKeys(Keys.ENTER)
               .perform();
    }

    public void selectJourneyDate() {

        wait.until(ExpectedConditions.elementToBeClickable(journeyDate));
        journeyDate.click();

        wait.until(ExpectedConditions.elementToBeClickable(date30));
        date30.click();

    }

    public void clickSearch() {

        wait.until(ExpectedConditions.elementToBeClickable(searchButton));

        searchButton.click();

    }

    public boolean isSearchButtonDisplayed() {

        return searchButton.isDisplayed();

    }

}