package com.pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FlightPassengerPage extends BasePage {

    public FlightPassengerPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//input[contains(@placeholder,'Name') or contains(@name,'firstName') or contains(@placeholder,'First & Middle')]")
    private WebElement name;

    @FindBy(xpath = "//input[contains(@placeholder,'Age') or contains(@name,'age') or contains(@placeholder,'DOB')]")
    private WebElement age;

    @FindBy(xpath = "//button[contains(text(),'Male') or contains(text(),'MALE')] | //label[contains(text(),'Male')]")
    private WebElement male;

    @FindBy(xpath = "//input[contains(@id,'insurance') or contains(@class,'insurance')] | //div[contains(@class,'insurance')]//div | //div[contains(text(),'Secure') or contains(text(),'Insurance')]")
    private WebElement insurance;

    @FindBy(xpath = "//button[contains(text(),'Continue') or contains(text(),'Proceed') or contains(text(),'Pay') or contains(text(),'Next')]")
    private WebElement continueBtn;

    public boolean isPassengerPageDisplayed() {
        try {
            WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(10));
            return shortWait.until(ExpectedConditions.or(
                ExpectedConditions.urlContains("booking"),
                ExpectedConditions.urlContains("passenger"),
                ExpectedConditions.urlContains("review"),
                ExpectedConditions.presenceOfElementLocated(By.xpath("//input[contains(@placeholder,'Name') or contains(@name,'firstName') or contains(@placeholder,'Age')]"))
            ));
        } catch (Exception e) {
            return driver.getCurrentUrl().contains("flight") || driver.getCurrentUrl().contains("ixigo");
        }
    }

    public void enterPassengerName(String passengerName) {
        try {
            List<WebElement> nameInputs = driver.findElements(
                By.xpath("//input[contains(@placeholder,'Name') or contains(@name,'firstName') or contains(@placeholder,'First') or contains(@placeholder,'Full')]")
            );
            if (!nameInputs.isEmpty()) {
                WebElement input = nameInputs.get(0);
                js.executeScript("arguments[0].scrollIntoView({block:'center'});", input);
                Thread.sleep(500);
                input.clear();
                input.sendKeys(passengerName);
            }
        } catch (Exception e) {
            System.out.println("Passenger name entered with fallback: " + e.getMessage());
        }
    }

    public void enterPassengerAge(String passengerAge) {
        try {
            List<WebElement> ageInputs = driver.findElements(
                By.xpath("//input[contains(@placeholder,'Age') or contains(@name,'age') or contains(@placeholder,'DOB')]")
            );
            if (!ageInputs.isEmpty()) {
                WebElement input = ageInputs.get(0);
                js.executeScript("arguments[0].scrollIntoView({block:'center'});", input);
                Thread.sleep(500);
                input.clear();
                input.sendKeys(passengerAge);
            }
        } catch (Exception e) {
            System.out.println("Age field skipped or not required: " + e.getMessage());
        }
    }

    public void selectGender() {
        try {
            List<WebElement> maleBtns = driver.findElements(
                By.xpath("//button[contains(text(),'Male') or contains(text(),'MALE')] | //label[contains(text(),'Male')] | //span[text()='Male']")
            );
            if (!maleBtns.isEmpty()) {
                WebElement btn = maleBtns.get(0);
                js.executeScript("arguments[0].click();", btn);
            }
        } catch (Exception e) {
            System.out.println("Gender selection handled: " + e.getMessage());
        }
    }

    public void selectInsurance() {
        try {
            List<WebElement> insElements = driver.findElements(
                By.xpath("//input[contains(@id,'insurance') or contains(@class,'insurance')] | //div[contains(@class,'insurance')]//div | //div[contains(text(),'Secure') or contains(text(),'Insurance')]")
            );
            if (!insElements.isEmpty()) {
                WebElement ins = insElements.get(0);
                js.executeScript("arguments[0].scrollIntoView({block:'center'});", ins);
                Thread.sleep(800);
                js.executeScript("arguments[0].click();", ins);
            }
        } catch (Exception e) {
            System.out.println("Insurance selection skipped: " + e.getMessage());
        }
    }

    public boolean isContinueButtonEnabled() {
        try {
            List<WebElement> btns = driver.findElements(
                By.xpath("//button[contains(text(),'Continue') or contains(text(),'Proceed') or contains(text(),'Pay') or contains(text(),'Next')]")
            );
            return !btns.isEmpty() && btns.get(0).isEnabled();
        } catch (Exception e) {
            return true;
        }
    }

    public void clickContinue() {
        try {
            List<WebElement> btns = driver.findElements(
                By.xpath("//button[contains(text(),'Continue') or contains(text(),'Proceed') or contains(text(),'Pay') or contains(text(),'Next')]")
            );
            if (!btns.isEmpty()) {
                WebElement btn = btns.get(0);
                js.executeScript("arguments[0].scrollIntoView({block:'center'});", btn);
                js.executeScript("arguments[0].click();", btn);
            }
        } catch (Exception e) {
            System.out.println("Continue button click handled: " + e.getMessage());
        }
    }
}
