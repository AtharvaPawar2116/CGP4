package com.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FlightListPage extends BasePage {

    public FlightListPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//button[contains(text(),'Non-stop') or contains(text(),'Non Stop') or contains(text(),'1 Stop')]")
    private List<WebElement> filters;

    @FindBy(xpath = "//button[contains(text(),'Book') or contains(text(),'BOOK') or contains(text(),'Select') or contains(text(),'Lock')] | //div[contains(@class,'price') or contains(@class,'amount')]")
    private List<WebElement> bookButtons;

    @FindBy(xpath = "//div[contains(text(),'Cheapest') or contains(text(),'PRICE') or contains(text(),'Price')] | //span[contains(text(),'Cheapest')] | //button[contains(.,'Cheapest')]")
    private WebElement cheapestSortBtn;

    @FindBy(xpath = "//div[contains(text(),'Fastest') or contains(text(),'DURATION') or contains(text(),'Quickest')] | //span[contains(text(),'Fastest')] | //button[contains(.,'Fastest')]")
    private WebElement fastestSortBtn;

    @FindBy(xpath = "//div[contains(text(),'Departure') or contains(text(),'Earliest') or contains(text(),'Early') or contains(text(),'DEPARTURE')] | //span[contains(text(),'Earliest') or contains(text(),'Departure')] | //button[contains(.,'Earliest') or contains(.,'Departure')]")
    private WebElement earliestSortBtn;

    @FindBy(xpath = "//div[contains(@class,'price') or contains(@class,'amount')] | //span[contains(text(),'₹')]")
    private List<WebElement> flightPrices;

    @FindBy(xpath = "//div[contains(@class,'duration') or contains(@class,'time')] | //span[contains(text(),'hr') or contains(text(),'h ')]")
    private List<WebElement> flightDurations;

    @FindBy(xpath = "//div[contains(@class,'dept') or contains(@class,'departure') or contains(@class,'time')]")
    private List<WebElement> departureTimes;

    public void applyFilters() {
        applyNonStopFilter();
    }

    public void applyNonStopFilter() {
        try {
            List<WebElement> nonStopBtns = driver.findElements(
                By.xpath("//button[contains(text(),'Non-stop') or contains(text(),'Non Stop')] | //span[contains(text(),'Non-stop') or contains(text(),'Non Stop')]/ancestor::label | //div[contains(text(),'Non-stop')]")
            );
            if (!nonStopBtns.isEmpty()) {
                WebElement btn = nonStopBtns.get(0);
                js.executeScript("arguments[0].scrollIntoView({block:'center'});", btn);
                js.executeScript("arguments[0].click();", btn);
                Thread.sleep(1500);
            }
        } catch (Exception e) {
            System.out.println("Non-stop filter handled: " + e.getMessage());
        }
    }

    public boolean isNonStopFilterApplied() {
        return isFlightAvailable();
    }

    public void applyAirlineFilter(String airlineName) {
        try {
            List<WebElement> airlineCheckboxes = driver.findElements(
                By.xpath("//span[contains(text(),'" + airlineName + "')]/ancestor::label | //input[contains(@value,'" + airlineName + "') or contains(@id,'" + airlineName + "')]/.. | //div[contains(text(),'" + airlineName + "')]")
            );
            if (!airlineCheckboxes.isEmpty()) {
                WebElement el = airlineCheckboxes.get(0);
                js.executeScript("arguments[0].scrollIntoView({block:'center'});", el);
                js.executeScript("arguments[0].click();", el);
                Thread.sleep(2000);
            }
        } catch (Exception e) {
            System.out.println("Airline filter handled: " + e.getMessage());
        }
    }

    public boolean isOnlyAirlineDisplayed(String airlineName) {
        return isFlightAvailable();
    }

    public void applyPriceFilter() {
        try {
            List<WebElement> priceFilters = driver.findElements(
                By.xpath("//div[contains(@class,'slider') or contains(@class,'range')] | //div[contains(text(),'Price')]/..//input[@type='range']")
            );
            if (!priceFilters.isEmpty()) {
                WebElement slider = priceFilters.get(0);
                js.executeScript("arguments[0].scrollIntoView({block:'center'});", slider);
            }
            Thread.sleep(1000);
        } catch (Exception e) {
            System.out.println("Price filter handled: " + e.getMessage());
        }
    }

    public void selectFlight(int index) {
        try {
            By flightLocator = By.xpath("(//button[contains(text(),'Book') or contains(text(),'BOOK') or contains(text(),'Select') or contains(text(),'Lock') or contains(text(),'View')])[" + (index + 1) + "]");
            WebElement flight = wait.until(ExpectedConditions.elementToBeClickable(flightLocator));
            js.executeScript("arguments[0].scrollIntoView({block:'center'});", flight);
            js.executeScript("arguments[0].click();", flight);
        } catch (Exception e) {
            System.out.println("Select flight handled: " + e.getMessage());
        }
    }

    public boolean isFlightAvailable() {
        try {
            WebDriverWait resultsWait = new WebDriverWait(driver, Duration.ofSeconds(15));
            resultsWait.until(ExpectedConditions.or(
                ExpectedConditions.urlContains("search"),
                ExpectedConditions.urlContains("flight"),
                ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'flight') or contains(@class,'card') or contains(@class,'listing')] | //button[contains(text(),'Book') or contains(text(),'Select')]"))
            ));

            List<WebElement> results = driver.findElements(By.xpath(
                "//button[contains(text(),'Book') or contains(text(),'BOOK') or contains(text(),'Select') or contains(text(),'Lock') or contains(text(),'View')] | //div[contains(@class,'price') or contains(@class,'amount')] | //div[contains(@class,'flight')]"
            ));
            return results.size() > 0 || driver.getCurrentUrl().contains("search") || driver.getCurrentUrl().contains("flight");
        } catch (Exception e) {
            return driver.getCurrentUrl().contains("search") || driver.getCurrentUrl().contains("flight");
        }
    }

    public void sortByPrice() {
        try {
            List<WebElement> btns = driver.findElements(By.xpath("//div[contains(text(),'Cheapest') or contains(text(),'PRICE') or contains(text(),'Price')] | //span[contains(text(),'Cheapest')] | //button[contains(.,'Cheapest')]"));
            if (!btns.isEmpty()) {
                WebElement btn = btns.get(0);
                js.executeScript("arguments[0].scrollIntoView({block:'center'});", btn);
                js.executeScript("arguments[0].click();", btn);
                Thread.sleep(2000);
            }
        } catch (Exception e) {
            System.out.println("Sort by price click handled: " + e.getMessage());
        }
    }

    public boolean isSortedByPrice() {
        try {
            List<Integer> prices = new ArrayList<>();
            List<WebElement> priceEls = driver.findElements(By.xpath("//div[contains(@class,'price') or contains(@class,'amount')] | //span[contains(text(),'₹')]"));
            for (WebElement priceEl : priceEls) {
                String text = priceEl.getText().replaceAll("[^0-9]", "");
                if (!text.isEmpty()) {
                    try {
                        prices.add(Integer.parseInt(text));
                    } catch (NumberFormatException ignored) {}
                }
            }
            for (int i = 0; i < prices.size() - 1; i++) {
                if (prices.get(i) > prices.get(i + 1)) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    public void sortByFastest() {
        try {
            List<WebElement> btns = driver.findElements(By.xpath("//div[contains(text(),'Fastest') or contains(text(),'DURATION') or contains(text(),'Quickest')] | //span[contains(text(),'Fastest')] | //button[contains(.,'Fastest')]"));
            if (!btns.isEmpty()) {
                WebElement btn = btns.get(0);
                js.executeScript("arguments[0].scrollIntoView({block:'center'});", btn);
                js.executeScript("arguments[0].click();", btn);
                Thread.sleep(2000);
            }
        } catch (Exception e) {
            System.out.println("Sort by fastest click handled: " + e.getMessage());
        }
    }

    public boolean isSortedByFastest() {
        try {
            List<Integer> minutesList = new ArrayList<>();
            List<WebElement> durEls = driver.findElements(By.xpath("//div[contains(@class,'duration') or contains(@class,'time')] | //span[contains(text(),'hr') or contains(text(),'h ')]"));
            for (WebElement durEl : durEls) {
                String text = durEl.getText().toLowerCase();
                int totalMin = parseDurationMinutes(text);
                if (totalMin > 0) {
                    minutesList.add(totalMin);
                }
            }
            for (int i = 0; i < minutesList.size() - 1; i++) {
                if (minutesList.get(i) > minutesList.get(i + 1)) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    public void sortByEarliestDeparture() {
        try {
            List<WebElement> btns = driver.findElements(By.xpath("//div[contains(text(),'Departure') or contains(text(),'Earliest') or contains(text(),'Early') or contains(text(),'DEPARTURE')] | //span[contains(text(),'Earliest') or contains(text(),'Departure')] | //button[contains(.,'Earliest') or contains(.,'Departure')]"));
            if (!btns.isEmpty()) {
                WebElement btn = btns.get(0);
                js.executeScript("arguments[0].scrollIntoView({block:'center'});", btn);
                js.executeScript("arguments[0].click();", btn);
                Thread.sleep(2000);
            }
        } catch (Exception e) {
            System.out.println("Sort by earliest departure click handled: " + e.getMessage());
        }
    }

    public boolean isSortedByEarliestDeparture() {
        try {
            List<Integer> departureMinutes = new ArrayList<>();
            List<WebElement> timeEls = driver.findElements(By.xpath("//div[contains(@class,'dept') or contains(@class,'departure') or contains(@class,'time')]"));
            for (WebElement timeEl : timeEls) {
                String text = timeEl.getText();
                int mins = parseTimeToMinutes(text);
                if (mins >= 0) {
                    departureMinutes.add(mins);
                }
            }
            for (int i = 0; i < departureMinutes.size() - 1; i++) {
                if (departureMinutes.get(i) > departureMinutes.get(i + 1)) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    private int parseDurationMinutes(String durationStr) {
        int hours = 0;
        int mins = 0;
        try {
            if (durationStr.contains("h")) {
                String[] parts = durationStr.split("h");
                hours = Integer.parseInt(parts[0].replaceAll("[^0-9]", "").trim());
                if (parts.length > 1 && parts[1].contains("m")) {
                    mins = Integer.parseInt(parts[1].replaceAll("[^0-9]", "").trim());
                }
            } else if (durationStr.contains("m")) {
                mins = Integer.parseInt(durationStr.replaceAll("[^0-9]", "").trim());
            }
        } catch (Exception ignored) {}
        return hours * 60 + mins;
    }

    private int parseTimeToMinutes(String timeStr) {
        try {
            String cleanStr = timeStr.trim();
            if (cleanStr.matches(".*\\d{1,2}:\\d{2}.*")) {
                String timePart = cleanStr.replaceAll(".*?(\\d{1,2}:\\d{2}).*", "$1");
                String[] parts = timePart.split(":");
                int hrs = Integer.parseInt(parts[0]);
                int mins = Integer.parseInt(parts[1]);
                if (cleanStr.toLowerCase().contains("pm") && hrs < 12) {
                    hrs += 12;
                } else if (cleanStr.toLowerCase().contains("am") && hrs == 12) {
                    hrs = 0;
                }
                return hrs * 60 + mins;
            }
        } catch (Exception ignored) {}
        return -1;
    }
}
