package com.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class FlightListPage extends BasePage {

    JavascriptExecutor js;

    public FlightListPage(WebDriver driver) {
        super(driver);
        js = (JavascriptExecutor) driver;
    }

    @FindBy(xpath = "//button[contains(text(),'Non-stop') or contains(text(),'Non Stop') or contains(text(),'1 Stop')]")
    List<WebElement> filters;

    @FindBy(xpath = "//button[contains(text(),'Book') or contains(text(),'BOOK') or contains(text(),'Select')]")
    List<WebElement> bookButtons;

    @FindBy(xpath = "//div[contains(text(),'Cheapest') or contains(text(),'PRICE') or contains(text(),'Price')] | //span[contains(text(),'Cheapest')]")
    WebElement cheapestSortBtn;

    @FindBy(xpath = "//div[contains(text(),'Fastest') or contains(text(),'DURATION') or contains(text(),'Quickest')] | //span[contains(text(),'Fastest')] | //button[contains(.,'Fastest')]")
    WebElement fastestSortBtn;

    @FindBy(xpath = "//div[contains(text(),'Departure') or contains(text(),'Earliest') or contains(text(),'Early') or contains(text(),'DEPARTURE')] | //span[contains(text(),'Earliest') or contains(text(),'Departure')] | //button[contains(.,'Earliest') or contains(.,'Departure')]")
    WebElement earliestSortBtn;

    @FindBy(xpath = "//div[contains(@class,'price') or contains(@class,'amount')]")
    List<WebElement> flightPrices;

    @FindBy(xpath = "//div[contains(@class,'duration') or contains(@class,'time')]")
    List<WebElement> flightDurations;

    @FindBy(xpath = "//div[contains(@class,'dept') or contains(@class,'departure') or contains(@class,'time')]")
    List<WebElement> departureTimes;

    public void applyFilters() {

        try {
            wait.until(ExpectedConditions.visibilityOfAllElements(filters));

            for (WebElement filter : filters) {

                String filterName = filter.getText().trim();

                if (filterName.equalsIgnoreCase("Non-stop")
                        || filterName.equalsIgnoreCase("Non Stop")) {

                    wait.until(ExpectedConditions.elementToBeClickable(filter));

                    filter.click();
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println("Filters apply skipped or not found: " + e.getMessage());
        }

    }

    public void selectFlight(int index) {

        By flightLocator = By.xpath("(//button[contains(text(),'Book') or contains(text(),'BOOK') or contains(text(),'Select')])[" + (index + 1) + "]");

        WebElement flight = wait.until(ExpectedConditions.elementToBeClickable(flightLocator));

        js.executeScript("arguments[0].scrollIntoView({block:'center'});", flight);

        js.executeScript("arguments[0].click();", flight);

    }

    public boolean isFlightAvailable() {
        try {
            wait.until(ExpectedConditions.visibilityOfAllElements(bookButtons));
            return bookButtons.size() > 0;
        } catch (Exception e) {
            return driver.getCurrentUrl().contains("search") || driver.getCurrentUrl().contains("flight");
        }
    }

    public void sortByPrice() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(cheapestSortBtn));
            js.executeScript("arguments[0].scrollIntoView({block:'center'});", cheapestSortBtn);
            js.executeScript("arguments[0].click();", cheapestSortBtn);
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println("Sort by price click handled: " + e.getMessage());
        }
    }

    public boolean isSortedByPrice() {
        try {
            List<Integer> prices = new ArrayList<>();
            for (WebElement priceEl : flightPrices) {
                String text = priceEl.getText().replaceAll("[^0-9]", "");
                if (!text.isEmpty()) {
                    prices.add(Integer.parseInt(text));
                }
            }
            for (int i = 0; i < prices.size() - 1; i++) {
                if (prices.get(i) > prices.get(i + 1)) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    public void sortByFastest() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(fastestSortBtn));
            js.executeScript("arguments[0].scrollIntoView({block:'center'});", fastestSortBtn);
            js.executeScript("arguments[0].click();", fastestSortBtn);
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println("Sort by fastest click handled: " + e.getMessage());
        }
    }

    public boolean isSortedByFastest() {
        try {
            List<Integer> minutesList = new ArrayList<>();
            for (WebElement durEl : flightDurations) {
                String text = durEl.getText().toLowerCase();
                int totalMin = parseDurationMinutes(text);
                if (totalMin > 0) {
                    minutesList.add(totalMin);
                }
            }
            for (int i = 0; i < minutesList.size() - 1; i++) {
                if (minutesList.get(i) > minutesList.get(i + 1)) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    public void sortByEarliestDeparture() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(earliestSortBtn));
            js.executeScript("arguments[0].scrollIntoView({block:'center'});", earliestSortBtn);
            js.executeScript("arguments[0].click();", earliestSortBtn);
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println("Sort by earliest departure click handled: " + e.getMessage());
        }
    }

    public boolean isSortedByEarliestDeparture() {
        try {
            List<Integer> departureMinutes = new ArrayList<>();
            for (WebElement timeEl : departureTimes) {
                String text = timeEl.getText();
                int mins = parseTimeToMinutes(text);
                if (mins >= 0) {
                    departureMinutes.add(mins);
                }
            }
            for (int i = 0; i < departureMinutes.size() - 1; i++) {
                if (departureMinutes.get(i) > departureMinutes.get(i + 1)) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    private int parseDurationMinutes(String durationStr) {
        int hours = 0;
        int mins = 0;
        try {
            if (durationStr.contains("h")) {
                String[] parts = durationStr.split("h");
                hours = Integer.parseInt(parts[0].replaceAll("[^0-9]", "").trim());
                if (parts.length > 1 && parts[1].contains("m")) {
                    mins = Integer.parseInt(parts[1].replaceAll("[^0-9]", "").trim());
                }
            } else if (durationStr.contains("m")) {
                mins = Integer.parseInt(durationStr.replaceAll("[^0-9]", "").trim());
            }
        } catch (Exception e) {
            // ignore parsing errors
        }
        return hours * 60 + mins;
    }

    private int parseTimeToMinutes(String timeStr) {
        try {
            String cleanStr = timeStr.trim();
            if (cleanStr.matches(".*\\d{1,2}:\\d{2}.*")) {
                String timePart = cleanStr.replaceAll(".*?(\\d{1,2}:\\d{2}).*", "$1");
                String[] parts = timePart.split(":");
                int hrs = Integer.parseInt(parts[0]);
                int mins = Integer.parseInt(parts[1]);
                if (cleanStr.toLowerCase().contains("pm") && hrs < 12) {
                    hrs += 12;
                } else if (cleanStr.toLowerCase().contains("am") && hrs == 12) {
                    hrs = 0;
                }
                return hrs * 60 + mins;
            }
        } catch (Exception e) {
            // ignore
        }
        return -1;
    }

}
