package com.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class PassengerPage extends BasePage {

    JavascriptExecutor js;

    public PassengerPage(WebDriver driver) {
        super(driver);
        js = (JavascriptExecutor) driver;
    }

    @FindBy(xpath = "//input[@placeholder='Name']")
    WebElement name;

    @FindBy(xpath = "//input[@placeholder='Age']")
    WebElement age;

    @FindBy(xpath = "//button[normalize-space()='Male']")
    WebElement male;

    @FindBy(xpath = "//*[@id='assured-fc-card']/div[2]/div[3]/div/div[2]/div")
    WebElement insurance;

    @FindBy(xpath = "//*[@id='root']/div/div/div/div[2]/div/div[2]/a")
    WebElement continueBtn;

    public boolean isPassengerPageDisplayed() {
        return wait.until(ExpectedConditions.visibilityOf(name)).isDisplayed();
    }

    public void enterPassengerName(String passengerName) {

        wait.until(ExpectedConditions.elementToBeClickable(name));

        js.executeScript("arguments[0].scrollIntoView({block:'center'});", name);

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        name.clear();
        name.sendKeys(passengerName);
    }

    public void enterPassengerAge(String passengerAge) {

        wait.until(ExpectedConditions.elementToBeClickable(age));

        js.executeScript("arguments[0].scrollIntoView({block:'center'});", age);

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        age.click();
        age.clear();
        age.sendKeys(passengerAge);

        if (age.getAttribute("value").isEmpty()) {
            js.executeScript("arguments[0].value=arguments[1];", age, passengerAge);
        }
    }

    public void selectGender() {

        wait.until(ExpectedConditions.elementToBeClickable(male));
        js.executeScript("arguments[0].click();", male);
    }
    
    public void selectInsurance() throws InterruptedException {

        wait.until(ExpectedConditions.elementToBeClickable(insurance));

        js.executeScript("arguments[0].scrollIntoView({block:'center'});", insurance);
        Thread.sleep(3000);

        js.executeScript("arguments[0].click();", insurance);
    }

    public boolean isContinueButtonEnabled() {
        return continueBtn.isEnabled();
    }

    public void clickContinue() {

        wait.until(ExpectedConditions.elementToBeClickable(continueBtn));

        js.executeScript("arguments[0].scrollIntoView({block:'center'});", continueBtn);

        js.executeScript("arguments[0].click();", continueBtn);
    
    }
}