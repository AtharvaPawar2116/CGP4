package com.utils;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.setup.SetupDriver;

public class ExtentListener implements ITestListener {

    private static ExtentReports extent = ExtentManager.getReport();
    private static ThreadLocal<ExtentTest> test = new ThreadLocal<>();

    @Override
    public void onStart(ITestContext context) {
        System.out.println("Execution Started: " + context.getName());
    }

    @Override
    public void onTestStart(ITestResult result) {
        ExtentTest extentTest = extent.createTest(result.getMethod().getMethodName());
        test.set(extentTest);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        ExtentTest currentTest = test.get();
        if (currentTest != null) {
            currentTest.pass("Test Passed");
        }
    }

    @Override
    public void onTestFailure(ITestResult result) {
        ExtentTest currentTest = test.get();
        if (currentTest == null) {
            currentTest = extent.createTest(result.getMethod().getMethodName());
            test.set(currentTest);
        }

        currentTest.fail(result.getThrowable());

        try {
            if (SetupDriver.getDriver() != null) {
                String path = Screenshot.captureScreenshot(
                        SetupDriver.getDriver(),
                        result.getMethod().getMethodName());
                currentTest.addScreenCaptureFromPath(path);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        ExtentTest currentTest = test.get();
        if (currentTest == null) {
            currentTest = extent.createTest(result.getMethod().getMethodName());
            test.set(currentTest);
        }
        currentTest.skip("Test Skipped: " + (result.getThrowable() != null ? result.getThrowable().getMessage() : ""));
    }

    @Override
    public void onFinish(ITestContext context) {
        try {
            extent.flush();
        } catch (Exception ignored) {}
        System.out.println("Execution Completed: " + context.getName());
    }

}
