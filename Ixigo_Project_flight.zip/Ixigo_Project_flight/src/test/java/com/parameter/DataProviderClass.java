package com.parameter;

import java.io.IOException;

import org.testng.annotations.DataProvider;

public class DataProviderClass {

    @DataProvider(name="FlightData")

    public Object[][] getFlightData() throws IOException{

        String path = System.getProperty("user.dir")
                + "\\src\\test\\resources\\ExcelData\\Data.xlsx";

        return ExcelReader.getExcelData(path, "FlightData");

    }

}