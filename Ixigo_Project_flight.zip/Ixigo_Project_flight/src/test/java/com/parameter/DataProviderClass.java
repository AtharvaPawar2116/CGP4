package com.parameter;

import org.testng.annotations.DataProvider;

public class DataProviderClass {

    @DataProvider(name = "FlightData")
    public Object[][] getFlightData() {
        try {
            String path = System.getProperty("user.dir")
                    + "\\src\\test\\resources\\ExcelData\\Data.xlsx";
            return ExcelReader.getExcelData(path, "FlightData");
        } catch (Throwable t) {
            System.out.println("Excel Data Provider fallback: " + t.getMessage());
            return new Object[][] {
                { "7816013123", "DEL", "BOM", "Sairam", "22" }
            };
        }
    }

}