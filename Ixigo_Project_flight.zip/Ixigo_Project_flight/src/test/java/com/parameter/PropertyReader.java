package com.parameter;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertyReader {

    static Properties prop = new Properties();

    public static String getProperty(String key) {

        try {

            String path = System.getProperty("user.dir")
                    + "\\src\\test\\resources\\Config\\Config.properties";

            FileInputStream fis = new FileInputStream(path);

            prop.load(fis);

        } catch (IOException e) {

            e.printStackTrace();

        }

        return prop.getProperty(key);

    }

}