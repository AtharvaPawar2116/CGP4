# Requirements Document

## Introduction

This document defines the requirements for adapting the Ixigo Bus automation framework to automate the **Flight module** of [https://www.ixigo.com](https://www.ixigo.com). The scope covers creating and modifying Page Object Model classes, an orchestration test class, a data provider, and supporting configuration so that the end-to-end flight booking flow (home → login → search → filter → flight selection → optional fare selection → traveller details) is fully automated within the existing Maven / Selenium 4 / TestNG 7 project — with no new dependencies.

---

## Glossary

- **System**: The flight booking automation framework as a whole.
- **HomePage**: Page object class responsible for interacting with the Ixigo home page and navigating to the Flights section.
- **LoginPage**: Existing, unchanged page object class that handles OTP-based mobile login.
- **SearchPage**: Page object class responsible for the flight search form (From/To autocomplete, departure date, Search button).
- **FlightListPage**: Page object class responsible for the flight results list, optional filter application, and flight selection.
- **FareSelectionPage**: Page object class responsible for the optional fare type selection page.
- **TravellerDetailsPage**: Page object class responsible for the traveller details entry form.
- **FlightBookingTest**: TestNG test class that orchestrates all page interactions end-to-end.
- **DataProviderClass**: TestNG `@DataProvider` class that reads flight test data from the `FlightData` Excel sheet.
- **ExcelReader**: Existing utility that reads rows from a named sheet in `Data.xlsx`.
- **BasePage**: Existing base class providing `WebDriver`, `WebDriverWait`, and `PageFactory` initialisation.
- **Hooks**: Existing TestNG `@BeforeClass` / `@AfterClass` class managing browser lifecycle.
- **ExtentListener**: Existing TestNG listener that integrates with ExtentReports for pass/fail/screenshot reporting.
- **ExtentManager**: Existing utility that initialises the ExtentReports HTML report.
- **FlightData sheet**: The worksheet named `FlightData` inside `src/test/resources/ExcelData/Data.xlsx`.

---

## Requirements

### Requirement 1: Home Page — Flights Navigation

**User Story:** As a test engineer, I want the automation to land on the Ixigo home page and navigate to the Flights section, so that subsequent search steps operate on the correct module.

#### Acceptance Criteria

1. WHEN the browser loads `https://www.ixigo.com`, THE HomePage SHALL confirm the page is displayed by verifying the browser title contains the text "ixigo".
2. WHEN `clickFlights()` is called, THE HomePage SHALL locate and click the Flights navigation element using a resilient multi-XPath locator that matches at least one of: anchor text "Flights", a flights list-item child anchor, or a span-text "Flights" parent anchor.
3. IF the Flights navigation element is not found within the configured explicit wait period, THEN THE HomePage SHALL throw a `TimeoutException` with a descriptive message.

---

### Requirement 2: Flight Search Form Interaction

**User Story:** As a test engineer, I want the automation to fill in the flight search form with origin, destination, and departure date, so that the correct flight results are returned.

#### Acceptance Criteria

1. WHEN `enterFrom(from)` is called with a non-empty city or airport string, THE SearchPage SHALL clear the From input, type the string, wait for the autocomplete dropdown, and select the first suggestion so that the From input field value is non-empty after the call.
2. WHEN `enterTo(to)` is called with a non-empty city or airport string, THE SearchPage SHALL clear the To input, type the string, wait for the autocomplete dropdown, and select the first suggestion so that the To input field value is non-empty after the call.
3. WHEN `selectDepartureDate()` is called, THE SearchPage SHALL open the date picker and select a calendar day whose date is `LocalDate.now().plusDays(7)`, ensuring the selected date is always greater than or equal to the current date.
4. IF the autocomplete dropdown does not open after typing, THEN THE SearchPage SHALL retry by dispatching a JavaScript `dispatchEvent` trigger before pressing `Keys.ARROW_DOWN + ENTER`.
5. IF the autocomplete dropdown still does not open after the retry, THEN THE SearchPage SHALL fail the current test step with a descriptive assertion message.
6. WHEN `clickSearch()` is called, THE SearchPage SHALL click the Search button using a native Selenium click with a JavaScript click fallback if the primary click is intercepted.

---

### Requirement 3: Flight List — Filter and Selection

**User Story:** As a test engineer, I want the automation to optionally apply a Non-stop filter and select a flight from the results list, so that the booking flow proceeds with the intended flight.

#### Acceptance Criteria

1. WHEN the flight results page loads, THE FlightListPage SHALL wait for at least one flight result card to become visible before any further interaction.
2. WHEN `applyFilters()` is called and the Non-stop filter element is present, THE FlightListPage SHALL click that filter element.
3. WHEN `applyFilters()` is called and the Non-stop filter element is absent, THE FlightListPage SHALL log the absence and continue execution without throwing an exception.
4. WHEN `isFlightAvailable()` is called, THE FlightListPage SHALL return `true` if at least one Book/View-Prices button is present on the page, and `false` otherwise.
5. IF `isFlightAvailable()` returns `false`, THEN THE FlightListPage SHALL throw a `RuntimeException` with the message "No flight cards found on results page".
6. WHEN `selectFlight(index)` is called with a valid index, THE FlightListPage SHALL scroll to the corresponding Book/View-Prices button and click it, using a JavaScript click fallback if the primary click is intercepted.

---

### Requirement 4: Optional Fare Selection

**User Story:** As a test engineer, I want the automation to handle the optional fare selection page gracefully, so that the test does not fail when this page is absent.

#### Acceptance Criteria

1. WHEN `isFarePagePresent()` is called, THE FareSelectionPage SHALL wait up to 5 seconds for a fare card or fare option element to appear and return `true` if found.
2. IF no fare card or fare option element appears within 5 seconds, THEN THE FareSelectionPage SHALL return `false` from `isFarePagePresent()` without throwing an exception.
3. WHEN `selectFareIfPresent()` is called and `isFarePagePresent()` returns `true`, THE FareSelectionPage SHALL click the first available fare option and then click the Continue button.
4. WHEN `selectFareIfPresent()` is called and `isFarePagePresent()` returns `false`, THE FareSelectionPage SHALL return immediately without performing any action or throwing an exception.

---

### Requirement 5: Traveller Details Entry

**User Story:** As a test engineer, I want the automation to fill in the adult traveller details form, so that the booking can proceed to the payment page.

#### Acceptance Criteria

1. WHEN `isTravellerPageDisplayed()` is called, THE TravellerDetailsPage SHALL return `true` if the First Name input field is visible, and `false` otherwise.
2. WHEN `selectTitle()` is called, THE TravellerDetailsPage SHALL select the "Mr" title option using a JavaScript click to handle React-rendered button selectors.
3. WHEN any text-entry method (`enterFirstName`, `enterLastName`, `enterMobile`, `enterEmail`) is called with a value string, THE TravellerDetailsPage SHALL scroll the target field into view, clear it, and send the value via `sendKeys`.
4. IF after `sendKeys` the field's `getAttribute("value")` does not equal the supplied value, THEN THE TravellerDetailsPage SHALL fall back to setting the field value via `JavascriptExecutor` and dispatching a React change event.
5. WHEN `clickContinue()` is called, THE TravellerDetailsPage SHALL click the Continue/Proceed/Review button using a JavaScript click fallback if the primary click is intercepted.

---

### Requirement 6: Excel Test Data — FlightData Sheet

**User Story:** As a test engineer, I want the automation to read flight test data from a dedicated Excel sheet, so that test inputs are data-driven and independent of the source code.

#### Acceptance Criteria

1. THE DataProviderClass SHALL expose a `@DataProvider` named `"FlightData"` that reads from the `FlightData` sheet of `Data.xlsx` and returns an `Object[][]` where each row contains exactly 6 columns in order: `mobile`, `from`, `to`, `name`, `lastName`, `email`.
2. WHEN the `FlightData` sheet contains one or more data rows, THE DataProviderClass SHALL return one `Object[]` per data row.
3. THE `FlightData` sheet SHALL contain the following column headers in row 1: `mobile`, `from`, `to`, `name`, `lastName`, `email`.
4. THE `mobile` column value SHALL be a non-empty numeric string of exactly 10 digits.
5. THE `from` and `to` column values SHALL be non-empty strings that are not equal to each other.
6. THE `name` and `lastName` column values SHALL be non-empty alphabetic strings.
7. THE `email` column value SHALL be a non-empty string containing the `@` character.

---

### Requirement 7: End-to-End Test Orchestration

**User Story:** As a test engineer, I want a single TestNG test class to orchestrate the complete flight booking flow, so that all steps execute in order and results are captured in an ExtentReport.

#### Acceptance Criteria

1. THE FlightBookingTest SHALL extend `Hooks` and be annotated with `@Listeners(ExtentListener.class)`.
2. THE FlightBookingTest SHALL declare a `@BeforeClass` method that initialises all required page object instances: `HomePage`, `LoginPage`, `SearchPage`, `FlightListPage`, `FareSelectionPage`, and `TravellerDetailsPage`.
3. THE FlightBookingTest SHALL declare a `@Test(priority=1)` method annotated with `@DataProvider(name="FlightData", dataProviderClass=DataProviderClass.class)` that stores the six test data fields as instance variables.
4. THE FlightBookingTest SHALL declare `@Test` methods at priorities 2 through 8, each delegating to the corresponding page object method(s) in the sequence: home page verification (2), OTP login (3), flight search (4), filter application (5), flight selection (6), fare selection (7), traveller details (8).
5. WHEN any `@Test` method fails, THE ExtentListener SHALL capture a screenshot and log the failure in the ExtentReport HTML output.
6. THE `testng.xml` file SHALL reference `FlightBookingTest` as the test class and shall NOT reference `BusBookingTest`.

---

### Requirement 8: Reporting Configuration

**User Story:** As a test engineer, I want the ExtentReports HTML report to be labelled for the Flight module, so that reports are clearly identifiable.

#### Acceptance Criteria

1. THE ExtentManager SHALL initialise the ExtentReports instance with the report name `"Flight Booking Automation"`.
2. WHEN the test suite completes, THE ExtentManager SHALL flush the report to the configured output path.

---

### Requirement 9: Resilient Element Interaction

**User Story:** As a test engineer, I want all click and input interactions to use defensive fallback mechanisms, so that transient overlay spinners and React-controlled inputs do not cause unnecessary test failures.

#### Acceptance Criteria

1. WHEN a native Selenium click on any interactive element raises an `ElementClickInterceptedException`, THE System SHALL retry the click using `Actions.click()` and, if still intercepted, fall back to a `JavascriptExecutor` click.
2. WHEN a `sendKeys` call does not populate a React-controlled input field (detected by an empty `getAttribute("value")` after the call), THE System SHALL fall back to setting the value via `JavascriptExecutor` and dispatching a `change` event on the element.
3. WHILE any page transition is in progress, THE System SHALL use `WebDriverWait` with the explicit wait timeout defined in `Config.properties` before interacting with elements on the new page.

---

### Requirement 10: Framework File Changes

**User Story:** As a test engineer, I want clearly defined file creation, modification, and deletion actions, so that the existing Bus module is fully replaced without residual artefacts.

#### Acceptance Criteria

1. THE System SHALL create the following new files: `FlightListPage.java`, `FareSelectionPage.java`, `TravellerDetailsPage.java`, and `FlightBookingTest.java` at their specified package paths.
2. THE System SHALL modify the following existing files: `HomePage.java` (add `clickFlights()`, update locator), `SearchPage.java` (complete rewrite for flight form), `DataProviderClass.java` (rename data provider and sheet to `"FlightData"`), `ExtentManager.java` (update report name), and `testng.xml` (update class reference).
3. THE System SHALL delete the following obsolete files: `BusListPage.java`, `SeatSelectionPage.java`, `PassengerPage.java`, and `BusBookingTest.java`.
4. THE following files SHALL remain unchanged: `BasePage.java`, `LoginPage.java`, `ExcelReader.java`, `PropertyReader.java`, `SetupDriver.java`, `Hooks.java`, `ExtentListener.java`, `Screenshot.java`, `pom.xml`, `Config.properties`.
