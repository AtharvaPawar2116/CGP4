# Implementation Plan: Ixigo Flight Booking Automation

## Overview

Adapt the existing Ixigo Bus automation framework to the Flight module by modifying page objects, creating new page classes, rewriting the test orchestration class, updating the data provider and reporting config, and cleaning up all bus-specific artefacts. All code is Java (Selenium 4 + TestNG 7 + POM). No new Maven dependencies are needed.

## Tasks

- [x] 1. Modify `HomePage.java` — add Flights navigation
  - Remove the `busesLink` `@FindBy` field and `clickBuses()` method
  - Add `@FindBy` field `flightsLink` using multi-XPath: `"//a[contains(text(),'Flights')] | //li[contains(@class,'flights')]//a | //span[text()='Flights']/parent::a"`
  - Add `clickFlights()` method that waits for `flightsLink` to be clickable and calls `.click()`
  - Keep `isHomePageDisplayed()` unchanged
  - _Requirements: 1.1, 1.2, 1.3, 10.2_

- [x] 2. Rewrite `SearchPage.java` — flight search form
  - [x] 2.1 Rewrite `SearchPage.java` with flight-specific locators and methods
    - Replace all bus-era locators with four `@FindBy` fields: `fromInput`, `toInput`, `departureDateInput`, `searchButton` (use multi-XPath resilient locators from design)
    - Implement `enterFrom(String from)`: wait for clickable, use `Actions` to click + sendKeys + ARROW_DOWN + ENTER; retry with JS `dispatchEvent` if dropdown does not open (Requirement 2.4, 2.5)
    - Implement `enterTo(String to)` with the same pattern as `enterFrom`
    - Implement `selectDepartureDate()`: compute `LocalDate.now().plusDays(7)`, open the date picker by clicking `departureDateInput`, then locate the calendar day cell dynamically via XPath containing the day-of-month string; click it (Requirement 2.3)
    - Implement `clickSearch()` with native click + JS fallback (Requirement 2.6)
    - Keep `isSearchButtonDisplayed()` as-is
    - Add `JavascriptExecutor js` and `Actions actions` fields initialised in constructor
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 10.2_
  - [ ]* 2.2 Write property test for From-field population (Property 2)
    - **Property 2: From-Field Population**
    - **Validates: Requirements 2.1**
  - [ ]* 2.3 Write property test for To-field population (Property 3)
    - **Property 3: To-Field Population**
    - **Validates: Requirements 2.2**
  - [ ]* 2.4 Write property test for departure date always in the future (Property 4)
    - **Property 4: Departure Date Is Always in the Future**
    - **Validates: Requirements 2.3**

- [x] 3. Create `FlightListPage.java` — flight results, filters, and selection
  - [x] 3.1 Create `src/test/java/com/pages/FlightListPage.java`
    - Extend `BasePage`; add `JavascriptExecutor js` initialised in constructor
    - Add `List<WebElement> nonStopFilter` via multi-XPath for Non-stop label/button
    - Add `List<WebElement> bookButtons` via multi-XPath for Book / View Prices buttons
    - Implement `applyFilters()`: wait for results page to settle, check `nonStopFilter.size() > 0`, click the first element if present, log and continue if absent — must never throw (Requirement 3.2, 3.3)
    - Implement `isFlightAvailable()`: return `bookButtons.size() > 0` (Requirement 3.4)
    - Implement `selectFlight(int index)`: wait for at least one book button with `ExpectedConditions.presenceOfElementLocated`; throw `RuntimeException("No flight cards found on results page")` if none (Requirement 3.5); resolve target index safely (use 0 if out of range); scroll into view via JS; click with native + JS fallback (Requirement 3.6)
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 10.1_
  - [ ]* 3.2 Write property test for filter application never throws (Property 5)
    - **Property 5: Filter Application Never Throws**
    - **Validates: Requirements 3.2, 3.3**
  - [ ]* 3.3 Write property test for flight availability check (Property 6)
    - **Property 6: Flight Availability Check**
    - **Validates: Requirements 3.4**

- [x] 4. Create `FareSelectionPage.java` — optional fare page handler
  - [x] 4.1 Create `src/test/java/com/pages/FareSelectionPage.java`
    - Extend `BasePage`; add `JavascriptExecutor js` initialised in constructor
    - Define `fareCardLocator` as a `By` constant with multi-XPath for fare-card / fareType / Saver / Flexi elements (from design)
    - Implement `isFarePagePresent()`: create a local `WebDriverWait` of 5 seconds, wait for `presenceOfElementLocated(fareCardLocator)`, return `true` on success and `false` on `TimeoutException` — must NOT let any exception propagate (Requirements 4.1, 4.2)
    - Implement `selectFareIfPresent()`: call `isFarePagePresent()`; if `false`, return immediately; if `true`, find fare elements, click the first one via JS click, then locate and click the Continue button (Requirement 4.3, 4.4)
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 10.1_
  - [ ]* 4.2 Write property test for graceful optional fare page (Property 7)
    - **Property 7: Graceful Optional Fare Page**
    - **Validates: Requirements 4.2, 4.4**

- [x] 5. Create `TravellerDetailsPage.java` — traveller form entry
  - [x] 5.1 Create `src/test/java/com/pages/TravellerDetailsPage.java`
    - Extend `BasePage`; add `JavascriptExecutor js` initialised in constructor
    - Add `@FindBy` fields: `titleMr`, `firstName`, `lastName`, `mobile`, `email`, `continueBtn` using resilient multi-XPath from design
    - Implement `isTravellerPageDisplayed()`: wait up to 30 s for `firstName` to be visible; return `true` / `false` (Requirement 5.1)
    - Implement `selectTitle()`: wait for `titleMr` to be clickable, use `js.executeScript("arguments[0].click();", titleMr)` (Requirement 5.2)
    - Implement private helper `typeIntoField(WebElement el, String value)`: scroll into view via JS, `el.clear()`, `el.sendKeys(value)`, check `getAttribute("value")`; if empty, fall back to `js.executeScript("arguments[0].value=arguments[1];", el, value)` and dispatch a React `change` event (Requirements 5.3, 5.4, 9.2)
    - Implement `enterFirstName(String firstName)`, `enterLastName(String lastName)`, `enterMobile(String mobile)`, `enterEmail(String email)` — each delegates to `typeIntoField`
    - Implement `clickContinue()`: wait for `continueBtn` clickable, try native click, catch `ElementClickInterceptedException` → `Actions` click, catch again → `js.executeScript("arguments[0].click();", continueBtn)` (Requirements 5.5, 9.1)
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 9.1, 9.2, 10.1_
  - [ ]* 5.2 Write property test for text input round-trip (Property 8)
    - **Property 8: Text Input Round-Trip**
    - **Validates: Requirements 5.3, 5.4**

- [x] 6. Checkpoint — Verify all new page classes compile
  - Ensure all tests pass, ask the user if questions arise.

- [x] 7. Modify `DataProviderClass.java` — rename to FlightData provider
  - Change `@DataProvider(name="BusData")` to `@DataProvider(name="FlightData")`
  - Change `ExcelReader.getExcelData(path, "BusData")` to `ExcelReader.getExcelData(path, "FlightData")`
  - Update the method signature: return type stays `Object[][]`, parameter count stays zero
  - _Requirements: 6.1, 6.2, 10.2_

- [x] 8. Update `Data.xlsx` — add FlightData sheet with sample data
  - Open `src/test/resources/ExcelData/Data.xlsx` and add a new sheet named exactly `FlightData`
  - Row 1 (headers): `mobile`, `from`, `to`, `name`, `lastName`, `email`
  - Row 2 (sample data): a 10-digit mobile number, a departure city (e.g. `Delhi`), a different arrival city (e.g. `Mumbai`), a first name (e.g. `John`), a last name (e.g. `Doe`), and a valid email address (e.g. `john.doe@example.com`)
  - Ensure `from` ≠ `to` in the sample row
  - _Requirements: 6.1, 6.3, 6.4, 6.5, 6.6, 6.7_

- [x] 9. Modify `ExtentManager.java` — update report metadata for Flight module
  - Change `spark.config().setReportName("Bus Booking Automation")` to `spark.config().setReportName("Flight Booking Automation")`
  - Change `extent.setSystemInfo("Project", "Ixigo Bus Automation")` to `extent.setSystemInfo("Project", "Ixigo Flight Automation")`
  - Leave all other settings (document title, tester name, framework) unchanged
  - _Requirements: 8.1, 8.2, 10.2_

- [x] 10. Create `FlightBookingTest.java` — end-to-end test orchestration
  - [x] 10.1 Create `src/test/java/com/test/FlightBookingTest.java`
    - Annotate class with `@Listeners(com.utils.ExtentListener.class)` and extend `Hooks`
    - Declare page object fields: `HomePage home`, `LoginPage login`, `SearchPage search`, `FlightListPage flightList`, `FareSelectionPage fareSelection`, `TravellerDetailsPage travellerDetails`
    - Declare instance variable fields: `String mobile, from, to, name, lastName, email`
    - Implement `@BeforeClass initializePages()` — instantiate all six page objects using `driver` from `Hooks`
    - `@Test(priority=1, dataProvider="FlightData", dataProviderClass=DataProviderClass.class) getTestData(String mobile, String from, String to, String name, String lastName, String email)` — assign the six parameters to instance variables
    - `@Test(priority=2) homePage()` — `Assert.assertTrue(home.isHomePageDisplayed())`, then `home.clickFlights()`
    - `@Test(priority=3) loginTest()` — mirrors `BusBookingTest.loginTest()` exactly (switchToLoginFrame, enterMobileNumber, clickContinue, waitForOTPVerification, switchToDefaultContent, Assert isLoginSuccessful)
    - `@Test(priority=4) searchFlight()` — `search.enterFrom(from)`, `search.enterTo(to)`, `search.selectDepartureDate()`, `Assert.assertTrue(search.isSearchButtonDisplayed())`, `search.clickSearch()`
    - `@Test(priority=5) applyFilters()` — `flightList.applyFilters()`
    - `@Test(priority=6) selectFlight()` — `flightList.selectFlight(0)`
    - `@Test(priority=7) handleFareSelection()` — `fareSelection.selectFareIfPresent()`
    - `@Test(priority=8) travellerDetails()` — `Assert.assertTrue(travellerDetails.isTravellerPageDisplayed())`, `travellerDetails.selectTitle()`, `travellerDetails.enterFirstName(name)`, `travellerDetails.enterLastName(lastName)`, `travellerDetails.enterMobile(mobile)`, `travellerDetails.enterEmail(email)`, `travellerDetails.clickContinue()`
    - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5, 7.6, 10.1_
  - [ ]* 10.2 Write unit tests for DataProvider column mapping (Property 9)
    - **Property 9: DataProvider Column Mapping**
    - **Validates: Requirements 6.1, 6.2**
  - [ ]* 10.3 Write unit tests for From/To uniqueness constraint (Property 10)
    - **Property 10: From and To Must Differ**
    - **Validates: Requirements 6.5**

- [x] 11. Modify `testng.xml` — update test suite for Flight module
  - Change `<test name="Bus Booking Test">` to `<test name="Flight Booking Test">`
  - Change `<class name="com.test.BusBookingTest"/>` to `<class name="com.test.FlightBookingTest"/>`
  - Keep the `<parameter name="browser" value="chrome"/>` line unchanged
  - _Requirements: 7.6, 10.2_

- [x] 12. Delete obsolete bus-specific files
  - Delete `src/test/java/com/pages/BusListPage.java`
  - Delete `src/test/java/com/pages/SeatSelectionPage.java`
  - Delete `src/test/java/com/pages/PassengerPage.java`
  - Delete `src/test/java/com/test/BusBookingTest.java`
  - _Requirements: 10.3_

- [x] 13. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for a faster MVP delivery
- Each task references specific requirements for traceability
- The design document uses Java throughout; no language selection prompt was needed
- `LoginPage.java`, `BasePage.java`, `ExcelReader.java`, `PropertyReader.java`, `SetupDriver.java`, `Hooks.java`, `ExtentListener.java`, `Screenshot.java`, `pom.xml`, and `Config.properties` are unchanged per Requirement 10.4
- OTP entry at priority-3 requires a human in the loop — the test pauses automatically via `waitForOTPVerification()`
- Property tests (tasks 2.2–2.4, 3.2–3.3, 4.2, 5.2, 10.2–10.3) validate universal correctness properties from the design document's "Correctness Properties" section
