# Design Document: Ixigo Flight Automation

## Overview

This document describes the technical design for adapting the existing Ixigo Bus automation project to instead automate the **Flight module** of [https://www.ixigo.com](https://www.ixigo.com). The project architecture, framework patterns, and toolchain remain identical (Selenium 4 + TestNG 7 + Page Object Model, Maven, ExtentReports, Apache POI); only the page classes, locators, test data, and orchestration test are replaced or rewritten to target the flight booking flow rather than the bus booking flow.

---

## Architecture

The framework follows the same layered Page Object Model architecture as the Bus module. No structural or build changes are required.

```mermaid
graph TD
    A[testng.xml] -->|runs| B[FlightBookingTest]
    B -->|extends| C[Hooks / SetupDriver]
    B -->|uses| D[DataProviderClass - FlightData]
    D -->|reads| E[ExcelReader → Data.xlsx / FlightData sheet]
    B -->|orchestrates| F[HomePage]
    B -->|orchestrates| G[LoginPage - unchanged]
    B -->|orchestrates| H[SearchPage - flight rewrite]
    B -->|orchestrates| I[FlightListPage]
    B -->|orchestrates| J[FareSelectionPage - optional]
    B -->|orchestrates| K[TravellerDetailsPage]
    F & G & H & I & J & K -->|extends| L[BasePage]
    L -->|wraps| M[WebDriver / WebDriverWait / PageFactory]
    B -->|reporting| N[ExtentListener → ExtentManager]
    N -->|screenshots| O[Screenshot utility]
```

### Sequence Diagram — End-to-End Flight Booking Flow

```mermaid
sequenceDiagram
    participant T as FlightBookingTest
    participant H as HomePage
    participant L as LoginPage
    participant S as SearchPage
    participant FL as FlightListPage
    participant FS as FareSelectionPage
    participant TD as TravellerDetailsPage

    T->>H: isHomePageDisplayed()
    T->>H: clickFlights()
    H-->>T: navigates to /flights
    T->>L: switchToLoginFrame()
    T->>L: enterMobileNumber(mobile)
    T->>L: clickContinue()
    Note over T,L: Manual OTP entry (same as bus flow)
    T->>L: waitForOTPVerification()
    T->>L: switchToDefaultContent()
    T->>S: enterFrom(from)
    T->>S: enterTo(to)
    T->>S: selectDepartureDate()
    T->>S: clickSearch()
    S-->>T: results page loaded
    T->>FL: applyFilters()
    T->>FL: selectFlight(index)
    FL-->>T: navigates to fare/traveller page
    T->>FS: selectFareIfPresent() [optional - graceful skip]
    FS-->>T: fare selected or skipped
    T->>TD: isTravellerPageDisplayed()
    T->>TD: selectTitle()
    T->>TD: enterFirstName(name)
    T->>TD: enterLastName(lastName)
    T->>TD: enterMobile(mobile)
    T->>TD: enterEmail(email)
    T->>TD: clickContinue()
    TD-->>T: reaches payment page
```

---

## Components and Interfaces

### Component 1: HomePage (modified)

**Purpose**: Navigate from the Ixigo home page to the Flights section.

**Interface**:
```java
public class HomePage extends BasePage {
    public HomePage(WebDriver driver);
    public void clickFlights();
    public boolean isHomePageDisplayed();
}
```

**Responsibilities**:
- Wait for and click the "Flights" navigation link using resilient multi-XPath
- Confirm the home page title contains "ixigo"

**Key locator** (multi-XPath, resilient):
```java
@FindBy(xpath = "//a[contains(text(),'Flights')] | //li[contains(@class,'flights')]//a | //span[text()='Flights']/parent::a")
WebElement flightsLink;
```

---

### Component 2: SearchPage (complete rewrite for flights)

**Purpose**: Interact with the flight search form — From/To city autocomplete, date picker, and Search button.

**Interface**:
```java
public class SearchPage extends BasePage {
    public SearchPage(WebDriver driver);
    public void enterFrom(String from);
    public void enterTo(String to);
    public void selectDepartureDate();
    public void clickSearch();
    public boolean isSearchButtonDisplayed();
}
```

**Responsibilities**:
- Clear and type into "From" autocomplete, wait for dropdown, select first suggestion via `Keys.ARROW_DOWN + ENTER`
- Same pattern for "To" autocomplete
- Open the date picker and click a date ~7 days from today (computed dynamically via `LocalDate`)
- Click the Search button, using JS fallback if the primary click is intercepted
- The Travellers/Class selector is left at its default (1 Adult, Economy) — no action needed unless test data specifies otherwise

**Key locators**:
```java
@FindBy(xpath = "//input[@placeholder='From' or @placeholder='From City or Airport' or contains(@id,'from') or contains(@class,'origin')]")
WebElement fromInput;

@FindBy(xpath = "//input[@placeholder='To' or @placeholder='To City or Airport' or contains(@id,'to') or contains(@class,'destination')]")
WebElement toInput;

@FindBy(xpath = "//div[contains(@class,'depart') or contains(@class,'date')]//input | //input[@placeholder='Departure Date'] | //div[contains(@class,'DayPicker')]//ancestor::div[contains(@class,'date')]")
WebElement departureDateInput;

@FindBy(xpath = "//button[contains(text(),'Search') or contains(@class,'search-btn') or contains(@class,'searchButton')]")
WebElement searchButton;
```

**Date selection strategy** (dynamic, avoids hardcoded index):
```java
// Compute target date text (+7 days) and find its calendar cell
LocalDate target = LocalDate.now().plusDays(7);
String dayStr = String.valueOf(target.getDayOfMonth());
By dayLocator = By.xpath(
    "//div[contains(@class,'DayPicker') or contains(@class,'calendar')]" +
    "//div[@aria-label or @data-date][normalize-space()='" + dayStr + "'][not(@disabled) and not(contains(@class,'disabled'))]" +
    " | //td[contains(@class,'day') and normalize-space()='" + dayStr + "' and not(contains(@class,'disabled'))]"
);
```

---

### Component 3: FlightListPage (new — replaces BusListPage)

**Purpose**: Handle the flight results page: apply optional filters and select a flight to proceed to booking.

**Interface**:
```java
public class FlightListPage extends BasePage {
    public FlightListPage(WebDriver driver);
    public void applyFilters();
    public void selectFlight(int index);
    public boolean isFlightAvailable();
}
```

**Responsibilities**:
- Wait for flight result cards to load
- Optionally apply "Non-stop" filter (graceful — logs and continues if filter is absent)
- Scroll to the target flight card and click its Book/View Prices button, with JS fallback
- `isFlightAvailable()` returns true if at least one book button is present

**Key locators**:
```java
// Filter labels/buttons
@FindBy(xpath = "//div[contains(@class,'filter')]//label[contains(text(),'Non stop') or contains(text(),'Non-stop') or contains(text(),'Nonstop')] | //button[contains(@class,'filter') and contains(.,'Non')]")
List<WebElement> nonStopFilter;

// Flight result cards
@FindBy(xpath = "//div[contains(@class,'flight-card')] | //div[contains(@class,'result-item')] | //div[contains(@class,'flight-listing')]//div[contains(@class,'item')]")
List<WebElement> flightCards;

// Book buttons
@FindBy(xpath = "//button[contains(text(),'Book') or contains(text(),'View Prices') or contains(@class,'book-btn') or contains(@class,'bookBtn')]")
List<WebElement> bookButtons;
```

---

### Component 4: FareSelectionPage (new — optional intermediate page)

**Purpose**: Handle the optional fare type selection page (Saver / Flexi / etc.) that may appear after selecting a flight. The test must gracefully skip this page if it does not appear.

**Interface**:
```java
public class FareSelectionPage extends BasePage {
    public FareSelectionPage(WebDriver driver);
    public boolean isFarePagePresent();
    public void selectFareIfPresent();
}
```

**Responsibilities**:
- Detect presence of fare selection cards within a short timeout (5 seconds)
- If present: click the first available fare option, then click Continue
- If absent: return immediately without throwing an exception

**Detection strategy** (short-circuit wait — does NOT fail if absent):
```java
public boolean isFarePagePresent() {
    try {
        new WebDriverWait(driver, Duration.ofSeconds(5))
            .until(ExpectedConditions.presenceOfElementLocated(fareCardLocator));
        return true;
    } catch (TimeoutException e) {
        return false;
    }
}
```

**Key locators**:
```java
private final By fareCardLocator = By.xpath(
    "//div[contains(@class,'fare-card')] | //div[contains(@class,'fareType')] | " +
    "//div[contains(@class,'fare') and contains(@class,'option')] | " +
    "//button[contains(@class,'fare') or contains(text(),'Saver') or contains(text(),'Flexi')]"
);
```

---

### Component 5: TravellerDetailsPage (new — replaces PassengerPage)

**Purpose**: Fill in the adult traveller details form on the flight booking page.

**Interface**:
```java
public class TravellerDetailsPage extends BasePage {
    public TravellerDetailsPage(WebDriver driver);
    public boolean isTravellerPageDisplayed();
    public void selectTitle();
    public void enterFirstName(String firstName);
    public void enterLastName(String lastName);
    public void enterMobile(String mobile);
    public void enterEmail(String email);
    public void clickContinue();
}
```

**Responsibilities**:
- Confirm the traveller form is visible before any interaction
- Select "Mr" title from the dropdown/button selector using JS click
- Enter first name, last name, mobile number, and email address
- For each input: scroll into view → clear → sendKeys → JS-value fallback if field stays empty
- Click Continue/Proceed/Review button using JS fallback

**Key locators**:
```java
@FindBy(xpath = "//div[contains(@class,'title')]//button[contains(text(),'Mr') or @value='Mr'] | //select[contains(@name,'title') or contains(@id,'title')]//option[@value='Mr'] | //li[normalize-space()='Mr']")
WebElement titleMr;

@FindBy(xpath = "//input[@placeholder='First Name' or @name='firstName' or @name='first_name' or contains(@placeholder,'First')]")
WebElement firstName;

@FindBy(xpath = "//input[@placeholder='Last Name' or @name='lastName' or @name='last_name' or contains(@placeholder,'Last')]")
WebElement lastName;

@FindBy(xpath = "//input[@placeholder='Mobile Number' or @placeholder='Mobile' or @type='tel' or contains(@placeholder,'Mobile') or contains(@name,'mobile') or contains(@name,'phone')]")
WebElement mobile;

@FindBy(xpath = "//input[@placeholder='Email' or @type='email' or contains(@placeholder,'Email') or @name='email']")
WebElement email;

@FindBy(xpath = "//button[contains(text(),'Continue') or contains(text(),'Proceed') or contains(text(),'Review') or contains(@class,'continue-btn') or contains(@class,'proceed')]")
WebElement continueBtn;
```

---

### Component 6: DataProviderClass (modified)

**Purpose**: Provide test data for the flight test from the `FlightData` Excel sheet.

**Interface**:
```java
public class DataProviderClass {
    @DataProvider(name = "FlightData")
    public Object[][] getData() throws IOException;
}
```

**Change**: Rename `@DataProvider` from `"BusData"` to `"FlightData"` and change sheet name argument from `"BusData"` to `"FlightData"`.

---

### Component 7: FlightBookingTest (new — replaces BusBookingTest)

**Purpose**: Orchestrate all test steps using TestNG `@Test` methods with priorities, the same structural approach as `BusBookingTest`.

**Interface**:
```java
@Listeners(com.utils.ExtentListener.class)
public class FlightBookingTest extends Hooks {
    @BeforeClass public void initializePages();
    @Test(priority=1, dataProvider="FlightData", dataProviderClass=DataProviderClass.class)
    public void getTestData(String mobile, String from, String to, String name, String lastName, String email);
    @Test(priority=2) public void homePage();
    @Test(priority=3) public void loginTest();
    @Test(priority=4) public void searchFlight();
    @Test(priority=5) public void applyFilters();
    @Test(priority=6) public void selectFlight();
    @Test(priority=7) public void handleFareSelection();
    @Test(priority=8) public void travellerDetails();
}
```

**Test data fields** (6 columns in `FlightData` sheet):
`mobile | from | to | name (firstName) | lastName | email`

---

## Data Models

### Excel Data Sheet — FlightData

The `Data.xlsx` file must contain a sheet named `FlightData` with the following columns (row 1 = header, row 2+ = data):

| Column | Header     | Example Value         |
|--------|------------|-----------------------|
| 0      | mobile     | 9876543210            |
| 1      | from       | Delhi                 |
| 2      | to         | Mumbai                |
| 3      | name       | John                  |
| 4      | lastName   | Doe                   |
| 5      | email      | john.doe@example.com  |

**Validation Rules**:
- `mobile`: non-empty, numeric string, 10 digits
- `from` / `to`: non-empty city or airport name strings; must differ from each other
- `name` / `lastName`: non-empty alphabetic strings
- `email`: non-empty string containing `@`

### Config.properties (unchanged)

```properties
browser=chrome
url=https://www.ixigo.com
implicitWait=5
explicitWait=40
```

---

## Error Handling

### Error Scenario 1: Fare Selection Page Not Present

**Condition**: After clicking Book on a flight card, the page navigates directly to the traveller details form, skipping fare selection.  
**Response**: `FareSelectionPage.isFarePagePresent()` returns `false` after a 5-second timeout; `selectFareIfPresent()` returns without action.  
**Recovery**: Test execution continues uninterrupted with `travellerDetails()` at priority 8.

### Error Scenario 2: Autocomplete Dropdown Fails to Open

**Condition**: The "From" or "To" input does not present a dropdown suggestion after typing.  
**Response**: `SearchPage.enterFrom/enterTo` logs the issue and re-tries with a JS `dispatchEvent` trigger before `Keys.ARROW_DOWN + ENTER`.  
**Recovery**: If still no dropdown, the test fails at `searchFlight()` with a meaningful assertion message.

### Error Scenario 3: No Flights Found After Search

**Condition**: The flight results page shows zero flight cards (e.g., no flights for the given route/date).  
**Response**: `FlightListPage.isFlightAvailable()` returns `false`; `selectFlight()` throws `RuntimeException("No flight cards found on results page")`.  
**Recovery**: TestNG marks the test as failed; ExtentListener captures a screenshot.

### Error Scenario 4: Traveller Input Field Stays Empty After sendKeys

**Condition**: React-controlled input does not register `sendKeys` (common on SPAs).  
**Response**: After `sendKeys`, check `getAttribute("value")`; if empty, fall back to `js.executeScript("arguments[0].value=arguments[1];", element, value)` then dispatch a React change event.  
**Recovery**: Field is populated via JS; test continues normally.

### Error Scenario 5: Element Not Clickable (intercepted by overlay/spinner)

**Condition**: A loading spinner or modal overlay is present when a click is attempted.  
**Response**: Wrap every click in a try/catch: native click → Actions click → JS click chain (identical pattern to `BusListPage.selectBus()` and `PassengerPage.clickContinue()`).  
**Recovery**: JS click bypasses the overlay; test continues.

---

## Testing Strategy

### Unit Testing Approach

Each page class method is independently testable by injecting a mock `WebDriver`. Key assertions per class:
- `HomePage.isHomePageDisplayed()` returns `true` when title contains "ixigo"
- `FlightListPage.isFlightAvailable()` returns `false` when no book buttons are found
- `FareSelectionPage.isFarePagePresent()` returns `false` on `TimeoutException`
- `TravellerDetailsPage.isTravellerPageDisplayed()` returns `true` when the first-name field is visible

### Property-Based Testing Approach

**Property Test Library**: Not applicable (UI automation end-to-end — no PBT framework used).

Properties validated through test design:

1. **Autocomplete resilience**: For any non-empty `from` string, `enterFrom(from)` must leave the From field non-empty after execution.
2. **Date picker future-only**: `selectDepartureDate()` always picks a date that is `>= LocalDate.now()` — never a past date.
3. **Graceful optional page**: For any browser state, `FareSelectionPage.selectFareIfPresent()` never throws an unchecked exception.
4. **Input fallback completeness**: For any `value` string, entering text via `sendKeys` + JS fallback results in `getAttribute("value").equals(value)`.

### Integration Testing Approach

The `FlightBookingTest` class itself serves as the integration test suite. Each `@Test(priority=N)` method is a sequential integration step. TestNG dependency chain via `priority` ensures:
- Steps 2–8 depend on step 1 (data loaded)
- Steps 3–8 depend on step 2 (navigation confirmed)
- ExtentReports captures pass/fail/screenshot for every step

---

## Performance Considerations

- All explicit waits use `WebDriverWait` with 30-second timeout (inherited from `BasePage`) — consistent with the bus module.
- `Thread.sleep` usage is minimized and retained only where React state transitions require a brief stabilization pause (same pattern as `SeatSelectionPage`).
- `FareSelectionPage` uses a short 5-second `WebDriverWait` to avoid blocking the overall test when the page is absent.
- The flight search results page may take longer to load than the bus list; if needed, the `isFlightAvailable()` wait can be extended without changing other waits.

---

## Security Considerations

- OTP-based login is kept exactly as-is (`LoginPage.java` unchanged) — no credentials are stored in code or config.
- Mobile number and email come from Excel test data — sensitive test data should not be committed to version control.
- No payment step is executed; the test stops at the payment page URL without submitting any financial data.

---

## Files Summary

### Files to Create (new)

| File | Description |
|------|-------------|
| `src/test/java/com/pages/FlightListPage.java` | Replaces `BusListPage.java` |
| `src/test/java/com/pages/FareSelectionPage.java` | New — optional fare page handler |
| `src/test/java/com/pages/TravellerDetailsPage.java` | Replaces `PassengerPage.java` |
| `src/test/java/com/test/FlightBookingTest.java` | Replaces `BusBookingTest.java` |

### Files to Modify

| File | Change |
|------|--------|
| `src/test/java/com/pages/HomePage.java` | `clickBuses()` → `clickFlights()`, update `@FindBy` locator |
| `src/test/java/com/pages/SearchPage.java` | Complete rewrite for flight search form |
| `src/test/java/com/parameter/DataProviderClass.java` | `"BusData"` → `"FlightData"` |
| `src/test/java/com/utils/ExtentManager.java` | Report name `"Bus Booking Automation"` → `"Flight Booking Automation"` |
| `testng.xml` | Test name + class reference → `FlightBookingTest` |

### Files to Delete

| File | Reason |
|------|--------|
| `src/test/java/com/pages/BusListPage.java` | Replaced by `FlightListPage.java` |
| `src/test/java/com/pages/SeatSelectionPage.java` | No seat map in flights flow |
| `src/test/java/com/pages/PassengerPage.java` | Replaced by `TravellerDetailsPage.java` |
| `src/test/java/com/test/BusBookingTest.java` | Replaced by `FlightBookingTest.java` |

### Files Unchanged

`BasePage.java`, `LoginPage.java`, `ExcelReader.java`, `PropertyReader.java`, `SetupDriver.java`, `Hooks.java`, `ExtentListener.java`, `Screenshot.java`, `pom.xml`, `Config.properties`

---

## Dependencies

No new dependencies are required. The existing `pom.xml` already provides:

| Library | Version | Purpose |
|---------|---------|---------|
| selenium-java | 4.43.0 | Browser automation |
| testng | 7.11.0 | Test framework, DataProvider, Listeners |
| poi + poi-ooxml | 5.4.1 | Excel test data reading |
| webdrivermanager | 5.9.2 | Automatic ChromeDriver setup |
| extentreports | 5.1.1 | HTML reporting |
| commons-io | 2.21.0 | Screenshot file copy |


---

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Home Page Title Detection

*For any* `WebDriver` instance whose `getTitle()` returns a string containing "ixigo" (case-insensitive), `HomePage.isHomePageDisplayed()` SHALL return `true`; for any title that does not contain "ixigo", it SHALL return `false`.

**Validates: Requirements 1.1**

---

### Property 2: From-Field Population

*For any* non-empty city or airport string `from`, after `SearchPage.enterFrom(from)` completes without throwing, the From input element's `getAttribute("value")` SHALL be non-empty.

**Validates: Requirements 2.1**

---

### Property 3: To-Field Population

*For any* non-empty city or airport string `to`, after `SearchPage.enterTo(to)` completes without throwing, the To input element's `getAttribute("value")` SHALL be non-empty.

**Validates: Requirements 2.2**

---

### Property 4: Departure Date Is Always in the Future

*For any* calendar day on which `SearchPage.selectDepartureDate()` is executed, the date value selected in the date picker SHALL be greater than or equal to `LocalDate.now()` — it SHALL never be a past date.

**Validates: Requirements 2.3**

---

### Property 5: Filter Application Never Throws

*For any* browser state (Non-stop filter present or absent), `FlightListPage.applyFilters()` SHALL complete execution without throwing an unchecked exception.

**Validates: Requirements 3.2, 3.3**

---

### Property 6: Flight Availability Check

*For any* page state where zero Book/View-Prices buttons are present, `FlightListPage.isFlightAvailable()` SHALL return `false`; for any page state where at least one such button is present, it SHALL return `true`.

**Validates: Requirements 3.4**

---

### Property 7: Graceful Optional Fare Page

*For any* browser state — regardless of whether the fare selection page appears — `FareSelectionPage.selectFareIfPresent()` SHALL complete execution without throwing an unchecked exception.

**Validates: Requirements 4.2, 4.4**

---

### Property 8: Text Input Round-Trip

*For any* non-null string `value`, after calling a `TravellerDetailsPage` text-entry method (`enterFirstName`, `enterLastName`, `enterMobile`, `enterEmail`) with `value` — using the `sendKeys` + JS fallback sequence — the target input element's `getAttribute("value")` SHALL equal `value`.

**Validates: Requirements 5.3, 5.4**

---

### Property 9: DataProvider Column Mapping

*For any* valid `Data.xlsx` file containing a `FlightData` sheet with `N` data rows (N ≥ 1), `DataProviderClass.getData()` SHALL return an `Object[][]` of length `N` where every row has exactly 6 elements in the order: `[mobile, from, to, name, lastName, email]`.

**Validates: Requirements 6.1, 6.2**

---

### Property 10: From and To Must Differ

*For any* row in the `FlightData` sheet, the `from` value and the `to` value SHALL NOT be equal to each other.

**Validates: Requirements 6.5**
