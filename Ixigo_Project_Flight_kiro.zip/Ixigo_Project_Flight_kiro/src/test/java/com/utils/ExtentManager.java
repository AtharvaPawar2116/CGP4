package com.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {

    private static ExtentReports extent;

    public static ExtentReports getReport() {

        if (extent == null) {

            String reportPath = System.getProperty("user.dir")
                    + "/target/ExtentReport/Report.html";

            ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);

            spark.config().setDocumentTitle("Ixigo Automation Report");
            spark.config().setReportName("Flight Booking Automation");

            extent = new ExtentReports();

            extent.attachReporter(spark);

            extent.setSystemInfo("Project", "Ixigo Flight Automation");
            extent.setSystemInfo("Tester", "Siva Shankar");
            extent.setSystemInfo("Framework", "Selenium + TestNG + POM");

        }

        return extent;

    }

}