package com.test;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pages.FareSelectionPage;
import com.pages.FlightListPage;
import com.pages.HomePage;
import com.pages.LoginPage;
import com.pages.SearchPage;
import com.pages.TravellerDetailsPage;
import com.parameter.DataProviderClass;
import com.setup.Hooks;

@Listeners(com.utils.ExtentListener.class)
public class FlightBookingTest extends Hooks {

    HomePage home;
    LoginPage login;
    SearchPage search;
    FlightListPage flightList;
    FareSelectionPage fareSelection;
    TravellerDetailsPage travellerDetails;

    String mobile;
    String from;
    String to;
    String name;
    String lastName;
    String email;

    @BeforeClass
    public void initializePages() {

        home             = new HomePage(driver);
        login            = new LoginPage(driver);
        search           = new SearchPage(driver);
        flightList       = new FlightListPage(driver);
        fareSelection    = new FareSelectionPage(driver);
        travellerDetails = new TravellerDetailsPage(driver);
    }

    // Priority 1 — load test data from Excel
    @Test(priority = 1, dataProvider = "FlightData", dataProviderClass = DataProviderClass.class)
    public void getTestData(String mobile, String from, String to,
                            String name, String lastName, String email) {

        this.mobile   = mobile;
        this.from     = from;
        this.to       = to;
        this.name     = name;
        this.lastName = lastName;
        this.email    = email;
    }

    // Priority 2 — verify home page and navigate to flights
    @Test(priority = 2, dependsOnMethods = "getTestData")
    public void homePage() {

        Assert.assertTrue(home.isHomePageDisplayed(), "Home page not displayed");

        home.clickFlights();

        // Allow the flights page to fully render before the next step
        try { Thread.sleep(3000); } catch (InterruptedException ignored) {}
    }

    // Priority 3 — OTP login
    // NOTE: triggerLoginIfNeeded() clicks any visible Login button first,
    //       then switchToLoginFrame() finds the SSO iframe with multi-strategy fallback.
    @Test(priority = 3, dependsOnMethods = "homePage")
    public void loginTest() {

        // Click the Login button in the header if it is present
        login.triggerLoginIfNeeded();

        // Switch into the SSO iframe (or stay in default content if no iframe)
        login.switchToLoginFrame();

        login.enterMobileNumber(mobile);

        login.clickContinue();

        System.out.println(">>> Enter OTP manually in the browser, then wait for it to clear <<<");

        login.waitForOTPVerification();

        login.switchToDefaultContent();

        Assert.assertTrue(login.isLoginSuccessful(), "Login was not successful");

        // Allow post-login redirect to settle
        try { Thread.sleep(2000); } catch (InterruptedException ignored) {}
    }

    // Priority 4 — fill in the flight search form
    @Test(priority = 4, dependsOnMethods = "loginTest")
    public void searchFlight() {

        search.enterFrom(from);

        search.enterTo(to);

        search.selectDepartureDate();

        Assert.assertTrue(search.isSearchButtonDisplayed(), "Search button not visible");

        search.clickSearch();

        // Wait for results page to begin loading
        try { Thread.sleep(3000); } catch (InterruptedException ignored) {}
    }

    // Priority 5 — apply filters on flight results
    @Test(priority = 5, dependsOnMethods = "searchFlight")
    public void applyFilters() {

        flightList.applyFilters();

        System.out.println("Filters applied (or skipped if not available)");
    }

    // Priority 6 — select the first available flight
    @Test(priority = 6, dependsOnMethods = "applyFilters")
    public void selectFlight() {

        flightList.selectFlight(0);

        System.out.println("Flight selected");
    }

    // Priority 7 — handle optional fare selection page
    @Test(priority = 7, dependsOnMethods = "selectFlight")
    public void handleFareSelection() {

        fareSelection.selectFareIfPresent();

        System.out.println("Fare selection handled");
    }

    // Priority 8 — fill in traveller details
    @Test(priority = 8, dependsOnMethods = "handleFareSelection")
    public void travellerDetails() {

        Assert.assertTrue(travellerDetails.isTravellerPageDisplayed(),
                "Traveller details page not displayed");

        travellerDetails.selectTitle();

        travellerDetails.enterFirstName(name);

        travellerDetails.enterLastName(lastName);

        travellerDetails.enterMobile(mobile);

        travellerDetails.enterEmail(email);

        travellerDetails.clickContinue();

        System.out.println("Traveller details entered — reached payment page");
    }
}
