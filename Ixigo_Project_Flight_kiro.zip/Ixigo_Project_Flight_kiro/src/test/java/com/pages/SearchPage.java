package com.pages;

import java.time.LocalDate;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class SearchPage extends BasePage {

    JavascriptExecutor js;
    Actions actions;

    public SearchPage(WebDriver driver) {
        super(driver);
        js = (JavascriptExecutor) driver;
        actions = new Actions(driver);
    }

    // -----------------------------------------------------------------------
    // Dynamic locators — resolved at runtime, not via @FindBy, because the
    // Ixigo flights React page does not expose stable id/placeholder attributes
    // that work with PageFactory's proxy on page load.
    // -----------------------------------------------------------------------

    /**
     * Finds the "From" (origin) input using a wide set of strategies.
     * Tries known placeholders, then falls back to the first text input
     * inside the flight search form container.
     */
    private WebElement findFromInput() {
        String[] xpaths = {
            "//input[@placeholder='From']",
            "//input[contains(@placeholder,'From')]",
            "//input[@id='source' or @id='from' or @id='origin' or @name='from' or @name='origin']",
            "//input[contains(@id,'from') or contains(@id,'source') or contains(@id,'origin')]",
            "//input[contains(@class,'origin') or contains(@class,'from')]",
            // Ixigo flight widget — first text input in the search box area
            "(//div[contains(@class,'search') or contains(@class,'widget')]//input[@type='text'])[1]",
            "(//input[@type='text'])[1]"
        };
        for (String xpath : xpaths) {
            try {
                List<WebElement> els = driver.findElements(By.xpath(xpath));
                if (!els.isEmpty() && els.get(0).isDisplayed()) {
                    System.out.println("From input found via: " + xpath);
                    return els.get(0);
                }
            } catch (Exception ignored) {}
        }
        throw new RuntimeException("Could not locate the From/Origin input field on the flight search page");
    }

    /**
     * Finds the "To" (destination) input.
     * Tries known placeholders, then falls back to the second text input
     * inside the flight search form container.
     */
    private WebElement findToInput() {
        String[] xpaths = {
            "//input[@placeholder='To']",
            "//input[contains(@placeholder,'To')]",
            "//input[@id='destination' or @id='to' or @name='to' or @name='destination']",
            "//input[contains(@id,'to') or contains(@id,'dest')]",
            "//input[contains(@class,'destination') or contains(@class,'to')]",
            // Ixigo flight widget — second text input in the search box area
            "(//div[contains(@class,'search') or contains(@class,'widget')]//input[@type='text'])[2]",
            "(//input[@type='text'])[2]"
        };
        for (String xpath : xpaths) {
            try {
                List<WebElement> els = driver.findElements(By.xpath(xpath));
                if (!els.isEmpty() && els.get(0).isDisplayed()) {
                    System.out.println("To input found via: " + xpath);
                    return els.get(0);
                }
            } catch (Exception ignored) {}
        }
        throw new RuntimeException("Could not locate the To/Destination input field on the flight search page");
    }

    /**
     * Finds the departure date input or trigger element.
     */
    private WebElement findDateInput() {
        String[] xpaths = {
            "//input[@placeholder='Departure Date']",
            "//input[contains(@placeholder,'Depart') or contains(@placeholder,'Date')]",
            "//input[@id='depart' or @id='departDate' or @id='onward' or @id='departure']",
            "//div[contains(@class,'depart') or contains(@class,'date')]//input",
            "//div[contains(@class,'date-picker')]//input",
            "(//div[contains(@class,'search') or contains(@class,'widget')]//input[@type='text'])[3]",
            "(//input[@type='text'])[3]"
        };
        for (String xpath : xpaths) {
            try {
                List<WebElement> els = driver.findElements(By.xpath(xpath));
                if (!els.isEmpty() && els.get(0).isDisplayed()) {
                    System.out.println("Date input found via: " + xpath);
                    return els.get(0);
                }
            } catch (Exception ignored) {}
        }
        throw new RuntimeException("Could not locate the Departure Date input field on the flight search page");
    }

    /**
     * Finds the Search/Find Flights button.
     */
    private WebElement findSearchButton() {
        String[] xpaths = {
            "//button[normalize-space()='Search']",
            "//button[contains(text(),'Search') or contains(text(),'Find')]",
            "//button[contains(@class,'search') or contains(@class,'Search')]",
            "//a[contains(text(),'Search') or contains(@class,'search-btn')]",
            "//input[@type='submit' and (contains(@value,'Search') or contains(@value,'Find'))]",
            "(//button[@type='submit'])[1]"
        };
        for (String xpath : xpaths) {
            try {
                List<WebElement> els = driver.findElements(By.xpath(xpath));
                if (!els.isEmpty() && els.get(0).isDisplayed()) {
                    System.out.println("Search button found via: " + xpath);
                    return els.get(0);
                }
            } catch (Exception ignored) {}
        }
        throw new RuntimeException("Could not locate the Search button on the flight search page");
    }

    // -----------------------------------------------------------------------
    // Public methods
    // -----------------------------------------------------------------------

    /**
     * Enters origin city/airport in the From autocomplete field.
     * Uses ARROW_DOWN + ENTER to pick the first suggestion.
     * Falls back to JS dispatchEvent if the dropdown does not open.
     */
    public void enterFrom(String from) {

        WebElement input = findFromInput();

        wait.until(ExpectedConditions.elementToBeClickable(input));
        input.click();
        input.clear();
        input.sendKeys(from);

        try { Thread.sleep(1200); } catch (InterruptedException ignored) {}

        // Check if any suggestion/dropdown appeared
        By suggestionLocator = By.xpath(
            "//ul[contains(@class,'suggest') or contains(@class,'autocomplete')]//li" +
            " | //div[contains(@class,'suggestion') or contains(@class,'option') or contains(@class,'dropdown')]//span[string-length(normalize-space())>0]" +
            " | //li[contains(@class,'search-result') or contains(@class,'city')]"
        );
        boolean dropdownVisible = !driver.findElements(suggestionLocator).isEmpty();

        if (!dropdownVisible) {
            System.out.println("From dropdown not detected — dispatching JS events");
            js.executeScript(
                "var el=arguments[0];" +
                "el.dispatchEvent(new Event('focus',{bubbles:true}));" +
                "el.dispatchEvent(new Event('input',{bubbles:true}));" +
                "el.dispatchEvent(new Event('keyup',{bubbles:true}));",
                input
            );
            try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
        }

        // Press ARROW_DOWN then ENTER to accept first suggestion
        input.sendKeys(Keys.ARROW_DOWN);
        try { Thread.sleep(500); } catch (InterruptedException ignored) {}
        input.sendKeys(Keys.ENTER);

        System.out.println("Entered From: " + from);
        try { Thread.sleep(800); } catch (InterruptedException ignored) {}
    }

    /**
     * Enters destination city/airport in the To autocomplete field.
     */
    public void enterTo(String to) {

        WebElement input = findToInput();

        wait.until(ExpectedConditions.elementToBeClickable(input));
        input.click();
        input.clear();
        input.sendKeys(to);

        try { Thread.sleep(1200); } catch (InterruptedException ignored) {}

        By suggestionLocator = By.xpath(
            "//ul[contains(@class,'suggest') or contains(@class,'autocomplete')]//li" +
            " | //div[contains(@class,'suggestion') or contains(@class,'option') or contains(@class,'dropdown')]//span[string-length(normalize-space())>0]" +
            " | //li[contains(@class,'search-result') or contains(@class,'city')]"
        );
        boolean dropdownVisible = !driver.findElements(suggestionLocator).isEmpty();

        if (!dropdownVisible) {
            System.out.println("To dropdown not detected — dispatching JS events");
            js.executeScript(
                "var el=arguments[0];" +
                "el.dispatchEvent(new Event('focus',{bubbles:true}));" +
                "el.dispatchEvent(new Event('input',{bubbles:true}));" +
                "el.dispatchEvent(new Event('keyup',{bubbles:true}));",
                input
            );
            try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
        }

        input.sendKeys(Keys.ARROW_DOWN);
        try { Thread.sleep(500); } catch (InterruptedException ignored) {}
        input.sendKeys(Keys.ENTER);

        System.out.println("Entered To: " + to);
        try { Thread.sleep(800); } catch (InterruptedException ignored) {}
    }

    /**
     * Opens the date picker and selects a date 7 days from today.
     * Always picks a future date — never a past date.
     */
    public void selectDepartureDate() {

        WebElement dateInput = findDateInput();
        wait.until(ExpectedConditions.elementToBeClickable(dateInput));
        dateInput.click();

        try { Thread.sleep(800); } catch (InterruptedException ignored) {}

        LocalDate target = LocalDate.now().plusDays(7);
        String dayStr = String.valueOf(target.getDayOfMonth());

        System.out.println("Selecting departure date: " + target + " (day " + dayStr + ")");

        // Try multiple calendar cell patterns used by different date picker widgets
        String[] calendarXpaths = {
            "//div[contains(@class,'DayPicker')]//div[not(@disabled) and not(contains(@class,'disabled')) and normalize-space()='" + dayStr + "']",
            "//div[contains(@class,'calendar')]//div[not(@disabled) and not(contains(@class,'disabled')) and not(contains(@class,'past')) and normalize-space()='" + dayStr + "']",
            "//td[contains(@class,'day') and normalize-space()='" + dayStr + "' and not(contains(@class,'disabled'))]",
            "//div[contains(@class,'cal') and normalize-space()='" + dayStr + "' and not(contains(@class,'disabled')) and not(contains(@class,'past'))]",
            "//span[contains(@class,'day') and normalize-space()='" + dayStr + "' and not(contains(@class,'disabled'))]",
            "//div[@role='button' and normalize-space()='" + dayStr + "' and not(@disabled)]",
            "//button[normalize-space()='" + dayStr + "' and not(@disabled) and not(contains(@class,'disabled'))]"
        };

        boolean dateSelected = false;
        for (String xpath : calendarXpaths) {
            try {
                List<WebElement> days = driver.findElements(By.xpath(xpath));
                if (!days.isEmpty()) {
                    WebElement day = days.get(0);
                    js.executeScript("arguments[0].scrollIntoView({block:'center'});", day);
                    try { Thread.sleep(300); } catch (InterruptedException ignored) {}
                    try {
                        day.click();
                    } catch (Exception e) {
                        js.executeScript("arguments[0].click();", day);
                    }
                    System.out.println("Departure date selected via: " + xpath);
                    dateSelected = true;
                    break;
                }
            } catch (Exception ignored) {}
        }

        if (!dateSelected) {
            System.out.println("Could not find calendar cell for day " + dayStr + " — continuing anyway.");
        }

        try { Thread.sleep(500); } catch (InterruptedException ignored) {}
    }

    /**
     * Clicks the Search button; falls back to JS click if intercepted.
     */
    public void clickSearch() {

        WebElement btn = findSearchButton();
        wait.until(ExpectedConditions.elementToBeClickable(btn));

        try {
            btn.click();
        } catch (Exception e) {
            System.out.println("Native search click intercepted — using JS fallback");
            js.executeScript("arguments[0].click();", btn);
        }

        System.out.println("Search button clicked");
    }

    public boolean isSearchButtonDisplayed() {
        try {
            return findSearchButton().isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

}
