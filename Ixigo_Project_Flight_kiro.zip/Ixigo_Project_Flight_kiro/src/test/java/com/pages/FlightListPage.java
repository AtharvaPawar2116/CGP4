package com.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class FlightListPage extends BasePage {

    JavascriptExecutor js;

    public FlightListPage(WebDriver driver) {
        super(driver);
        js = (JavascriptExecutor) driver;
    }

    // ---------- Locators ----------

    // Non-stop filter label / button
    @FindBy(xpath =
        "//div[contains(@class,'filter')]//label[contains(text(),'Non stop')" +
        " or contains(text(),'Non-stop') or contains(text(),'Nonstop')" +
        " or contains(text(),'non-stop') or contains(text(),'nonstop')]" +
        " | //button[contains(@class,'filter') and (contains(.,'Non') or contains(.,'non'))]" +
        " | //span[contains(text(),'Non stop') or contains(text(),'Non-stop')]" +
        " | //div[contains(@class,'stops')]//label[contains(.,'0')]"
    )
    List<WebElement> nonStopFilter;

    // Book / View Prices buttons on flight cards
    @FindBy(xpath =
        "//button[contains(text(),'Book') or contains(text(),'View Prices')" +
        " or contains(@class,'book-btn') or contains(@class,'bookBtn')" +
        " or contains(@class,'book_btn')]" +
        " | //a[contains(text(),'Book') or contains(text(),'View Prices')" +
        " or contains(@class,'book-btn')]"
    )
    List<WebElement> bookButtons;

    // Locator for wait — any flight result card or book button
    private final By anyFlightLocator = By.xpath(
        "//button[contains(text(),'Book') or contains(text(),'View Prices')" +
        " or contains(@class,'book-btn') or contains(@class,'bookBtn')]" +
        " | //div[contains(@class,'flight-card')] | //div[contains(@class,'result-item')]" +
        " | //div[contains(@class,'flight-listing')]//div[contains(@class,'item')]"
    );

    // ---------- Methods ----------

    /**
     * Waits for flight results and optionally applies the Non-stop filter.
     * Gracefully continues if the filter is not present — never throws.
     */
    public void applyFilters() {

        System.out.println("Waiting for flight results to load...");

        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(anyFlightLocator));
            Thread.sleep(2000); // let all cards render
        } catch (Exception e) {
            System.out.println("Flight results wait: " + e.getMessage());
        }

        // Refresh the nonStopFilter list after page load
        List<WebElement> filters = driver.findElements(By.xpath(
            "//div[contains(@class,'filter')]//label[contains(text(),'Non stop')" +
            " or contains(text(),'Non-stop') or contains(text(),'Nonstop')" +
            " or contains(text(),'non-stop') or contains(text(),'nonstop')]" +
            " | //button[contains(@class,'filter') and (contains(.,'Non') or contains(.,'non'))]" +
            " | //span[contains(text(),'Non stop') or contains(text(),'Non-stop')]" +
            " | //div[contains(@class,'stops')]//label[contains(.,'0')]"
        ));

        if (!filters.isEmpty()) {
            try {
                WebElement filter = filters.get(0);
                js.executeScript("arguments[0].scrollIntoView({block:'center'});", filter);
                Thread.sleep(400);
                try {
                    filter.click();
                } catch (Exception e) {
                    js.executeScript("arguments[0].click();", filter);
                }
                System.out.println("Non-stop filter applied.");
                Thread.sleep(1500);
            } catch (Exception e) {
                System.out.println("Could not click Non-stop filter (continuing): " + e.getMessage());
            }
        } else {
            System.out.println("Non-stop filter not found on page — continuing without filter.");
        }
    }

    /**
     * Returns true if at least one Book/View-Prices button is present.
     */
    public boolean isFlightAvailable() {

        List<WebElement> btns = driver.findElements(By.xpath(
            "//button[contains(text(),'Book') or contains(text(),'View Prices')" +
            " or contains(@class,'book-btn') or contains(@class,'bookBtn')]" +
            " | //a[contains(text(),'Book') or contains(text(),'View Prices')]"
        ));
        return !btns.isEmpty();
    }

    /**
     * Selects a flight at the given index by clicking its Book / View Prices button.
     * Falls back to JS click if the native click is intercepted.
     * Throws RuntimeException if no flights are available.
     */
    public void selectFlight(int index) {

        By bookLocator = By.xpath(
            "//button[contains(text(),'Book') or contains(text(),'View Prices')" +
            " or contains(@class,'book-btn') or contains(@class,'bookBtn')" +
            " or contains(@class,'book_btn')]" +
            " | //a[contains(text(),'Book') or contains(text(),'View Prices')" +
            " or contains(@class,'book-btn')]"
        );

        wait.until(ExpectedConditions.presenceOfElementLocated(bookLocator));

        List<WebElement> buttons = driver.findElements(bookLocator);

        if (buttons.isEmpty()) {
            throw new RuntimeException("No flight cards found on results page");
        }

        int targetIndex = (index >= 0 && index < buttons.size()) ? index : 0;
        WebElement btn = buttons.get(targetIndex);

        System.out.println("Selecting flight at index " + targetIndex + " of " + buttons.size() + " results");

        js.executeScript("arguments[0].scrollIntoView({behavior:'instant', block:'center'});", btn);

        try {
            Thread.sleep(800);
        } catch (InterruptedException ignored) {}

        try {
            btn.click();
        } catch (Exception e) {
            System.out.println("Native click intercepted — using JS fallback for Book button");
            js.executeScript("arguments[0].click();", btn);
        }

        System.out.println("Flight selected.");

        try {
            Thread.sleep(2000);
        } catch (InterruptedException ignored) {}
    }

}
