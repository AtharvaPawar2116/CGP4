package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HomePage extends BasePage {

    public HomePage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//a[contains(text(),'Flights')] | //li[contains(@class,'flights')]//a | //span[text()='Flights']/parent::a")
    WebElement flightsLink;

    public void clickFlights() {

        wait.until(ExpectedConditions.elementToBeClickable(flightsLink));

        flightsLink.click();

    }

    public boolean isHomePageDisplayed() {

        return driver.getTitle().toLowerCase().contains("ixigo");

    }

}
