package com.pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FareSelectionPage extends BasePage {

    JavascriptExecutor js;

    public FareSelectionPage(WebDriver driver) {
        super(driver);
        js = (JavascriptExecutor) driver;
    }

    // Locator for any fare card / option element
    private final By fareCardLocator = By.xpath(
        "//div[contains(@class,'fare-card')]" +
        " | //div[contains(@class,'fareType')]" +
        " | //div[contains(@class,'fare') and contains(@class,'option')]" +
        " | //button[contains(@class,'fare') or contains(text(),'Saver') or contains(text(),'Flexi')]" +
        " | //div[contains(text(),'Saver') or contains(text(),'Flexi') or contains(text(),'Value')]"
    );

    // Locator for the Continue button on the fare page
    private final By fareContinueLocator = By.xpath(
        "//button[contains(text(),'Continue') or contains(text(),'Proceed')" +
        " or contains(@class,'continue') or contains(@class,'proceed')]" +
        " | //a[contains(text(),'Continue') or contains(text(),'Proceed')]"
    );

    /**
     * Checks if the fare selection page is currently present.
     * Uses a short 5-second wait — returns false (never throws) if absent.
     */
    public boolean isFarePagePresent() {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(5))
                .until(ExpectedConditions.presenceOfElementLocated(fareCardLocator));
            System.out.println("Fare selection page detected.");
            return true;
        } catch (TimeoutException e) {
            System.out.println("Fare selection page not present — skipping.");
            return false;
        } catch (Exception e) {
            System.out.println("Fare page check error (treating as absent): " + e.getMessage());
            return false;
        }
    }

    /**
     * Selects the first fare option if the page is present; silently skips if absent.
     * Never throws an unchecked exception.
     */
    public void selectFareIfPresent() {

        if (!isFarePagePresent()) {
            return;
        }

        try {
            List<WebElement> fareOptions = driver.findElements(fareCardLocator);
            if (!fareOptions.isEmpty()) {
                WebElement firstFare = fareOptions.get(0);
                js.executeScript("arguments[0].scrollIntoView({block:'center'});", firstFare);
                try { Thread.sleep(400); } catch (InterruptedException ignored) {}
                js.executeScript("arguments[0].click();", firstFare);
                System.out.println("Fare option selected.");
                Thread.sleep(1000);
            }

            // Click Continue if present
            List<WebElement> continueBtns = driver.findElements(fareContinueLocator);
            if (!continueBtns.isEmpty()) {
                WebElement cont = continueBtns.get(0);
                js.executeScript("arguments[0].scrollIntoView({block:'center'});", cont);
                try { Thread.sleep(400); } catch (InterruptedException ignored) {}
                js.executeScript("arguments[0].click();", cont);
                System.out.println("Fare continue button clicked.");
                Thread.sleep(1500);
            }

        } catch (Exception e) {
            System.out.println("Error during fare selection (continuing): " + e.getMessage());
        }
    }

}
