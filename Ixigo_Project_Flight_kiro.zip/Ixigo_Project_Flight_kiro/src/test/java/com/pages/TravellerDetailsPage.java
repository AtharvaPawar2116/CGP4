package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class TravellerDetailsPage extends BasePage {

    JavascriptExecutor js;
    Actions actions;

    public TravellerDetailsPage(WebDriver driver) {
        super(driver);
        js = (JavascriptExecutor) driver;
        actions = new Actions(driver);
    }

    // ---------- Locators ----------

    // Title selector (Mr)
    @FindBy(xpath =
        "//div[contains(@class,'title')]//button[contains(text(),'Mr') or @value='Mr']" +
        " | //li[normalize-space()='Mr']" +
        " | //span[normalize-space()='Mr' and (parent::button or parent::li or parent::div)]" +
        " | //select[contains(@name,'title') or contains(@id,'title') or contains(@name,'salutation')]"
    )
    WebElement titleMr;

    // First name input
    @FindBy(xpath =
        "//input[@placeholder='First Name' or @name='firstName' or @name='first_name'" +
        " or @name='fname' or contains(@placeholder,'First') or contains(@id,'first')]"
    )
    WebElement firstName;

    // Last name input
    @FindBy(xpath =
        "//input[@placeholder='Last Name' or @name='lastName' or @name='last_name'" +
        " or @name='lname' or contains(@placeholder,'Last') or contains(@id,'last')]"
    )
    WebElement lastName;

    // Mobile number input
    @FindBy(xpath =
        "//input[@placeholder='Mobile Number' or @placeholder='Mobile'" +
        " or @type='tel' or contains(@placeholder,'Mobile') or contains(@placeholder,'Phone')" +
        " or contains(@name,'mobile') or contains(@name,'phone') or contains(@id,'mobile')]"
    )
    WebElement mobileInput;

    // Email input
    @FindBy(xpath =
        "//input[@placeholder='Email' or @type='email'" +
        " or contains(@placeholder,'Email') or contains(@placeholder,'email')" +
        " or @name='email' or contains(@id,'email')]"
    )
    WebElement emailInput;

    // Continue / Proceed / Review button
    @FindBy(xpath =
        "//button[contains(text(),'Continue') or contains(text(),'Proceed')" +
        " or contains(text(),'Review') or contains(@class,'continue-btn')" +
        " or contains(@class,'proceed') or contains(@class,'continueBtn')]" +
        " | //a[contains(text(),'Continue') or contains(text(),'Proceed')]"
    )
    WebElement continueBtn;

    // ---------- Methods ----------

    /**
     * Returns true when the traveller details form is visible (First Name field present).
     */
    public boolean isTravellerPageDisplayed() {
        By firstNameBy = By.xpath(
            "//input[@placeholder='First Name' or @name='firstName' or @name='first_name'" +
            " or @name='fname' or contains(@placeholder,'First') or contains(@id,'first')]"
        );
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameBy)).isDisplayed();
        } catch (Exception e) {
            System.out.println("Traveller page first name not visible: " + e.getMessage());
            return false;
        }
    }

    /**
     * Selects the "Mr" title using JS click to handle React-rendered selectors.
     */
    public void selectTitle() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(titleMr));
            js.executeScript("arguments[0].scrollIntoView({block:'center'});", titleMr);
            try { Thread.sleep(400); } catch (InterruptedException ignored) {}
            js.executeScript("arguments[0].click();", titleMr);
            System.out.println("Title 'Mr' selected.");
        } catch (Exception e) {
            System.out.println("Title selection skipped (not found or already selected): " + e.getMessage());
        }
    }

    /**
     * Enters text into an input field with sendKeys + JS value fallback for React inputs.
     * Dispatches a React-compatible change event after JS fallback.
     */
    private void typeIntoField(WebElement el, String value) {
        js.executeScript("arguments[0].scrollIntoView({block:'center'});", el);
        try { Thread.sleep(500); } catch (InterruptedException ignored) {}

        el.clear();
        el.sendKeys(value);

        // Check if sendKeys registered; if not, fall back to JS value assignment
        String current = el.getAttribute("value");
        if (current == null || current.isEmpty()) {
            System.out.println("sendKeys did not register — using JS fallback for field");
            js.executeScript("arguments[0].value = arguments[1];", el, value);

            // Dispatch React-compatible input + change events
            js.executeScript(
                "var el = arguments[0];" +
                "var evt = new Event('input', {bubbles: true});" +
                "el.dispatchEvent(evt);" +
                "var evt2 = new Event('change', {bubbles: true});" +
                "el.dispatchEvent(evt2);",
                el
            );
        }
    }

    public void enterFirstName(String name) {
        wait.until(ExpectedConditions.elementToBeClickable(firstName));
        typeIntoField(firstName, name);
        System.out.println("First name entered: " + name);
    }

    public void enterLastName(String name) {
        wait.until(ExpectedConditions.elementToBeClickable(lastName));
        typeIntoField(lastName, name);
        System.out.println("Last name entered: " + name);
    }

    public void enterMobile(String mobile) {
        wait.until(ExpectedConditions.elementToBeClickable(mobileInput));
        typeIntoField(mobileInput, mobile);
        System.out.println("Mobile entered: " + mobile);
    }

    public void enterEmail(String email) {
        wait.until(ExpectedConditions.elementToBeClickable(emailInput));
        typeIntoField(emailInput, email);
        System.out.println("Email entered: " + email);
    }

    /**
     * Clicks the Continue/Proceed/Review button using a 3-tier fallback:
     * native click → Actions click → JS click.
     */
    public void clickContinue() {
        wait.until(ExpectedConditions.elementToBeClickable(continueBtn));
        js.executeScript("arguments[0].scrollIntoView({block:'center'});", continueBtn);
        try { Thread.sleep(500); } catch (InterruptedException ignored) {}

        try {
            continueBtn.click();
        } catch (ElementClickInterceptedException e1) {
            System.out.println("Native click intercepted — trying Actions click");
            try {
                actions.moveToElement(continueBtn).click().perform();
            } catch (Exception e2) {
                System.out.println("Actions click failed — using JS fallback");
                js.executeScript("arguments[0].click();", continueBtn);
            }
        }
        System.out.println("Continue button clicked.");
    }

}
