package com.pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage extends BasePage {

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    // Keep the original @FindBy for PageFactory init — used as fallback
    @FindBy(id = "sso-frame")
    WebElement loginFrame;

    @FindBy(xpath = "//input[@placeholder='Mobile no.' or @placeholder='Mobile No.' or @placeholder='Enter mobile number' or @type='tel']")
    WebElement mobileNumber;

    @FindBy(xpath = "//button[normalize-space()='Continue' or normalize-space()='CONTINUE' or contains(text(),'Continue')]")
    WebElement continueBtn;

    /**
     * Resilient frame switcher for Ixigo SSO login.
     * Strategy:
     *   1. Try switching by the well-known id "sso-frame"
     *   2. Fall back to any iframe on the page (first one found)
     *   3. If no iframe, assume login is not framed (direct DOM) — skip frame switch
     */
    public void switchToLoginFrame() {

        System.out.println("Attempting to switch to login frame...");

        // Wait a moment for any login dialog/iframe to appear
        try { Thread.sleep(2000); } catch (InterruptedException ignored) {}

        // Strategy 1: by id "sso-frame"
        try {
            new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("sso-frame")));
            System.out.println("Switched to login frame by id 'sso-frame'.");
            return;
        } catch (Exception e) {
            System.out.println("sso-frame not found by id — trying other strategies.");
        }

        // Strategy 2: any iframe with name/id/src related to sso or login
        try {
            WebElement ssoFrame = driver.findElement(By.xpath(
                "//iframe[contains(@id,'sso') or contains(@name,'sso')" +
                " or contains(@src,'sso') or contains(@id,'login') or contains(@name,'login')]"
            ));
            driver.switchTo().frame(ssoFrame);
            System.out.println("Switched to SSO-related iframe.");
            return;
        } catch (Exception e) {
            System.out.println("No SSO iframe by attribute — trying any iframe.");
        }

        // Strategy 3: switch to first iframe on page
        try {
            List<WebElement> frames = driver.findElements(By.tagName("iframe"));
            if (!frames.isEmpty()) {
                driver.switchTo().frame(frames.get(0));
                System.out.println("Switched to first iframe on page (index 0).");
                return;
            }
        } catch (Exception e) {
            System.out.println("No iframes found: " + e.getMessage());
        }

        // Strategy 4: Login may be in a modal/popup without an iframe — stay in default content
        System.out.println("No iframe found — assuming login is in default content (no frame switch needed).");
    }

    /**
     * Triggers the login/sign-in popup if it hasn't appeared yet.
     * Ixigo flights page may require clicking a "Login" button first.
     */
    public void triggerLoginIfNeeded() {
        try {
            // Look for a Login/Sign In button in the page header
            By loginBtnLocator = By.xpath(
                "//a[contains(text(),'Login') or contains(text(),'Sign In') or contains(text(),'Sign in')]" +
                " | //button[contains(text(),'Login') or contains(text(),'Sign In')]" +
                " | //span[contains(text(),'Login') or contains(text(),'Sign in')]/parent::*"
            );
            List<WebElement> loginBtns = driver.findElements(loginBtnLocator);
            if (!loginBtns.isEmpty()) {
                System.out.println("Login button found — clicking to trigger SSO popup.");
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", loginBtns.get(0));
                try { Thread.sleep(2000); } catch (InterruptedException ignored) {}
            } else {
                System.out.println("No explicit Login button found — SSO may already be present.");
            }
        } catch (Exception e) {
            System.out.println("triggerLoginIfNeeded: " + e.getMessage());
        }
    }

    public void enterMobileNumber(String mobile) {

        // Re-locate the mobile field dynamically (handles both framed and non-framed login)
        By mobileBy = By.xpath(
            "//input[@placeholder='Mobile no.' or @placeholder='Mobile No.'" +
            " or @placeholder='Enter mobile number' or contains(@placeholder,'mobile')" +
            " or contains(@placeholder,'Mobile') or (@type='tel' and not(@readonly))]"
        );

        wait.until(ExpectedConditions.visibilityOfElementLocated(mobileBy));
        WebElement mob = driver.findElement(mobileBy);
        mob.clear();
        mob.sendKeys(mobile);

    }

    public void clickContinue() {

        By continueBy = By.xpath(
            "//button[normalize-space()='Continue' or normalize-space()='CONTINUE'" +
            " or contains(text(),'Continue') or contains(text(),'CONTINUE')]"
        );

        wait.until(ExpectedConditions.visibilityOfElementLocated(continueBy));
        wait.until(ExpectedConditions.elementToBeClickable(continueBy));

        WebElement btn = driver.findElement(continueBy);
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);

    }

    public void waitForOTPVerification() {

        // Wait until the OTP entry screen is gone (user enters OTP manually)
        wait.until(ExpectedConditions.invisibilityOfElementLocated(
                By.xpath("//div[contains(text(),'Enter OTP') or contains(text(),'OTP')]")));

    }

    public void switchToDefaultContent() {

        driver.switchTo().defaultContent();

    }

    public boolean isLoginSuccessful() {

        return driver.getCurrentUrl().contains("ixigo");

    }

}
